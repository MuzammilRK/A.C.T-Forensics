import type { ReactNode } from "react";
import type { Severity } from "../lib/types";

/* --------------------------------- icons ---------------------------------- */

const PATHS: Record<string, string> = {
  dashboard: "M4 4h7v7H4zM13 4h7v4h-7zM13 10h7v10h-7zM4 13h7v7H4z",
  evidence: "M7 3h7l4 4v14H7zM14 3v5h4M10 13h5M10 17h5",
  scan: "M12 3l7 3v6c0 4-3 7-7 9-4-2-7-5-7-9V6zM9 12l2 2 4-4",
  graph: "M5 6h4v4H5zM15 14h4v4h-4zM5 16h4v4H5zM9 7h6v9M9 18h6",
  link: "M9 15l6-6M8 7l2-2a4 4 0 016 6l-2 2M16 17l-2 2a4 4 0 01-6-6l2-2",
  ledger: "M12 3l8 4v6c0 4-3 6-8 8-5-2-8-4-8-8V7zM9 12l2 2 4-4",
  report: "M6 3h9l4 4v14H6zM15 3v5h4M9 12h6M9 16h6M9 8h2",
  upload: "M12 16V4M7 9l5-5 5 5M4 16v3h16v-3",
  close: "M6 6l12 12M18 6L6 18",
  check: "M4 12l5 5L20 6",
  alert: "M12 3l9 17H3zM12 9v5M12 17h.01",
  copy: "M8 8h11v11H8zM5 16V5h11",
  download: "M12 4v11M7 10l5 5 5-5M4 19h16",
  print: "M7 8V3h10v5M7 17H5a1 1 0 01-1-1v-6h16v6a1 1 0 01-1 1h-2M7 14h10v7H7z",
  plus: "M12 5v14M5 12h14",
  image: "M4 5h16v14H4zM4 15l5-4 4 3 3-2 4 3M15 9a1.4 1.4 0 11-2.8 0 1.4 1.4 0 012.8 0",
  video: "M4 6h11v12H4zM15 10l5-3v10l-5-3",
  audio: "M4 10v4M8 6v12M12 3v18M16 8v8M20 11v2",
  doc: "M6 3h8l4 4v14H6zM14 3v5h4M9 13h6M9 17h4",
  code: "M9 8l-4 4 4 4M15 8l4 4-4 4",
  spark: "M12 3l1.8 5.4L19 10l-5.2 1.6L12 17l-1.8-5.4L5 10l5.2-1.6z",
  search: "M11 4a7 7 0 105 12 7 7 0 00-5-12zM20 20l-4-4",
  arrow: "M5 12h14M13 6l6 6-6 6",
  shield: "M12 3l8 3v7c0 4-3 7-8 9-5-2-8-5-8-9V6z",
  refresh: "M20 12a8 8 0 11-2.3-5.6M20 4v5h-5",
  trash: "M4 7h16M9 7V4h6v3M6 7l1 14h10l1-14",
};

export function Icon({ name, size = 16 }: { name: keyof typeof PATHS | string; size?: number }) {
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      fill="none"
      stroke="currentColor"
      strokeWidth={1.6}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d={PATHS[name] ?? PATHS.dashboard} />
    </svg>
  );
}

export function kindIcon(kind: string): string {
  switch (kind) {
    case "image":
      return "image";
    case "video":
      return "video";
    case "audio":
      return "audio";
    case "code":
      return "code";
    default:
      return "doc";
  }
}

/* ------------------------------- score ring -------------------------------- */

export function scoreColor(value: number): string {
  if (value >= 70) return "#ff6078";
  if (value >= 45) return "#ffc857";
  return "#3fe0cf";
}

export function ScoreRing({
  value,
  size = 88,
  label = "AI likelihood",
  stroke = 7,
}: {
  value: number;
  size?: number;
  label?: string;
  stroke?: number;
}) {
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const color = scoreColor(value);
  return (
    <div className="score" style={{ width: size, height: size }}>
      <svg width={size} height={size}>
        <circle cx={size / 2} cy={size / 2} r={radius} stroke="rgba(255,255,255,0.07)" strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={color}
          strokeWidth={stroke}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={`${(value / 100) * circumference} ${circumference}`}
          style={{ filter: `drop-shadow(0 0 6px ${color}66)` }}
        />
      </svg>
      <div className="score-center">
        <div className="score-value" style={{ color }}>
          {Math.round(value)}%
        </div>
        <div className="score-label">{label}</div>
      </div>
    </div>
  );
}

export function SeverityBadge({ severity }: { severity: Severity }) {
  return <span className={`badge badge-${severity}`}>{severity}</span>;
}

export function Stat({
  label,
  value,
  note,
  accent,
}: {
  label: string;
  value: ReactNode;
  note?: ReactNode;
  accent?: "cyan" | "red" | "amber" | "blue";
}) {
  return (
    <div className="stat">
      <div className="stat-label">{label}</div>
      <div className={`stat-value ${accent ? `accent-${accent}` : ""}`}>{value}</div>
      {note && <div className="stat-note">{note}</div>}
    </div>
  );
}

export function Empty({ title, children, icon = "search" }: { title: string; children?: ReactNode; icon?: string }) {
  return (
    <div className="empty">
      <Icon name={icon} size={28} />
      <div style={{ color: "var(--text)", fontSize: 13.5, fontWeight: 600, marginBottom: 6 }}>{title}</div>
      {children}
    </div>
  );
}

export function Meter({ value, color }: { value: number; color?: string }) {
  return (
    <div className="meter">
      <div style={{ width: `${Math.max(2, Math.min(100, value))}%`, ...(color ? { background: color } : {}) }} />
    </div>
  );
}

export function CopyButton({ text, label = "Copy" }: { text: string; label?: string }) {
  return (
    <button
      className="btn btn-sm btn-ghost"
      onClick={(e) => {
        e.stopPropagation();
        void navigator.clipboard?.writeText(text);
      }}
      type="button"
    >
      {label}
    </button>
  );
}
