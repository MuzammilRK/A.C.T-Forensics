import { useMemo } from "react";
import type { GraphNode } from "../lib/types";
import type { ThreatGraph } from "../lib/graph";

const NODE_W = 194;
const NODE_H = 46;
const LAYER_GAP = 252;
const ROW_GAP = 60;

const LAYER_LABEL = ["ENTRY POINT", "WEAKNESS", "ASSET", "IMPACT"];

function nodeColor(node: GraphNode): string {
  if (node.kind === "entry") return "#5b9dff";
  if (node.kind === "asset") return "#a78bfa";
  if (node.kind === "impact") return "#ff6078";
  if (node.kind === "evidence") return "#3fe0cf";
  switch (node.severity) {
    case "critical":
      return "#ff6078";
    case "high":
      return "#ff9a5c";
    case "medium":
      return "#ffc857";
    default:
      return "#7f96b3";
  }
}

export function GraphView({
  graph,
  activeNodes = [],
  onSelect,
}: {
  graph: ThreatGraph;
  activeNodes?: string[];
  onSelect?: (node: GraphNode) => void;
}) {
  const layout = useMemo(() => {
    const positions = new Map<string, { x: number; y: number }>();
    const byLayer = new Map<number, GraphNode[]>();
    for (const node of graph.nodes) {
      const layer = node.kind === "evidence" ? 2 : node.layer;
      if (!byLayer.has(layer)) byLayer.set(layer, []);
      byLayer.get(layer)!.push(node);
    }
    const ordered: GraphNode[] = [];
    for (let layer = 0; layer <= 3; layer++) {
      const list = (byLayer.get(layer) ?? []).sort((a, b) => {
        const rank = (n: GraphNode) => (n.kind === "evidence" ? 2 : n.kind === "asset" ? 0 : n.kind === "weakness" ? 1 : 0);
        if (rank(a) !== rank(b)) return rank(a) - rank(b);
        return a.label.localeCompare(b.label);
      });
      list.forEach((node, index) => {
        ordered.push(node);
        positions.set(node.id, {
          x: 34 + layer * LAYER_GAP,
          y: 44 + index * ROW_GAP,
        });
      });
    }
    const maxRows = Math.max(...Array.from(byLayer.values()).map((l) => l.length), 1);
    const height = Math.max(280, 44 + maxRows * ROW_GAP + 30);
    const width = 34 + 3 * LAYER_GAP + NODE_W + 40;
    return { positions, height, width };
  }, [graph]);

  const activeSet = new Set(activeNodes);

  return (
    <div className="stack" style={{ gap: 10 }}>
      <div className="graph-shell">
        <svg
          viewBox={`0 0 ${layout.width} ${layout.height}`}
          width="100%"
          style={{ minWidth: 900, height: "auto" }}
          role="img"
          aria-label="Evidence threat-link graph"
        >
          <defs>
            <marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
              <path d="M 0 0 L 10 5 L 0 10 z" fill="#34506e" />
            </marker>
            <marker id="arrow-active" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
              <path d="M 0 0 L 10 5 L 0 10 z" fill="#3fe0cf" />
            </marker>
          </defs>

          {[0, 1, 2, 3].map((layer) => (
            <g key={layer}>
              <text
                x={34 + layer * LAYER_GAP}
                y={20}
                fill="#5f7694"
                style={{ fontFamily: "var(--mono)", fontSize: 8, letterSpacing: 1.6 }}
              >
                {LAYER_LABEL[layer]}
              </text>
              <line
                x1={34 + layer * LAYER_GAP}
                y1={26}
                x2={34 + layer * LAYER_GAP + NODE_W}
                y2={26}
                stroke="#1c2c42"
                strokeWidth={1}
              />
            </g>
          ))}

          {graph.edges.map((edge) => {
            const from = layout.positions.get(edge.from);
            const to = layout.positions.get(edge.to);
            if (!from || !to) return null;
            const x1 = from.x + NODE_W;
            const y1 = from.y + NODE_H / 2;
            const x2 = to.x;
            const y2 = to.y + NODE_H / 2;
            const isActive = activeSet.has(edge.from) && activeSet.has(edge.to);
            const dim = activeSet.size > 0 && !isActive;
            const control = Math.max(40, (x2 - x1) / 2);
            return (
              <path
                key={`${edge.from}-${edge.to}`}
                d={`M ${x1} ${y1} C ${x1 + control} ${y1}, ${x2 - control} ${y2}, ${x2 - 6} ${y2}`}
                className={`edge ${isActive ? "active" : ""} ${dim ? "dim" : ""}`}
                markerEnd={isActive ? "url(#arrow-active)" : "url(#arrow)"}
              />
            );
          })}

          {graph.nodes.map((node) => {
            const pos = layout.positions.get(node.id);
            if (!pos) return null;
            const color = nodeColor(node);
            const isActive = activeSet.has(node.id);
            const dim = activeSet.size > 0 && !isActive;
            return (
              <g
                key={node.id}
                className={`node ${isActive ? "active" : ""} ${dim ? "dim" : ""}`}
                transform={`translate(${pos.x}, ${pos.y})`}
                onClick={() => onSelect?.(node)}
                style={{ cursor: onSelect ? "pointer" : "default" }}
              >
                <rect
                  width={NODE_W}
                  height={NODE_H}
                  rx={8}
                  fill="rgba(13,22,37,0.94)"
                  stroke={isActive ? "#3fe0cf" : "#22364d"}
                  strokeWidth={1}
                />
                <rect width={3.5} height={NODE_H} rx={2} fill={color} />
                <text x={12} y={17} className="node-kind">
                  {node.kind}
                </text>
                <text x={12} y={32} style={{ fontSize: 10 }}>
                  {node.label.length > 30 ? `${node.label.slice(0, 29)}…` : node.label}
                </text>
                <circle cx={NODE_W - 12} cy={14} r={3} fill={color} />
              </g>
            );
          })}
        </svg>
      </div>
      <div className="row" style={{ gap: 16, fontSize: 10.5, color: "var(--muted-2)" }}>
        {[
          ["#5b9dff", "Entry"],
          ["#ff6078", "Critical weakness / impact"],
          ["#a78bfa", "Asset"],
          ["#3fe0cf", "Evidence exhibit"],
        ].map(([color, label]) => (
          <span key={label} style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
            <span style={{ width: 8, height: 8, borderRadius: 2, background: color }} />
            {label}
          </span>
        ))}
        <span style={{ marginLeft: "auto", fontFamily: "var(--mono)" }}>
          {graph.nodes.length} nodes · {graph.edges.length} edges
        </span>
      </div>
    </div>
  );
}
