import { useCallback, useEffect, useMemo, useState } from "react";
import { activeCase, createCase, setActiveCase, useAppStore } from "./lib/store";
import { seedDemoCase } from "./lib/demo";
import { buildThreatGraph } from "./lib/graph";
import { Icon } from "./components/ui";
import { pageMeta, type Page } from "./pages/nav";
import { Overview } from "./pages/Overview";
import { EvidenceLab } from "./pages/EvidenceLab";
import { Scanner } from "./pages/Scanner";
import { WebsiteScanner } from "./pages/Website";
import { AttackPaths, ThreatLink } from "./pages/Graphs";
import { Ledger } from "./pages/Ledger";
import { Report } from "./pages/Report";

const NAV: Page[] = ["overview", "evidence", "web", "scanner", "paths", "link", "ledger", "report"];

export default function App() {
  const state = useAppStore();
  const caseFile = activeCase(state);
  const [page, setPage] = useState<Page>("overview");
  const [focusEvidence, setFocusEvidence] = useState<string | null>(null);
  const [demoBusy, setDemoBusy] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [newCaseOpen, setNewCaseOpen] = useState(false);
  const [newCaseName, setNewCaseName] = useState("");

  const graph = useMemo(() => buildThreatGraph(caseFile), [caseFile]);
  const findingCount = caseFile.scans.reduce((a, s) => a + s.findings.length, 0);

  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(null), 6000);
    return () => clearTimeout(timer);
  }, [toast]);

  const clearFocus = useCallback(() => setFocusEvidence(null), []);

  const runDemo = async () => {
    setDemoBusy(true);
    try {
      const result = await seedDemoCase();
      setPage("overview");
      setToast(
        `Demo case ready — ${result.added} exhibits analysed, ${result.scan.findings.length} application findings, ${
          buildThreatGraph(activeCase()).paths.length
        } attack paths.`
      );
    } catch (err) {
      setToast(`Demo generation failed: ${String(err)}`);
    } finally {
      setDemoBusy(false);
    }
  };

  const navCount = (p: Page): number | null => {
    if (p === "evidence") return caseFile.evidence.length;
    if (p === "web") return caseFile.audits?.length ?? 0;
    if (p === "scanner") return findingCount;
    if (p === "paths" || p === "link") return graph.paths.length;
    if (p === "ledger") return caseFile.evidence.length;
    return null;
  };

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">ACT</div>
          <div>
            <div className="brand-name">A.C.T Forensics</div>
            <div className="brand-sub">AI Cyber &amp; Evidence Lab</div>
          </div>
        </div>

        <div>
          <div className="nav-label">Workspace</div>
          <nav className="nav">
            {NAV.map((p) => (
              <button
                key={p}
                type="button"
                className={`nav-item ${page === p ? "active" : ""}`}
                onClick={() => setPage(p)}
              >
                <Icon name={pageMeta[p].icon} />
                {pageMeta[p].label}
                {navCount(p) ? <span className="nav-count">{navCount(p)}</span> : null}
              </button>
            ))}
          </nav>
        </div>

        <div className="sidebar-foot">
          <div className="case-card">
            <div className="ref">{caseFile.reference}</div>
            <select value={caseFile.id} onChange={(e) => setActiveCase(e.target.value)} aria-label="Active case">
              {state.cases.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
          <button className="btn btn-sm" type="button" onClick={() => setNewCaseOpen(true)}>
            <Icon name="plus" size={13} /> New case
          </button>
          <button className="btn btn-sm btn-ghost" type="button" onClick={runDemo} disabled={demoBusy}>
            <Icon name="spark" size={13} /> {demoBusy ? "Building…" : "Load demo"}
          </button>
          <div className="legend">
            LOCAL ANALYSIS ENGINE
            <br />
            SHA-256 · STATEMENT OF LIMITS
          </div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div className="crumbs">
            Case <b>{caseFile.reference}</b> <span>/</span> <b>{pageMeta[page].label}</b>
          </div>
          <div className="topbar-spacer" />
          <div className="topbar-status">
            <span className="dot" /> Analysis engine ready · runs on this device
          </div>
          <span className="chip">{caseFile.evidence.length} exhibits</span>
          <button className="btn btn-sm btn-primary" type="button" onClick={() => setNewCaseOpen(true)}>
            <Icon name="plus" size={13} /> New case
          </button>
        </header>

        <div className="content">
          {page === "overview" && (
            <Overview
              onNavigate={setPage}
              onDemo={runDemo}
              demoBusy={demoBusy}
              onOpenEvidence={(id) => {
                setFocusEvidence(id);
                setPage("evidence");
              }}
            />
          )}
          {page === "evidence" && <EvidenceLab focusId={focusEvidence} onConsumed={clearFocus} />}
          {page === "web" && <WebsiteScanner />}
          {page === "scanner" && <Scanner />}
          {page === "paths" && <AttackPaths />}
          {page === "link" && <ThreatLink />}
          {page === "ledger" && <Ledger />}
          {page === "report" && <Report />}
        </div>
      </main>

      {newCaseOpen && (
        <div className="modal-backdrop" onClick={() => setNewCaseOpen(false)}>
          <div className="modal" style={{ width: 480 }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-head">
              <Icon name="plus" />
              <div style={{ flex: 1 }}>
                <h2 style={{ fontSize: 16 }}>Open a new case</h2>
                <div className="tiny muted" style={{ marginTop: 3 }}>
                  Exhibits, scans and the integrity ledger are scoped per case.
                </div>
              </div>
              <button className="close-btn" type="button" onClick={() => setNewCaseOpen(false)}>
                <Icon name="close" size={14} />
              </button>
            </div>
            <div className="modal-body stack">
              <div className="field">
                <span>Case name</span>
                <input
                  className="input"
                  autoFocus
                  placeholder="e.g. Riverside extortion — exhibits"
                  value={newCaseName}
                  onChange={(e) => setNewCaseName(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && newCaseName.trim()) {
                      createCase(newCaseName);
                      setNewCaseName("");
                      setNewCaseOpen(false);
                      setPage("evidence");
                      setToast("New case opened. Add exhibits to begin.");
                    }
                  }}
                />
              </div>
              <div className="row" style={{ justifyContent: "flex-end" }}>
                <button className="btn btn-ghost" type="button" onClick={() => setNewCaseOpen(false)}>
                  Cancel
                </button>
                <button
                  className="btn btn-primary"
                  type="button"
                  disabled={!newCaseName.trim()}
                  onClick={() => {
                    createCase(newCaseName);
                    setNewCaseName("");
                    setNewCaseOpen(false);
                    setPage("evidence");
                    setToast("New case opened. Add exhibits to begin.");
                  }}
                >
                  Create case
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}
