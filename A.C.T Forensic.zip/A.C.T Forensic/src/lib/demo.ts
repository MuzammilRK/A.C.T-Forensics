import type { EvidenceItem, ScanResult } from "./types";
import { addEvidence, addScan, createCase, setPosture, updateCase } from "./store";
import { analyzeFile } from "./scanFile";
import { sampleVulnerableSource, scanSource } from "./vuln";
import { uid } from "./hash";

/** A self-contained demo case so judges can see every module without preparing files. */

function canvasBlob(width: number, height: number): Promise<Blob> {
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d")!;
  const sky = ctx.createLinearGradient(0, 0, 0, height);
  sky.addColorStop(0, "#1b2a4a");
  sky.addColorStop(0.45, "#7a4f7d");
  sky.addColorStop(0.75, "#c9785f");
  sky.addColorStop(1, "#3a2b3f");
  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, width, height);

  ctx.fillStyle = "#ffd9a0";
  ctx.beginPath();
  ctx.arc(width * 0.68, height * 0.42, 58, 0, Math.PI * 2);
  ctx.fill();

  // Deliberately cloned vegetation clusters: triggers the copy-move detector.
  const tree = (x: number, y: number, s: number) => {
    ctx.fillStyle = "#14202b";
    ctx.fillRect(x - 3 * s, y, 6 * s, 26 * s);
    ctx.fillStyle = "#1f3b34";
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.arc(x, y - i * 9 * s, (20 - i * 4) * s, 0, Math.PI * 2);
      ctx.fill();
    }
  };
  for (let i = 0; i < 7; i++) tree(70 + i * 118, height - 110, 1.4);
  for (let i = 0; i < 4; i++) tree(150 + i * 200, height - 190, 1.05);

  ctx.fillStyle = "rgba(10, 14, 20, 0.55)";
  ctx.fillRect(0, height - 60, width, 60);
  ctx.fillStyle = "rgba(255,255,255,0.10)";
  ctx.fillRect(0, height - 60, width, 2);

  return new Promise((resolve) => canvas.toBlob((b) => resolve(b!), "image/jpeg", 0.94));
}

/**
 * Demo fixture: writes a Content Credentials style XMP block into the JPEG so
 * the provenance reader has something to show. This is synthetic demo data —
 * the image itself is drawn on a canvas below.
 */
async function stampDemoProvenance(jpeg: Blob): Promise<Blob> {
  const bytes = new Uint8Array(await jpeg.arrayBuffer());
  if (bytes[0] !== 0xff || bytes[1] !== 0xd8) return jpeg;
  const xmp = `<x:xmpmeta xmlns:x="adobe:ns:meta/"><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"><rdf:Description rdf:about="" xmlns:xmp="http://ns.adobe.com/xap/1.0/" xmlns:Iptc4xmpExt="http://iptc.org/std/Iptc4xmpExt/2008-02-29/" xmp:CreatorTool="DALL-E 3 (OpenAI image generation)" Iptc4xmpExt:DigitalSourceType="http://cv.iptc.org/newscodes/digitalsourcetype/trainedAlgorithmicMedia"><xmp:History><rdf:Seq><rdf:li stEvt:action="c2pa.created" xmlns:stEvt="http://ns.adobe.com/xap/1.0/sType/ResourceEvent#"/><rdf:li stEvt:action="c2pa.edited" xmlns:stEvt="http://ns.adobe.com/xap/1.0/sType/ResourceEvent#"/></rdf:Seq></xmp:History></rdf:Description></rdf:RDF></x:xmpmeta>`;
  const header = "http://ns.adobe.com/xap/1.0/\u0000";
  const payload = new TextEncoder().encode(header + xmp);
  const segment = new Uint8Array(4 + payload.length);
  segment[0] = 0xff;
  segment[1] = 0xe1;
  const length = payload.length + 2;
  segment[2] = (length >> 8) & 0xff;
  segment[3] = length & 0xff;
  segment.set(payload, 4);
  return new Blob([bytes.subarray(0, 2), segment, bytes.subarray(2)], { type: "image/jpeg" });
}

function makeWav(): Blob {
  const sr = 44100;
  const seconds = 3.2;
  const count = Math.floor(sr * seconds);
  const buffer = new ArrayBuffer(44 + count * 2);
  const view = new DataView(buffer);
  const write = (offset: number, text: string) => {
    for (let i = 0; i < text.length; i++) view.setUint8(offset + i, text.charCodeAt(i));
  };
  write(0, "RIFF");
  view.setUint32(4, 36 + count * 2, true);
  write(8, "WAVE");
  write(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sr, true);
  view.setUint32(28, sr * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  write(36, "data");
  view.setUint32(40, count * 2, true);
  for (let i = 0; i < count; i++) {
    const t = i / sr;
    const env = 0.5 + 0.5 * Math.sin(2 * Math.PI * 0.7 * t);
    const v =
      0.32 * Math.sin(2 * Math.PI * 220 * t) * env +
      0.18 * Math.sin(2 * Math.PI * 440 * t) * env +
      0.06 * Math.sin(2 * Math.PI * 660 * t) +
      0.02 * Math.sin(2 * Math.PI * 5000 * t);
    view.setInt16(44 + i * 2, Math.max(-1, Math.min(1, v)) * 0x7fff, true);
  }
  return new Blob([buffer], { type: "audio/wav" });
}

const DEMO_DOCUMENT = `In today's fast-paced digital landscape, the integrity of digital evidence is paramount. It is important to note that forensic examiners must navigate a multifaceted ecosystem of devices, applications, and third-party libraries. Furthermore, the ever-evolving threat landscape underscores the need for robust and seamless verification workflows that foster trust across the entire chain of custody.

Moreover, modern evidence pipelines leverage cutting-edge hashing algorithms to ensure that artefacts remain tamper-evident. Additionally, automated analysis plays a pivotal role in identifying subtle manipulation indicators, and it is essential that investigators document every step of the process. Consequently, the platform facilitates a holistic approach to cyber forensics that empowers examiners, courts, and financial institutions alike.

It is worth noting that generative models can synthesise convincing media with remarkable speed. However, manual review alone cannot keep pace with this transformative shift — a seamless integration of statistical checks and cryptographic verification is crucial. In conclusion, a robust, multifaceted framework represents a testament to the importance of trust, transparency, and accountability in the digital realm.

It is imperative that organisations remain vigilant in this ever-evolving landscape. Firstly, examiners should adopt robust verification protocols; secondly, they must ensure that every artefact is logged in a seamless and transparent manner. Furthermore, a multifaceted approach plays a vital role in safeguarding public trust, and it is essential that stakeholders collaborate to unlock the full potential of digital forensics.`;

export interface DemoResult {
  caseId: string;
  added: number;
  scan: ScanResult;
}

export async function seedDemoCase(): Promise<DemoResult> {
  const caseId = createCase("Demo — Operation Nightingale");
  updateCase(caseId, (c) => ({
    ...c,
    reference: `ACT-${new Date().getFullYear()}-DEMO`,
    posture: {
      https: true,
      mfa: false,
      rateLimit: false,
      strongPasswords: true,
      waf: true,
      sessionExpiry: false,
      leastPrivilege: false,
      logging: true,
      encryptionAtRest: false,
      dependencyScanning: false,
    },
  }));

  const image = await stampDemoProvenance(await canvasBlob(960, 640));
  const files: File[] = [
    new File([image], "scene_0142_north_pier.jpg", { type: "image/jpeg" }),
    new File([DEMO_DOCUMENT], "witness_statement_draft.txt", { type: "text/plain" }),
    new File([sampleVulnerableSource()], "legacy_evidence_portal.js", { type: "text/javascript" }),
    new File([makeWav()], "interview_clip_01.wav", { type: "audio/wav" }),
  ];

  const { mediaCache } = await import("./store");
  let added = 0;
  for (const file of files) {
    try {
      const { hash, kind, analysis } = await analyzeFile(file);
      const item: EvidenceItem = {
        id: uid("ev"),
        name: file.name,
        mime: file.type,
        size: file.size,
        kind,
        hash,
        hashAt: new Date().toISOString(),
        addedAt: new Date().toISOString(),
        analysis,
        source: "demo",
      };
      mediaCache.set(item.id, file);
      addEvidence(caseId, item);
      added++;
    } catch (err) {
      console.error("demo evidence failed", file.name, err);
    }
  }

  const source = sampleVulnerableSource();
  const scanBase = scanSource(source, "legacy_evidence_portal.js");
  const scan: ScanResult = {
    id: uid("scan"),
    kind: "source",
    target: "legacy_evidence_portal.js",
    createdAt: new Date().toISOString(),
    score: scanBase.score,
    grade: scanBase.grade,
    findings: scanBase.findings,
    stats: scanBase.stats,
  };
  addScan(caseId, scan);
  setPosture(caseId, {
    https: true,
    mfa: false,
    rateLimit: false,
    strongPasswords: true,
    waf: true,
    sessionExpiry: false,
    leastPrivilege: false,
    logging: true,
    encryptionAtRest: false,
    dependencyScanning: false,
  });

  return { caseId, added, scan };
}
