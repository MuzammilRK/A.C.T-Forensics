import type { Analysis, EvidenceKind, ForensicCheck, Signal } from "./types";
import { clamp, sha256 } from "./hash";
import { detectMagic } from "./meta";
import { analyzeImage } from "./image";
import { analyzeAudio, analyzeVideo } from "./media";
import { extractDocument } from "./docs";
import { analyzeText } from "./text";
import { scanSource } from "./vuln";
import { inspectInvisibleText, scanBinaryProvenance } from "./watermark";

const CODE_EXT = new Set([
  "js", "jsx", "ts", "tsx", "py", "php", "rb", "java", "cs", "go", "rs", "c", "cpp", "sql", "sh", "yml", "yaml", "tf", "env", "conf", "json",
]);
const TEXT_EXT = new Set(["txt", "md", "csv", "log", "rtf", "html", "xml"]);

export function extensionOf(name: string): string {
  return name.split(".").pop()?.toLowerCase() ?? "";
}

export function kindFrom(file: File, magic: ReturnType<typeof detectMagic>): EvidenceKind {
  const mime = file.type.toLowerCase();
  if (mime.startsWith("image/")) return "image";
  if (mime.startsWith("video/")) return "video";
  if (mime.startsWith("audio/")) return "audio";
  if (["jpeg", "png", "gif", "webp", "bmp"].includes(magic.kind)) return "image";
  if (["mp4", "mov"].includes(magic.kind)) return "video";
  if (["wav", "mp3", "ogg"].includes(magic.kind)) return "audio";
  if (["pdf", "docx", "zip"].includes(magic.kind)) return "document";
  const ext = extensionOf(file.name);
  if (CODE_EXT.has(ext)) return "code";
  if (TEXT_EXT.has(ext) || mime.startsWith("text/")) return "document";
  return "unknown";
}

export interface AnalysisBundle {
  hash: string;
  kind: EvidenceKind;
  analysis: Analysis;
}

export async function analyzeFile(
  file: File,
  onProgress?: (message: string, percent: number) => void
): Promise<AnalysisBundle> {
  const buffer = await file.arrayBuffer();
  const bytes = new Uint8Array(buffer);
  const magic = detectMagic(bytes);
  const kind = kindFrom(file, magic);
  onProgress?.("Fingerprinting the file with SHA-256", 20);
  const hash = await sha256(buffer);

  if (kind === "image") {
    onProgress?.("Reading the image's own metadata and watermark record", 45);
    onProgress?.("Measuring compression, noise and duplicated texture", 70);
    try {
      const analysis = await analyzeImage(file, file.name);
      onProgress?.("Analysis complete", 100);
      return { hash, kind, analysis };
    } catch (err) {
      return { hash, kind, analysis: fallback(file, kind, `Image decoding failed: ${String(err)}`) };
    }
  }

  if (kind === "video") {
    onProgress?.("Reading container provenance and sampling frames", 55);
    try {
      const analysis = await analyzeVideo(file, file.name);
      onProgress?.("Analysis complete", 100);
      return { hash, kind, analysis };
    } catch (err) {
      return { hash, kind, analysis: fallback(file, kind, `Video decoding failed: ${String(err)}`) };
    }
  }

  if (kind === "audio") {
    onProgress?.("Decoding the waveform and measuring its spectrum", 55);
    try {
      const analysis = await analyzeAudio(file, file.name);
      onProgress?.("Analysis complete", 100);
      return { hash, kind, analysis };
    } catch (err) {
      return { hash, kind, analysis: fallback(file, kind, `Audio decoding failed: ${String(err)}`) };
    }
  }

  if (kind === "code") {
    onProgress?.("Scanning source for exploitable patterns", 50);
    const text = new TextDecoder().decode(bytes);
    const scan = scanSource(text, file.name);
    const signals: Signal[] = scan.findings.slice(0, 6).map((f) => ({
      id: f.id,
      label: `${f.severity.toUpperCase()} — ${f.title}`,
      strength: clamp(f.weight * 8, 0, 100) / 100,
      detail: `${f.detail} Fix: ${f.fix}`,
      tone: f.severity === "critical" || f.severity === "high" ? "risk" : "neutral",
    }));
    if (!signals.length) {
      signals.push({
        id: "clean",
        label: "No known vulnerability pattern matched",
        strength: 0,
        detail: "The source did not match the platform's 20 rules. That is not proof of security — it means nothing obvious was found.",
        tone: "good",
      });
    }
    const invisible = inspectInvisibleText(text);
    onProgress?.("Analysis complete", 100);
    return {
      hash,
      kind,
      analysis: {
        kind,
        aiLikelihood: scan.score,
        verdict:
          scan.score >= 65
            ? "Source carries serious exploitable weaknesses"
            : scan.score >= 35
            ? "Source carries moderate weaknesses"
            : "No high-risk patterns detected in source",
        confidence: 74,
        plain:
          scan.score >= 65
            ? `This file has ${scan.findings.length} weakness(es) a real attacker could use. Each one is listed with a fix.`
            : `No high-risk weakness was found in this file. ${scan.findings.length} lower-priority note(s) are listed for completeness.`,
        summary: `${file.name}: ${scan.findings.length} finding(s), risk ${scan.score}/100 (grade ${scan.grade}).`,
        signals,
        metadata: {
          Language: extensionOf(file.name).toUpperCase(),
          "Lines of code": String(text.split(/\r?\n/).length),
          Findings: String(scan.findings.length),
          "Risk grade": scan.grade,
        },
        checks: [
          { id: "source", name: "Rules applied", status: "pass", metric: `${scan.stats["Rules evaluated"]} rules`, detail: "Injection, auth, secrets, transport, upload and access-control patterns are matched line by line." },
          { id: "visual", name: "Findings", status: scan.score >= 65 ? "fail" : scan.findings.length ? "warn" : "pass", metric: `${scan.findings.length}`, detail: "Open Application Scan for the line, the reason and the exact fix." },
          { id: "watermark", name: "Hidden characters", status: invisible.length ? "warn" : "pass", metric: `${invisible.length}`, detail: "Source files can hide invisible payloads too; this check counts them." },
        ],
        provenance: {
          verdict: "unknown",
          headline: "Source file — provenance not applicable",
          plain: "This is code, not media. Its risk is measured by what an attacker can do with it.",
          confidence: 0,
          device: null,
          software: null,
          signed: false,
          aiDeclared: false,
          hits: invisible,
        },
        excerpt: text.slice(0, 6000),
        notes: ["Open Application Scan with this source to see the fixes and how each weakness chains into an attack path."],
      },
    };
  }

  const isPlainText =
    kind === "document" && (file.type.startsWith("text/") || TEXT_EXT.has(extensionOf(file.name)));
  const formatLabel = isPlainText ? "Plain text" : magic.label;

  if ((magic.kind === "unknown" && !isPlainText) || magic.kind === "zip") {
    const isArchive = magic.kind === "zip";
    onProgress?.("Registering container", 90);
    return {
      hash,
      kind: "document",
      analysis: {
        kind: "document",
        aiLikelihood: 6,
        verdict: isArchive ? "Archive registered — contents not inspected" : "Unsupported format — fingerprint recorded",
        confidence: 30,
        plain: isArchive
          ? "This is a ZIP archive. Its fingerprint is recorded, but the files inside must be analysed one by one."
          : "This file type could not be read, so no claim is made about its content. Its fingerprint is still recorded.",
        summary: isArchive
          ? `${file.name}: ZIP archive hashed and registered.`
          : `${file.name}: container not recognised; content analysis skipped.`,
        signals: [
          {
            id: "opaque",
            label: isArchive ? "Archive container" : "Unrecognised binary",
            strength: 0.2,
            detail: isArchive
              ? "Extract the archive and add its files individually for content analysis."
              : "The first bytes do not match a supported image, video, audio, PDF, DOCX or text format.",
            tone: "neutral",
          },
        ],
        metadata: {
          "Detected format": magic.label,
          "File size": `${(file.size / 1024).toFixed(1)} KB`,
          "Declared type": file.type || "unknown",
        },
        checks: [{ id: "source", name: "Content", status: "na", metric: "not parsed", detail: "Integrity checking still applies: re-hashing detects any byte-level change." }],
        notes: ["Integrity verification still applies: re-hashing detects any byte-level change."],
      },
    };
  }

  onProgress?.("Extracting text and provenance from the document", 45);
  const isPdfLike = magic.kind === "pdf" || magic.kind === "docx";
  const doc =
    isPdfLike || kind === "document"
      ? extractDocument(bytes, magic.kind, file.type)
      : { text: "", metadata: {}, method: "none", notes: [] as string[] };

  const prov = scanBinaryProvenance(bytes, file.type || magic.mime);
  const invisible = inspectInvisibleText(doc.text);
  const words = doc.text.split(/\s+/).filter(Boolean).length;
  const textResult = words >= 40 ? analyzeText(doc.text) : null;
  const signals: Signal[] = [];
  let score = textResult?.aiLikelihood ?? 12;
  let verdict = textResult?.verdict ?? "Not enough text to judge authorship";
  let confidence = textResult?.confidence ?? 34;

  if (textResult) {
    signals.push(...textResult.signals);
    if (words < 120) {
      signals.push({
        id: "short",
        label: "Short sample",
        strength: 0.3,
        detail: `Only ${words} words were recovered. Short documents give weaker authorship signals, so this percentage is less reliable.`,
        tone: "neutral",
      });
    }
  } else {
    signals.push({
      id: "notext",
      label: "No readable text",
      strength: 0.2,
      detail:
        magic.kind === "pdf"
          ? "This PDF is a scan with no text layer. OCR is needed before authorship can be judged."
          : "No meaningful text could be extracted from this file.",
      tone: "neutral",
    });
  }

  // Human drafting evidence: an author name, revision counter and creation/modification stamps.
  const humanMetadata = /Document author metadata|Revision counter|Last modified metadata|Produced by application tag/i.test(
    doc.notes.join(" ")
  );
  if (humanMetadata && score < 70) {
    score = clamp(score - 14);
    signals.push({
      id: "authorship",
      label: "Document history names a human author",
      strength: 0.5,
      detail: "The file carries an author name, revision counter or modification history — the residue of a person drafting in an office suite.",
      tone: "good",
    });
  }

  const generatorHint = prov.aiGenerator ?? prov.hits.find((h) => h.kind === "ai-label")?.label ?? null;
  if (generatorHint) {
    score = clamp(score + 22);
    signals.push({
      id: "producer",
      label: `Producer metadata references ${generatorHint}`,
      strength: 0.7,
      detail: "The document's producer or creator field names a generative tool. That is provenance, not a writing-style guess.",
      tone: "risk",
    });
  }

  if (invisible.length) {
    score = clamp(score + Math.min(30, invisible.reduce((a, h) => a + h.strength * 0.3, 0)));
    for (const h of invisible) {
      signals.push({ id: h.id, label: h.label, strength: h.strength / 100, detail: `${h.meaning} Evidence: ${h.evidence}`, tone: h.tone });
    }
  }

  const active = doc.notes.filter((n) => /JavaScript|Launch|OpenAction|macros/i.test(n));
  if (active.length) {
    signals.push({
      id: "active",
      label: "Active content inside the document",
      strength: 0.85,
      detail: `${active.join(" ")} This is a delivery risk, not an authorship signal.`,
      tone: "risk",
    });
  }

  if (!doc.text && !isPdfLike) verdict = "Binary container — provenance recorded, content not readable";
  else if (textResult && score >= 70) verdict = "Strong AI-authorship indicators";
  else if (textResult && score >= 45) verdict = "Mixed authorship signals";
  else if (textResult) verdict = "Reads like human writing";

  const checks: ForensicCheck[] = [
    {
      id: "source",
      name: "Producer record",
      status: generatorHint ? "fail" : humanMetadata ? "pass" : "warn",
      metric: generatorHint ?? (doc.metadata.Producer || doc.metadata.Creator || "not recorded"),
      detail: generatorHint
        ? "The producer field names a generative tool."
        : "The software that exported the document. Office suites and PDF printers each leave a distinct signature.",
    },
    {
      id: "visual",
      name: "Writing style",
      status: textResult ? (score >= 70 ? "warn" : "pass") : "na",
      metric: textResult ? `${words} words` : "no text layer",
      detail: "Phrasing, sentence rhythm and vocabulary are compared with known machine-writing patterns. This is the weakest of the checks on its own.",
    },
    {
      id: "watermark",
      name: "Hidden text",
      status: invisible.length ? "warn" : "pass",
      metric: `${invisible.length} hidden marker(s)`,
      detail: "Zero-width characters, Unicode tag characters and assistant boilerplate are invisible to a reader but readable to a script.",
    },
    {
      id: "temporal",
      name: "Revision history",
      status: humanMetadata ? "pass" : "na",
      metric: humanMetadata ? "author + revisions" : "not present",
      detail: "An author name and edit count are hard to fake accidentally and suggest a person worked on the file.",
    },
    {
      id: "compression",
      name: "Active content",
      status: active.length ? "fail" : "pass",
      metric: active.length ? `${active.length} item(s)` : "none",
      detail: "Embedded scripts, launch actions and macros can run code when the document is opened.",
    },
  ];

  onProgress?.("Analysis complete", 100);
  return {
    hash,
    kind: kind === "unknown" ? "document" : kind,
    analysis: {
      kind: kind === "unknown" ? "document" : kind,
      aiLikelihood: score,
      verdict,
      confidence,
      plain:
        score >= 70
          ? "Several independent signals agree that this document was probably written by an AI. Read the signals before relying on it."
          : score >= 45
          ? "The writing shows some machine-like patterns, but not enough to call it AI. Formal human writing often looks like this."
          : generatorHint
          ? "No strong writing-style signals, but the file's producer metadata names a generative tool."
          : "Nothing in the writing style or the file's hidden text points to AI generation. That is an absence of evidence, not proof of human authorship.",
      summary: `${file.name}: ${verdict.toLowerCase()}. ${words ? `${words} words analysed.` : "No text layer recovered."}`,
      signals,
      metadata: {
        "Detected format": formatLabel,
        "Extraction method": doc.method,
        "Words extracted": String(words),
        "File size": `${(file.size / 1024).toFixed(1)} KB`,
        ...doc.metadata,
      },
      sentences: textResult?.sentences,
      excerpt: doc.text.slice(0, 6000),
      provenance: {
        verdict: generatorHint ? "synthetic" : humanMetadata ? "authentic-capture" : "unknown",
        headline: generatorHint
          ? `Producer metadata names ${generatorHint}`
          : humanMetadata
          ? "Document history names a human author"
          : "No producer identity in the file",
        plain: generatorHint
          ? "The file itself says which tool produced it."
          : "Document producers are easy to strip and easy to fake. Treat this as context for the writing-style result.",
        confidence: generatorHint ? 85 : 55,
        device: null,
        software: doc.metadata.Producer ?? doc.metadata.Creator ?? null,
        signed: false,
        aiDeclared: !!generatorHint,
        hits: [...prov.hits.filter((h) => h.tone !== "neutral").slice(0, 4), ...invisible],
      },
      checks,
      notes: [...doc.notes, ...(textResult ? [] : ["Authorship analysis was skipped: there was not enough readable text."])],
    },
  };
}

function fallback(file: File, kind: EvidenceKind, message: string): Analysis {
  return {
    kind,
    aiLikelihood: 5,
    verdict: "Automatic analysis incomplete",
    confidence: 15,
    plain: "The file could not be decoded here, so no conclusion is drawn about its content. Its fingerprint is still recorded.",
    summary: `${file.name}: ${message}`,
    signals: [{ id: "error", label: "Decoder unavailable", strength: 0.2, detail: message, tone: "neutral" }],
    metadata: { "File size": `${(file.size / 1024).toFixed(1)} KB`, "Declared type": file.type || "unknown" },
    checks: [{ id: "source", name: "Decode", status: "na", metric: "failed", detail: message }],
    notes: ["Convert the file to a format this browser supports, or open it in its native application."],
  };
}
