import type { Severity, WebFinding, WebsiteAudit } from "./types";
import { uid } from "./hash";
import { scanSource } from "./vuln";

/**
 * Website security audit.
 *
 * The page is fetched and read the way a browser reads it: every script, form,
 * comment, header and linked resource is inspected. Nothing is exploited and no
 * login is attempted — this is a source-code review, which is what a security
 * researcher does first.
 */

export interface FetchedPage {
  html: string;
  via: string;
  finalUrl: string;
  headers: Record<string, string>;
  bytes: number;
}

export function normalizeUrl(input: string): string {
  const trimmed = input.trim();
  if (!trimmed) return "";
  const withScheme = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  try {
    const u = new URL(withScheme);
    if (!u.hostname.includes(".")) return "";
    return u.toString();
  } catch {
    return "";
  }
}

const PROXIES: { name: string; build: (u: string) => string }[] = [
  { name: "direct", build: (u) => u },
  { name: "allorigins", build: (u) => `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}` },
  { name: "codetabs", build: (u) => `https://api.codetabs.com/v1/proxy/?quest=${encodeURIComponent(u)}` },
  { name: "corsproxy.io", build: (u) => `https://corsproxy.io/?url=${encodeURIComponent(u)}` },
];

/**
 * Fetches the page with the first source that answers.
 * Browsers refuse cross-origin reads, so a small public relay is tried in
 * parallel; whichever replies first wins and the rest are cancelled. When every
 * source is blocked, the caller falls back to a saved page or pasted source.
 */
export async function fetchSiteHtml(url: string): Promise<FetchedPage> {
  const controllers: AbortController[] = [];
  const errors: string[] = [];

  const attempt = async (proxy: (typeof PROXIES)[number]): Promise<FetchedPage> => {
    const controller = new AbortController();
    controllers.push(controller);
    const timer = setTimeout(() => controller.abort(), 9000);
    try {
      const response = await fetch(proxy.build(url), {
        signal: controller.signal,
        redirect: "follow",
        headers: proxy.name === "direct" ? { Accept: "text/html,application/xhtml+xml" } : {},
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const text = await response.text();
      if (!/<html|<body|<!doctype/i.test(text.slice(0, 4000))) throw new Error("response was not HTML");
      const headers: Record<string, string> = {};
      if (proxy.name === "direct") {
        response.headers.forEach((value, key) => {
          headers[key.toLowerCase()] = value;
        });
      }
      return {
        html: text,
        via: proxy.name === "direct" ? "direct browser fetch" : `via ${proxy.name}`,
        finalUrl: url,
        headers,
        bytes: new Blob([text]).size,
      };
    } finally {
      clearTimeout(timer);
    }
  };

  const results = PROXIES.map((proxy) =>
    attempt(proxy).catch((err: unknown) => {
      errors.push(`${proxy.name}: ${err instanceof Error ? err.message : "failed"}`);
      throw err;
    })
  );

  try {
    const page = await Promise.any(results);
    controllers.forEach((c) => c.abort());
    return page;
  } catch {
    throw new Error(
      `This site could not be read from the browser. Browsers block cross-origin reads, and the public relays did not answer (${errors.join(
        "; "
      )}). Save the page with Ctrl+S and upload the .html file below, or paste its source.`
    );
  }
}

/** A deliberately flawed page so the auditor can be demonstrated without a network. */
export const SAMPLE_PAGE_HTML = `<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><title>Alder Street Dental — patient portal</title>
<meta name="generator" content="WordPress 5.2.3">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://cdn.alder-demo.example/bootstrap/3.3.7/css/bootstrap.min.css">
</head><body>
<!-- TODO: remove staging credentials before launch - admin / Alder2019! - db at 10.0.4.12 -->
<nav><a href="/wp-admin">Staff login</a><a href="/.git/config">Site source</a><a href="/backup.zip">Backup</a></nav>
<main>
  <h1>Book an appointment</h1>
  <form method="get" action="/search">
    <input type="text" name="q" placeholder="Search patients">
    <input type="password" name="pin" autocomplete="on" placeholder="Patient PIN">
    <button type="submit">Search</button>
  </form>
  <div id="results"></div>
  <a href="http://alder-demo.example/portal" target="_blank">Old portal</a>
  <iframe src="http://widgets.tracker-demo.example/frame" width="300" height="150"></iframe>
</main>
<script src="http://cdn.alder-demo.example/jquery-1.12.4.min.js"></script>
<script>
  var apiKey = "AIzaSyD5hT9demoKeyNotReal0000000000000";
  var params = new URLSearchParams(location.search);
  document.getElementById('results').innerHTML = params.get('q');
  eval(params.get('mode') || 'void 0');
  console.log('token', apiKey);
</script>
</body></html>`;

const SEV: Record<Severity, number> = { critical: 15, high: 10, medium: 6, low: 3, info: 1 };

const HEADER_RULES: { name: string; sev: Severity; why: string; fix: string; aliases?: string[] }[] = [
  {
    name: "content-security-policy",
    sev: "high",
    why: "Without CSP, any injected script runs with full access to the page and its session.",
    fix: "Add a CSP that forbids inline script and only allows your own origins for script-src.",
  },
  {
    name: "strict-transport-security",
    sev: "medium",
    why: "Without HSTS, a network attacker can downgrade the first visit to plain HTTP and read the traffic.",
    fix: "Send Strict-Transport-Security: max-age=31536000; includeSubDomains; preload.",
  },
  {
    name: "x-frame-options",
    sev: "medium",
    why: "Without frame protection the site can be embedded invisibly and used for clickjacking.",
    fix: "Send X-Frame-Options: DENY (or frame-ancestors 'none' in CSP).",
    aliases: ["content-security-policy"],
  },
  {
    name: "x-content-type-options",
    sev: "low",
    why: "Browsers may guess a file's type and run a text file as a script.",
    fix: "Send X-Content-Type-Options: nosniff.",
  },
  {
    name: "referrer-policy",
    sev: "low",
    why: "Full URLs (which may contain tokens) leak to other sites through the Referer header.",
    fix: "Send Referrer-Policy: strict-origin-when-cross-origin.",
  },
  {
    name: "permissions-policy",
    sev: "low",
    why: "Camera, microphone and location stay available to any script without a policy.",
    fix: "Send Permissions-Policy denying features the site does not use.",
  },
];

const SECRET_PATTERNS: { re: RegExp; label: string; sev: Severity }[] = [
  { re: /\bAKIA[0-9A-Z]{16}\b/, label: "AWS access key ID", sev: "critical" },
  { re: /\bsk_live_[0-9a-zA-Z]{16,}\b/, label: "Stripe live secret key", sev: "critical" },
  { re: /\bsk-[A-Za-z0-9]{32,}\b/, label: "OpenAI-style API key", sev: "critical" },
  { re: /\bAIza[0-9A-Za-z\-_]{30,}\b/, label: "Google API key", sev: "high" },
  { re: /\bghp_[0-9A-Za-z]{30,}\b|\bgithub_pat_/, label: "GitHub token", sev: "critical" },
  { re: /\bxox[baprs]-[0-9A-Za-z-]{10,}\b/, label: "Slack token", sev: "critical" },
  { re: /-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----/, label: "Private key", sev: "critical" },
  { re: /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{6,}\b/, label: "JWT exposed in page source", sev: "high" },
  { re: /(password|passwd|pwd)\s*[:=]\s*["'][^"']{4,}["']/i, label: "Password literal in page source", sev: "high" },
  { re: /(api[_-]?key|apikey|access[_-]?token)\s*[:=]\s*["'][A-Za-z0-9_\-]{16,}["']/i, label: "API key assigned in page source", sev: "high" },
];

const OLD_LIBS: { re: RegExp; label: string; sev: Severity; why: string }[] = [
  { re: /jquery[.-]?([12])\.\d+/i, label: "jQuery 1.x/2.x", sev: "high", why: "Old jQuery versions have public XSS and prototype-pollution exploits." },
  { re: /jquery[.-]?3\.[0-4]\.\d+/i, label: "jQuery below 3.5", sev: "medium", why: "Known HTML-manipulation XSS flaws were fixed in 3.5." },
  { re: /bootstrap[.-]?3\.\d+/i, label: "Bootstrap 3", sev: "medium", why: "Bootstrap 3 is end-of-life and its bundled jQuery is exploitable." },
  { re: /angular(?:\.min)?\.js["'?].*?1\.\d+\.\d+/i, label: "AngularJS 1.x", sev: "high", why: "AngularJS 1.x is end-of-life and has unfixed XSS sandbox escapes." },
  { re: /react@?(?:0|15|16)\./i, label: "React 15/16", sev: "low", why: "Very old React versions miss years of security fixes." },
  { re: /moment[.-]?2\.(?:[0-9]|1[0-9]|2[0-8])\./i, label: "Moment.js before 2.29", sev: "medium", why: "Older Moment.js has a path-traversal advisory in locale loading." },
  { re: /wordpress\s*[0-5]\.\d+/i, label: "Old WordPress", sev: "high", why: "Older WordPress cores have publicly exploited plugin and core holes." },
];

function decodeEntities(s: string): string {
  return s
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#x27;|&#39;/g, "'");
}

function stripTags(html: string): string {
  return html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
}

export interface AuditOptions {
  rawHtml?: string;
  onStep?: (message: string) => void;
}

export async function auditWebsite(input: string, options: AuditOptions = {}): Promise<WebsiteAudit> {
  const url = normalizeUrl(input);
  if (!url) throw new Error("That does not look like a web address. Try example.com or https://example.com/.");

  options.onStep?.("Fetching the page…");
  let page: FetchedPage;
  if (options.rawHtml && options.rawHtml.trim().length > 40) {
    page = { html: options.rawHtml, via: "pasted source", finalUrl: url, headers: {}, bytes: new Blob([options.rawHtml]).size };
  } else {
    page = await fetchSiteHtml(url);
  }
  const { html, headers } = page;
  const host = new URL(page.finalUrl).hostname;
  const headersAvailable = Object.keys(headers).length > 0;

  options.onStep?.("Parsing the document…");
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");

  const findings: WebFinding[] = [];
  const push = (
    title: string,
    severity: Severity,
    category: string,
    evidence: string,
    detail: string,
    fix: string,
    reference: string
  ) => {
    findings.push({
      id: uid("web"),
      title,
      severity,
      category,
      evidence: decodeEntities(evidence).replace(/\s+/g, " ").trim().slice(0, 260),
      detail,
      fix,
      reference,
    });
  };

  const scripts = Array.from(doc.querySelectorAll("script"));
  const externalScripts = scripts.filter((s) => s.getAttribute("src"));
  const inlineScripts = scripts.filter((s) => !s.getAttribute("src") && (s.textContent ?? "").trim());
  const links = Array.from(doc.querySelectorAll("link[href]"));
  const forms = Array.from(doc.querySelectorAll("form"));
  const iframes = Array.from(doc.querySelectorAll("iframe"));
  const anchors = Array.from(doc.querySelectorAll("a[href]"));
  const imgs = Array.from(doc.querySelectorAll("img"));
  const metas = Array.from(doc.querySelectorAll("meta"));
  const allAttrs = Array.from(doc.querySelectorAll("*")).slice(0, 4000);
  const generator = metas.find((m) => (m.getAttribute("name") ?? "").toLowerCase() === "generator")?.getAttribute("content") ?? "";
  const title = doc.querySelector("title")?.textContent?.trim() ?? "";

  const externalHosts = new Set<string>();
  for (const el of [...externalScripts, ...links, ...imgs]) {
    const raw = el.getAttribute("src") ?? el.getAttribute("href") ?? "";
    if (!raw || raw.startsWith("data:") || raw.startsWith("#")) continue;
    try {
      const u = new URL(raw, page.finalUrl);
      if (u.hostname !== host) externalHosts.add(u.hostname);
    } catch {
      /* relative or malformed */
    }
  }

  /* ---------------------------- transport ---------------------------- */
  if (new URL(page.finalUrl).protocol !== "https:") {
    push(
      "Page is served over plain HTTP",
      "critical",
      "Transport",
      page.finalUrl,
      "Everything on this page — passwords, session cookies, form contents — travels unencrypted and can be read or changed on the network.",
      "Serve the site over HTTPS only and redirect all HTTP requests permanently.",
      "CWE-319"
    );
  }

  /* ------------------------- security headers ------------------------ */
  if (headersAvailable) {
    for (const rule of HEADER_RULES) {
      const present = rule.aliases?.some((a) => headers[a]) ?? Boolean(headers[rule.name]);
      if (present) continue;
      push(
        `Missing security header: ${rule.name}`,
        rule.sev,
        "Headers",
        Object.keys(headers).join(", ") || "no headers returned",
        rule.why,
        rule.fix,
        "OWASP Secure Headers"
      );
    }
    const server = headers["server"] ?? "";
    if (server && /\d+\.\d+/.test(server)) {
      push(
        "Server software and version disclosed",
        "low",
        "Information leak",
        `Server: ${server}`,
        "Version banners let an attacker look up exactly which exploits apply to this server.",
        "Remove the version from the Server header (or hide it at the proxy).",
        "CWE-200"
      );
    }
    const powered = headers["x-powered-by"] ?? "";
    if (powered) {
      push(
        "Framework disclosed in X-Powered-By",
        "low",
        "Information leak",
        `X-Powered-By: ${powered}`,
        "Naming the framework and version narrows the attacker's search for known bugs.",
        "Remove X-Powered-By, or set it to a generic value.",
        "CWE-200"
      );
    }
    const cookie = headers["set-cookie"] ?? "";
    if (cookie && !/httponly/i.test(cookie)) {
      push(
        "Session cookie without HttpOnly",
        "high",
        "Session",
        cookie.slice(0, 160),
        "A cookie without HttpOnly is readable by any injected script, so one XSS becomes full account takeover.",
        "Add HttpOnly, Secure and SameSite=Lax (or Strict) to session cookies.",
        "CWE-1004"
      );
    }
  } else {
    push(
      "Response headers could not be inspected",
      "info",
      "Coverage",
      `Fetched ${page.via}`,
      "The page source was read through a proxy, which does not forward response headers. HSTS, CSP, cookie flags and X-Frame-Options are therefore unknown. The source checks below are unaffected.",
      "Run the audit from the same origin, or check headers with curl -I from a terminal.",
      "Coverage limitation"
    );
  }

  const metaCsp = metas.find((m) => (m.getAttribute("http-equiv") ?? "").toLowerCase() === "content-security-policy")?.getAttribute("content");
  if (metaCsp) {
    push(
      "Content-Security-Policy is delivered as a meta tag",
      "low",
      "Headers",
      metaCsp.slice(0, 160),
      "A meta-tag CSP is weaker than a header: it cannot use frame-ancestors, sandbox or report-only, and it arrives after some resources have loaded.",
      "Send CSP as a real HTTP response header.",
      "CSP via meta"
    );
  }

  /* ----------------------- inline / attribute JS --------------------- */
  const inlineHandlers = allAttrs.flatMap((el) =>
    Array.from(el.attributes)
      .filter((a) => /^on[a-z]+$/i.test(a.name))
      .map((a) => `<${el.tagName.toLowerCase()} ${a.name}="${a.value.slice(0, 60)}">`)
  );
  if (inlineHandlers.length) {
    push(
      `${inlineHandlers.length} inline event handler${inlineHandlers.length > 1 ? "s" : ""} in the markup`,
      "medium",
      "Injection",
      inlineHandlers.slice(0, 3).join("  "),
      "Inline handlers are executable JavaScript sitting in HTML. If any user text reaches the page unescaped, it becomes script that runs in the visitor's session.",
      "Move handlers into external JS files and attach them with addEventListener.",
      "CWE-79"
    );
  }

  if (inlineScripts.length && !metaCsp) {
    push(
      `${inlineScripts.length} inline script block${inlineScripts.length > 1 ? "s" : ""} with no CSP`,
      "high",
      "Injection",
      `${inlineScripts.length} inline blocks; first is ${(inlineScripts[0].textContent ?? "").trim().slice(0, 100)}…`,
      "Inline script cannot be allowed selectively without a nonce or hash, so the site cannot deploy a strict CSP — the main defence against XSS — while these exist.",
      "Move inline code to external files and add a nonce-based CSP.",
      "CWE-79"
    );
  }

  const unsafeSinks = html.match(/\b(eval\s*\(|document\.write\s*\(|innerHTML\s*=|dangerouslySetInnerHTML|new\s+Function\s*\()/g) ?? [];
  if (unsafeSinks.length) {
    push(
      "Unsafe HTML/script sinks in page code",
      "high",
      "Injection",
      `${unsafeSinks.length} occurrences: ${Array.from(new Set(unsafeSinks)).join(", ")}`,
      "These functions turn strings into markup or code. If the string contains anything a visitor controls, that visitor can run script on your page.",
      "Use textContent, a templating engine with escaping, or sanitise with DOMPurify.",
      "CWE-79"
    );
  }

  const postMessage = html.match(/addEventListener\(\s*['"]message['"][\s\S]{0,240}/g) ?? [];
  const postMessageUnchecked = postMessage.filter((chunk) => !/\.origin\s*[!=]==?/.test(chunk));
  if (postMessageUnchecked.length) {
    push(
      "postMessage listener without an origin check",
      "high",
      "Injection",
      postMessageUnchecked[0].slice(0, 140),
      "Any page that can frame this one can send it messages. Without checking event.origin, a hostile site can drive the handler.",
      "Compare event.origin against an allow-list and ignore everything else.",
      "CWE-346"
    );
  }

  /* --------------------------- resources ----------------------------- */
  const insecureResources = [...externalScripts, ...links, ...imgs].filter((el) => {
    const raw = el.getAttribute("src") ?? el.getAttribute("href") ?? "";
    return /^http:\/\//i.test(raw);
  });
  if (insecureResources.length) {
    push(
      `${insecureResources.length} resource${insecureResources.length > 1 ? "s" : ""} loaded over plain HTTP`,
      "high",
      "Transport",
      (insecureResources[0].getAttribute("src") ?? insecureResources[0].getAttribute("href") ?? "").slice(0, 160),
      "Mixed content can be swapped in transit. A single HTTP script tag hands script execution to the network.",
      "Load every asset over HTTPS and add upgrade-insecure-requests to the CSP.",
      "CWE-319"
    );
  }

  const scriptsNoSri = externalScripts.filter((s) => {
    const src = s.getAttribute("src") ?? "";
    return !s.getAttribute("integrity") && !src.includes(host) && !src.startsWith("/");
  });
  if (scriptsNoSri.length) {
    push(
      `${scriptsNoSri.length} third-party script${scriptsNoSri.length > 1 ? "s" : ""} without Subresource Integrity`,
      "medium",
      "Supply chain",
      scriptsNoSri.slice(0, 3).map((s) => s.getAttribute("src")).join("  "),
      "If the CDN or library is compromised, the changed file runs in your visitors' browsers. SRI pins the exact file by hash.",
      "Add integrity and crossorigin attributes to every third-party script and stylesheet.",
      "CWE-1104"
    );
  }

  const targetBlank = anchors.filter((a) => a.getAttribute("target") === "_blank" && !/noopener|noreferrer/i.test(a.getAttribute("rel") ?? ""));
  if (targetBlank.length) {
    push(
      `${targetBlank.length} link${targetBlank.length > 1 ? "s" : ""} opening a new tab without rel="noopener"`,
      "low",
      "Injection",
      targetBlank[0].getAttribute("href")?.slice(0, 120) ?? "",
      "The new page can reach back through window.opener and navigate your tab to a phishing page.",
      'Add rel="noopener noreferrer" to every target="_blank" link.',
      "CWE-1022"
    );
  }

  /* ------------------------------ forms ------------------------------ */
  const passwordFields = Array.from(doc.querySelectorAll('input[type="password"]'));
  const getPasswordForm = forms.find(
    (f) => (f.getAttribute("method") ?? "get").toLowerCase() === "get" && f.querySelector('input[type="password"]')
  );
  if (getPasswordForm) {
    push(
      "Password form submits with GET",
      "critical",
      "Authentication",
      getPasswordForm.outerHTML.slice(0, 200),
      "GET puts the password into the URL, browser history, proxies and server logs — where it stays readable.",
      "Submit credentials with POST over HTTPS.",
      "CWE-598"
    );
  }
  const crossOriginForms = forms.filter((f) => {
    const action = f.getAttribute("action") ?? "";
    if (!action) return false;
    try {
      return new URL(action, page.finalUrl).hostname !== host;
    } catch {
      return false;
    }
  });
  if (crossOriginForms.length) {
    push(
      `Form posts to another domain (${crossOriginForms.length})`,
      "medium",
      "Data flow",
      crossOriginForms[0].getAttribute("action")?.slice(0, 160) ?? "",
      "Visitor input leaves your site. Confirm the destination is a service you trust and that the transfer is encrypted.",
      "Post to your own origin and forward server-side, or document the third party.",
      "CWE-201"
    );
  }
  const formsNoToken = forms.filter((f) => {
    const method = (f.getAttribute("method") ?? "get").toLowerCase();
    return method === "post" && !f.querySelector('input[name*="csrf" i], input[name*="token" i], meta[name*="csrf" i]');
  });
  if (formsNoToken.length) {
    push(
      `${formsNoToken.length} POST form${formsNoToken.length > 1 ? "s" : ""} without a visible CSRF token`,
      "medium",
      "Authentication",
      formsNoToken[0].outerHTML.slice(0, 160),
      "If the session is cookie-based and the token is absent, another site can make a logged-in visitor submit this form.",
      "Include a per-session CSRF token and verify it server-side, plus SameSite cookies.",
      "CWE-352"
    );
  }
  const passwordNoAutocomplete = passwordFields.filter((p) => (p.getAttribute("autocomplete") ?? "") === "on");
  if (passwordNoAutocomplete.length) {
    push(
      "Password field set to autocomplete=on",
      "low",
      "Authentication",
      passwordNoAutocomplete[0].outerHTML.slice(0, 140),
      "The browser may store and refill the password on shared machines.",
      'Use autocomplete="current-password" or "new-password".',
      "CWE-522"
    );
  }

  /* ----------------------------- secrets ----------------------------- */
  const scriptText = inlineScripts.map((s) => s.textContent ?? "").join("\n");
  const haystack = `${html}\n${scriptText}`;
  for (const pattern of SECRET_PATTERNS) {
    const match = pattern.re.exec(haystack);
    if (!match) continue;
    push(
      `${pattern.label} visible in page source`,
      pattern.sev,
      "Secrets",
      match[0].replace(/^(.{0,12}).*$/, (_m, start: string) => `${start}…`),
      "Anything in page source is public. A key here can be used by anyone who opens developer tools, often at your expense.",
      "Revoke and rotate the key now, then move the call to a server-side function.",
      "CWE-798"
    );
  }

  /* --------------------------- information --------------------------- */
  const sourceMapRefs = html.match(/[A-Za-z0-9_\-./]+\.js\.map/g) ?? [];
  if (sourceMapRefs.length) {
    push(
      "Source maps are reachable",
      "medium",
      "Information leak",
      sourceMapRefs.slice(0, 3).join(", "),
      "Source maps rebuild the original, unminified code — comments, internal URLs and sometimes secrets included.",
      "Do not ship .map files to production, or restrict them to authenticated staff.",
      "CWE-540"
    );
  }
  if (generator) {
    push(
      "Generator/CMS version declared",
      "low",
      "Information leak",
      generator,
      "Publishing the exact CMS and version tells an attacker which plugin exploits to try first.",
      "Remove the generator meta tag and any version query strings.",
      "CWE-200"
    );
  }
  const comments = html.match(/<!--[\s\S]{0,400}?-->/g) ?? [];
  const riskyComments = comments.filter((c) => /todo|fixme|password|secret|api[_-]?key|admin|debug|internal|staging|localhost/i.test(c));
  if (riskyComments.length) {
    push(
      `${riskyComments.length} HTML comment${riskyComments.length > 1 ? "s" : ""} ${riskyComments.length > 1 ? "expose" : "exposes"} internal notes`,
      "medium",
      "Information leak",
      stripTags(riskyComments[0]).slice(0, 160),
      "Comments ship to every visitor. Notes about admin paths, staging hosts or credentials are a map for an attacker.",
      "Strip comments during the production build.",
      "CWE-200"
    );
  }
  const consoleLogs = (scriptText.match(/console\.(log|debug|info)\s*\(/g) ?? []).length;
  if (consoleLogs > 8) {
    push(
      `Verbose logging left in production (${consoleLogs} calls)`,
      "low",
      "Information leak",
      `${consoleLogs} console.log/debug calls`,
      "Debug logging often prints tokens, user records and internal IDs into the browser console.",
      "Remove debug logging from production builds.",
      "CWE-532"
    );
  }

  /* ----------------------------- libraries --------------------------- */
  const libSources = [...externalScripts, ...links].map((el) => el.getAttribute("src") ?? el.getAttribute("href") ?? "");
  const libHaystack = `${libSources.join("\n")}\n${scriptText.slice(0, 400000)}\n${generator}`;
  for (const lib of OLD_LIBS) {
    const match = lib.re.exec(libHaystack);
    if (!match) continue;
    push(
      `Outdated library: ${lib.label}`,
      lib.sev,
      "Supply chain",
      match[0],
      lib.why,
      `Upgrade ${lib.label.split(" ")[0]} to a supported release and re-test the pages that use it.`,
      "CWE-1104"
    );
  }

  /* ------------------------- exposed endpoints ----------------------- */
  const riskyPaths = anchors
    .map((a) => a.getAttribute("href") ?? "")
    .filter((h) => /(^|\/)(\.git|\.env|wp-admin|wp-login\.php|admin|phpmyadmin|server-status|actuator|swagger-ui|graphiql|debug)(\/|$|\.)/i.test(h));
  if (riskyPaths.length) {
    push(
      "Administrative or sensitive paths are linked publicly",
      "high",
      "Exposure",
      Array.from(new Set(riskyPaths)).slice(0, 4).join(", "),
      "Links to admin panels, .git, .env, debug consoles or API explorers give an attacker a starting point and sometimes open data.",
      "Remove the links, require authentication on those routes, and block .git/.env at the edge.",
      "CWE-200"
    );
  }

  const iframeHosts = new Set<string>();
  for (const frame of iframes) {
    const src = frame.getAttribute("src") ?? "";
    if (!src || src.startsWith("about:")) continue;
    try {
      const u = new URL(src, page.finalUrl);
      if (u.hostname !== host) iframeHosts.add(u.hostname);
    } catch {
      /* ignore */
    }
  }
  if (iframeHosts.size) {
    push(
      `Third-party frames embedded from ${iframeHosts.size} domain${iframeHosts.size > 1 ? "s" : ""}`,
      "low",
      "Third party",
      Array.from(iframeHosts).join(", "),
      "Embedded frames run their own code inside your page and can request permissions or show content you do not control.",
      "Keep frames on trusted hosts and add a sandbox attribute.",
      "CWE-1021"
    );
  }

  /* ---------------------- server-side rule scan ---------------------- */
  if (scriptText.length > 60) {
    const scan = scanSource(scriptText, `${host} inline script`);
    for (const f of scan.findings.slice(0, 6)) {
      push(
        `Inline script: ${f.title}`,
        f.severity,
        f.category,
        f.snippet,
        f.detail,
        f.fix,
        f.cwe
      );
    }
  }

  /* ------------------------------ score ----------------------------- */
  const weighted = findings.reduce((total, f) => total + SEV[f.severity], 0);
  const score = Math.min(100, Math.round(weighted));
  const grade =
    score >= 80 ? "F" : score >= 62 ? "E" : score >= 44 ? "D" : score >= 26 ? "C" : score >= 12 ? "B" : "A";
  const critical = findings.filter((f) => f.severity === "critical").length;
  const high = findings.filter((f) => f.severity === "high").length;

  const order: Severity[] = ["critical", "high", "medium", "low", "info"];
  findings.sort((a, b) => order.indexOf(a.severity) - order.indexOf(b.severity));

  const topFixes = findings
    .filter((f) => f.severity === "critical" || f.severity === "high")
    .slice(0, 3)
    .map((f) => f.fix);
  if (!topFixes.length) {
    findings
      .filter((f) => f.severity === "medium")
      .slice(0, 3)
      .forEach((f) => topFixes.push(f.fix));
  }

  const plain = critical
    ? `We found ${critical} critical problem${critical > 1 ? "s" : ""} that could be used to break into this site or its visitors' accounts. Start with the fixes below.`
    : high
    ? `No critical hole was exposed in the page source, but ${high} serious weakness${high > 1 ? "es" : ""} need fixing.`
    : findings.length
    ? `The page source looks reasonably maintained. ${findings.length} smaller issue${findings.length > 1 ? "s" : ""} would still be worth cleaning up.`
    : "Nothing exploitable was found in the page source. That is a good sign, not a guarantee — the server and APIs are out of scope.";

  const inventory: Record<string, string> = {
    "Page title": title || "not set",
    "Final URL": page.finalUrl,
    "Fetched": page.via,
    "Page size": `${(page.bytes / 1024).toFixed(1)} KB`,
    "Scripts": `${scripts.length} (${externalScripts.length} external, ${inlineScripts.length} inline)`,
    "Third-party hosts": externalHosts.size ? Array.from(externalHosts).slice(0, 8).join(", ") : "none",
    "Stylesheets": String(links.filter((l) => (l.getAttribute("rel") ?? "").includes("stylesheet")).length),
    "Forms": String(forms.length),
    "Password fields": String(passwordFields.length),
    "Iframes": String(iframes.length),
    "Images": String(imgs.length),
    "Generator": generator || "not declared",
    "Headers inspected": headersAvailable ? "yes" : "no (proxied fetch)",
  };

  const headerRows = HEADER_RULES.map((rule) => {
    const value =
      headers[rule.name] ??
      (rule.aliases?.map((a) => headers[a]).find(Boolean) ?? "");
    if (!headersAvailable) {
      return { name: rule.name, value: "not inspected", ok: true, note: rule.why };
    }
    return {
      name: rule.name,
      value: value || "not sent",
      ok: Boolean(value),
      note: rule.why,
    };
  });

  return {
    id: uid("audit"),
    url: page.finalUrl,
    host,
    createdAt: new Date().toISOString(),
    score,
    grade,
    plain,
    via: page.via,
    headersAvailable,
    findings,
    headers: headerRows,
    inventory,
    topFixes,
  };
}
