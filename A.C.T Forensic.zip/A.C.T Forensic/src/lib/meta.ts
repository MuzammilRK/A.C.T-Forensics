/** Low-level container and metadata parsing used by the forensic analyzers. */

const ASCII = (bytes: Uint8Array, start = 0, end = bytes.length) =>
  new TextDecoder("latin1").decode(bytes.subarray(start, end));

export function detectMagic(bytes: Uint8Array): { kind: string; label: string; mime: string } {
  const sig = (offset: number, seq: number[]) =>
    seq.every((v, i) => bytes[offset + i] === v);
  if (sig(0, [0xff, 0xd8, 0xff])) return { kind: "jpeg", label: "JPEG image", mime: "image/jpeg" };
  if (sig(0, [0x89, 0x50, 0x4e, 0x47])) return { kind: "png", label: "PNG image", mime: "image/png" };
  if (sig(0, [0x47, 0x49, 0x46, 0x38])) return { kind: "gif", label: "GIF image", mime: "image/gif" };
  if (sig(0, [0x52, 0x49, 0x46, 0x46]) && ASCII(bytes, 8, 12) === "WEBP")
    return { kind: "webp", label: "WebP image", mime: "image/webp" };
  if (sig(0, [0x42, 0x4d])) return { kind: "bmp", label: "BMP image", mime: "image/bmp" };
  if (sig(4, [0x66, 0x74, 0x79, 0x70]) && ASCII(bytes, 8, 12).includes("qt"))
    return { kind: "mov", label: "QuickTime movie", mime: "video/quicktime" };
  if (sig(4, [0x66, 0x74, 0x79, 0x70])) return { kind: "mp4", label: "MP4 container", mime: "video/mp4" };
  if (ASCII(bytes, 0, 4) === "RIFF" && ASCII(bytes, 8, 12) === "WAVE")
    return { kind: "wav", label: "WAV audio", mime: "audio/wav" };
  if (ASCII(bytes, 0, 3) === "ID3" || sig(0, [0xff, 0xfb]))
    return { kind: "mp3", label: "MPEG audio", mime: "audio/mpeg" };
  if (ASCII(bytes, 0, 4) === "%PDF") return { kind: "pdf", label: "PDF document", mime: "application/pdf" };
  if (sig(0, [0x50, 0x4b, 0x03, 0x04])) {
    if (ASCII(bytes, 0, Math.min(bytes.length, 6000)).includes("word/document.xml"))
      return { kind: "docx", label: "Word document", mime: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" };
    return { kind: "zip", label: "ZIP archive", mime: "application/zip" };
  }
  if (sig(0, [0x4f, 0x67, 0x67, 0x53])) return { kind: "ogg", label: "Ogg media", mime: "audio/ogg" };
  return { kind: "unknown", label: "Unrecognised binary", mime: "application/octet-stream" };
}

/** Printable ASCII runs, with generous minimum length, for metadata hunting. */
export function asciiStrings(bytes: Uint8Array, minLen = 5, limit = 400): string[] {
  const out: string[] = [];
  let current = "";
  const scanLength = Math.min(bytes.length, 1024 * 1024);
  for (let i = 0; i < scanLength; i++) {
    const c = bytes[i];
    if (c >= 32 && c <= 126) {
      current += String.fromCharCode(c);
    } else {
      if (current.length >= minLen) out.push(current);
      current = "";
      if (out.length >= limit) break;
    }
  }
  if (current.length >= minLen && out.length < limit) out.push(current);
  return out;
}

export interface PngText {
  keyword: string;
  value: string;
}

export function readPngText(bytes: Uint8Array): PngText[] {
  const chunks: PngText[] = [];
  let offset = 8;
  const decoder = new TextDecoder("latin1");
  while (offset + 12 < bytes.length && chunks.length < 40) {
    const view = new DataView(bytes.buffer, bytes.byteOffset + offset, 4);
    const length = view.getUint32(0);
    if (length > bytes.length) break;
    const type = decoder.decode(bytes.subarray(offset + 4, offset + 8));
    const dataStart = offset + 8;
    if (type === "tEXt" || type === "iTXt") {
      const raw = decoder.decode(bytes.subarray(dataStart, dataStart + Math.min(length, 6000)));
      const split = raw.indexOf("\u0000");
      if (split > 0) {
        const keyword = raw.slice(0, split);
        let value = raw.slice(split + 1);
        if (type === "iTXt") {
          const parts = value.split("\u0000");
          value = parts.slice(2).join(" ");
        }
        chunks.push({ keyword, value: value.trim().slice(0, 4000) });
      }
    } else if (type === "zTXt") {
      chunks.push({ keyword: "zTXt", value: "(compressed text chunk)" });
    }
    if (type === "IEND") break;
    offset = dataStart + length + 4;
  }
  return chunks;
}

export interface Mp4Info {
  brand: string;
  durationSeconds: number | null;
  creator: string | null;
  handler: string | null;
}

export function readMp4(bytes: Uint8Array): Mp4Info {
  const text = ASCII(bytes, 0, Math.min(bytes.length, 4096));
  const brand = text.slice(8, 12).trim() || "unknown";
  let durationSeconds: number | null = null;
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  for (let i = 4; i < Math.min(bytes.length - 16, 4 * 1024 * 1024); i++) {
    if (bytes[i] === 0x6d && bytes[i + 1] === 0x76 && bytes[i + 2] === 0x68 && bytes[i + 3] === 0x64) {
      // mvhd payload: version(1) flags(3) [creation, mod, timescale, duration]
      const version = bytes[i + 4];
      const base = i + 8;
      if (version === 0 && base + 12 <= bytes.length) {
        const timescale = dv.getUint32(base + 8);
        const duration = dv.getUint32(base + 12);
        if (timescale > 0) durationSeconds = duration / timescale;
      } else if (base + 28 <= bytes.length) {
        const timescale = dv.getUint32(base + 16);
        const duration = Number(dv.getBigUint64(base + 20));
        if (timescale > 0) durationSeconds = duration / timescale;
      }
      break;
    }
  }
  const strings = asciiStrings(bytes, 4, 800);
  const creator =
    strings.find((s) => /Lavf|HandBrake|Adobe|Apple|CapCut|FFmpeg|Runway|Sora|Pika|Kling|Luma|Synthesia|HeyGen|Descript|Veed/i.test(s)) ?? null;
  return { brand, durationSeconds, creator, handler: null };
}

export interface WavInfo {
  sampleRate: number;
  channels: number;
  bits: number;
  durationSeconds: number;
  codec: string;
}

export function readWav(bytes: Uint8Array): WavInfo | null {
  if (bytes.length < 44) return null;
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (ASCII(bytes, 0, 4) !== "RIFF" || ASCII(bytes, 8, 12) !== "WAVE") return null;
  let offset = 12;
  let sampleRate = 0;
  let channels = 0;
  let bits = 0;
  let codec = "PCM";
  let durationSeconds = 0;
  while (offset + 8 < bytes.length) {
    const id = ASCII(bytes, offset, offset + 4);
    const size = dv.getUint32(offset + 4, true);
    if (id === "fmt ") {
      codec = dv.getUint16(offset + 8, true) === 1 ? "PCM" : `format ${dv.getUint16(offset + 8, true)}`;
      channels = dv.getUint16(offset + 10, true);
      sampleRate = dv.getUint32(offset + 12, true);
      bits = dv.getUint16(offset + 22, true);
    } else if (id === "data") {
      const byteRate = sampleRate * channels * (bits / 8);
      if (byteRate > 0) durationSeconds = size / byteRate;
      break;
    }
    offset += 8 + size + (size % 2);
  }
  return { sampleRate, channels, bits, durationSeconds, codec };
}

export function readPdfInfo(bytes: Uint8Array): Record<string, string> {
  const text = ASCII(bytes, 0, Math.min(bytes.length, 2 * 1024 * 1024));
  const grab = (key: string) => {
    const m = text.match(new RegExp(`/${key}\\s*\\(([^)]{0,120})\\)`));
    return m ? m[1].replace(/\\([()\\])/g, "$1") : "";
  };
  const info: Record<string, string> = {};
  for (const key of ["Producer", "Creator", "Author", "Title", "CreationDate"]) {
    const v = grab(key);
    if (v) info[key] = v;
  }
  info["PDF version"] = text.slice(0, 8).trim();
  info["Pages (declared)"] = String((text.match(/\/Type\s*\/Page[^s]/g) ?? []).length || "unknown");
  return info;
}

export const GENERATOR_MARKERS: { pattern: RegExp; label: string; weight: number }[] = [
  { pattern: /midjourney/i, label: "Midjourney", weight: 62 },
  { pattern: /dall[-\s·]?e|openai/i, label: "OpenAI DALL·E", weight: 62 },
  { pattern: /stable\s*diffusion|sdxl|automatic1111|comfyui|a1111/i, label: "Stable Diffusion toolchain", weight: 66 },
  { pattern: /adobe\s*firefly|firefly/i, label: "Adobe Firefly", weight: 48 },
  { pattern: /leonardo\.ai|leonardo ai/i, label: "Leonardo AI", weight: 55 },
  { pattern: /runway|gen-?3/i, label: "Runway", weight: 55 },
  { pattern: /\bsora\b/i, label: "OpenAI Sora", weight: 65 },
  { pattern: /pika\s*labs|\bpika\b/i, label: "Pika", weight: 55 },
  { pattern: /kling|veo\s*3|veo2?/i, label: "Kling / Veo", weight: 55 },
  { pattern: /luma\s*(ai|dream)|dream\s*machine/i, label: "Luma Dream Machine", weight: 55 },
  { pattern: /elevenlabs|eleven\s*labs/i, label: "ElevenLabs voice synthesis", weight: 66 },
  { pattern: /suno|udio|soundraw|mubert/i, label: "AI music generator", weight: 62 },
  { pattern: /synthesia|heygen|did\.?studio|descript/i, label: "AI avatar / dubbing tool", weight: 55 },
  { pattern: /generative\s*fill|content\s*credentials|c2pa/i, label: "Generative fill / C2PA provenance", weight: 40 },
  { pattern: /canva|figma|photopea/i, label: "Web editor export", weight: 18 },
  { pattern: /photoshop|adobe\s*photoshop|gimp|lightroom|affinity/i, label: "Photo editor export", weight: 22 },
];

export const CAMERA_MARKERS =
  /iPhone|iPad|NIKON|Canon|SONY|Samsung|Pixel|GoPro|DJI|FUJIFILM|Olympus|Panasonic|Leica|Hasselblad|OnePlus|Xiaomi|Motorola/i;
