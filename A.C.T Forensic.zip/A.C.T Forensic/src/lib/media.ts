import type { Analysis, ForensicCheck, Keyframe, ProvenanceReport, Signal } from "./types";
import { clamp } from "./hash";
import { detectMagic, readMp4, readWav } from "./meta";
import { scanBinaryProvenance } from "./watermark";

/* ------------------------------- shared ------------------------------- */

function plainProvenance(kind: "video" | "audio", hasDevice: boolean, aiTool: string | null, statsNote: string, device?: string | null): ProvenanceReport {
  const verdict: ProvenanceReport["verdict"] = aiTool ? "synthetic" : hasDevice ? "authentic-capture" : "unknown";
  return {
    verdict,
    headline: aiTool
      ? `A generative tool is named in the file — ${aiTool}`
      : hasDevice
      ? `Recording device recorded${device ? `: ${device}` : ""}`
      : `No ${kind === "video" ? "camera" : "recorder"} identity in the file`,
    plain: aiTool
      ? "The file's own container metadata names a synthesis tool. That is direct evidence, not a probability."
      : hasDevice
      ? `The container records the equipment that wrote it. ${statsNote}`
      : `The container was stripped of device details — normal for files sent through chat apps. ${statsNote}`,
    confidence: aiTool ? 88 : hasDevice ? 76 : 46,
    device: device ?? null,
    software: null,
    signed: false,
    aiDeclared: !!aiTool,
    hits: [],
  };
}

/* ------------------------------- video ------------------------------- */

function sampleVideoFrame(video: HTMLVideoElement, time: number): Promise<{ pixels: Float32Array; thumb: string } | null> {
  return new Promise((resolve) => {
    const onSeeked = () => {
      video.removeEventListener("seeked", onSeeked);
      try {
        const w = 320;
        const h = Math.max(8, Math.round((video.videoHeight / video.videoWidth) * w));
        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d", { willReadFrequently: true });
        if (!ctx) return resolve(null);
        ctx.drawImage(video, 0, 0, w, h);
        const pixels = new Float32Array(ctx.getImageData(0, 0, w, h).data);
        const thumbCanvas = document.createElement("canvas");
        thumbCanvas.width = 200;
        thumbCanvas.height = Math.max(8, Math.round((h / w) * 200));
        const tctx = thumbCanvas.getContext("2d");
        tctx?.drawImage(canvas, 0, 0, thumbCanvas.width, thumbCanvas.height);
        resolve({ pixels, thumb: thumbCanvas.toDataURL("image/jpeg", 0.62) });
      } catch {
        resolve(null);
      }
    };
    video.addEventListener("seeked", onSeeked);
    setTimeout(() => {
      video.removeEventListener("seeked", onSeeked);
      resolve(null);
    }, 4000);
    try {
      video.currentTime = time;
    } catch {
      resolve(null);
    }
  });
}

function frameStats(pixels: Float32Array) {
  const n = pixels.length / 4;
  let sum = 0;
  let sumSq = 0;
  let satSum = 0;
  for (let p = 0; p < n; p++) {
    const o = p * 4;
    const l = 0.2126 * pixels[o] + 0.7152 * pixels[o + 1] + 0.0722 * pixels[o + 2];
    sum += l;
    sumSq += l * l;
    const max = Math.max(pixels[o], pixels[o + 1], pixels[o + 2]);
    const min = Math.min(pixels[o], pixels[o + 1], pixels[o + 2]);
    satSum += max === 0 ? 0 : (max - min) / max;
  }
  const mean = sum / n;
  const sd = Math.sqrt(Math.max(0, sumSq / n - mean * mean));
  return { lumMean: mean, lumSd: sd, saturation: satSum / n };
}

export async function analyzeVideo(blob: Blob, name: string): Promise<Analysis> {
  const bytes = new Uint8Array(await blob.arrayBuffer());
  const magic = detectMagic(bytes);
  const info = magic.kind === "mp4" || magic.kind === "mov" ? readMp4(bytes) : null;
  const prov = scanBinaryProvenance(bytes, blob.type || magic.mime);
  const aiTool =
    prov.aiGenerator ??
    prov.hits.find((h) => h.kind === "ai-label" && h.strength >= 70)?.label ??
    null;

  const url = URL.createObjectURL(blob);
  const video = document.createElement("video");
  video.muted = true;
  video.playsInline = true;
  video.preload = "auto";
  video.src = url;

  const ready = await new Promise<boolean>((resolve) => {
    video.addEventListener("loadeddata", () => resolve(true), { once: true });
    video.addEventListener("error", () => resolve(false), { once: true });
    setTimeout(() => resolve(false), 9000);
  });

  let duration = info?.durationSeconds ?? 0;
  let width = video.videoWidth;
  let height = video.videoHeight;
  const stats: ReturnType<typeof frameStats>[] = [];
  const keyframes: Keyframe[] = [];
  if (ready && video.duration && Number.isFinite(video.duration)) {
    duration = video.duration;
    width = video.videoWidth;
    height = video.videoHeight;
    for (const frac of [0.06, 0.28, 0.5, 0.72, 0.94]) {
      const shot = await sampleVideoFrame(video, Math.max(0, duration * frac));
      if (shot) {
        const s = frameStats(shot.pixels);
        stats.push(s);
        keyframes.push({
          t: Number((duration * frac).toFixed(2)),
          thumb: shot.thumb,
          note: s.lumSd < 32 ? "low detail variance" : "normal detail",
          score: 0,
        });
      }
    }
  }
  URL.revokeObjectURL(url);

  const signals: Signal[] = [];
  const lums = stats.map((s) => s.lumMean);
  const lumSds = stats.map((s) => s.lumSd);
  const saturations = stats.map((s) => s.saturation);
  const spread = lums.length > 1 ? Math.max(...lums) - Math.min(...lums) : 0;
  const satMean = saturations.length ? saturations.reduce((a, b) => a + b, 0) / saturations.length : 0;
  const satSd = saturations.length
    ? Math.sqrt(saturations.reduce((a, v) => a + (v - satMean) ** 2, 0) / saturations.length)
    : 0;
  const avgDetail = lumSds.length ? lumSds.reduce((a, b) => a + b, 0) / lumSds.length : 0;

  // Base score: metadata decides the band, frame statistics only move it inside that band.
  let score: number;
  if (aiTool) score = 74;
  else if (prov.device || info?.creator) score = 10;
  else score = 18;
  if (prov.device || info?.creator) {
    if (spread < 4) score += 4;
    if (avgDetail < 22 && stats.length) score += 4;
    score = clamp(score, 4, 34);
  } else {
    if (spread < 10 && stats.length) score += 8;
    if (avgDetail < 26 && stats.length) score += 6;
    if (satSd < 0.004 && stats.length) score += 4;
    score = clamp(score, 8, 52);
  }
  if (aiTool) score = clamp(score + Math.round(satSd * 40), 68, 96);

  if (prov.hits.length) {
    for (const h of prov.hits.slice(0, 5)) {
      signals.push({
        id: h.id,
        label: h.label,
        strength: h.strength / 100,
        detail: `${h.meaning} Found in ${h.where}: “${h.evidence}”`,
        tone: h.tone,
      });
    }
  }

  signals.push({
    id: "exposure",
    label: "Light drift across the clip",
    strength: spread < 10 ? 0.6 : 0.2,
    detail: stats.length
      ? `Brightness moves ${spread.toFixed(1)} out of 255 across ${stats.length} sampled frames. ${
          spread < 10
            ? "Real cameras almost always drift more than this as light changes; generated video tends to stay locked."
            : "Light changes naturally, as you would expect from a camera recording."
        }`
      : "Frames could not be decoded, so this check was skipped.",
    tone: spread < 10 && stats.length ? "risk" : "good",
  });
  signals.push({
    id: "detail",
    label: "Detail consistency",
    strength: avgDetail < 26 ? 0.55 : 0.2,
    detail: `Average fine-detail response is ${avgDetail.toFixed(1)}. ${
      avgDetail < 26
        ? "Texture is soft through the whole clip — a common look for diffusion video and heavy upscaling."
        : "Texture is present frame to frame."
    }`,
    tone: avgDetail < 26 ? "risk" : "good",
  });
  signals.push({
    id: "palette",
    label: "Colour stability",
    strength: satSd < 0.004 ? 0.45 : 0.15,
    detail: `Mean saturation ${(satMean * 100).toFixed(0)}%, frame-to-frame σ ${(satSd * 100).toFixed(
      1
    )}%. ${satSd < 0.004 ? "A frozen palette is typical of rendered clips." : "Colour shifts slightly with the scene."}`,
    tone: satSd < 0.004 ? "neutral" : "good",
  });

  const checks: ForensicCheck[] = [
    {
      id: "source",
      name: "Source record",
      status: aiTool ? "fail" : prov.device || info?.creator ? "pass" : "warn",
      metric: aiTool ?? prov.device ?? info?.creator ?? "not recorded",
      detail: aiTool
        ? "The container metadata names a synthesis tool."
        : "Camera or encoder identity inside the container. Platforms often strip this when a video is re-uploaded.",
    },
    {
      id: "visual",
      name: "Visual frames",
      status: stats.length ? "pass" : "na",
      metric: `${stats.length} frames sampled`,
      detail: "Frames are pulled across the timeline and compared for lighting, texture and palette stability.",
    },
    {
      id: "temporal",
      name: "Temporal drift",
      status: stats.length ? (spread < 10 ? "warn" : "pass") : "na",
      metric: `${spread.toFixed(1)}/255`,
      detail: "How much brightness moves between frames. Physical lighting changes; renderers often do not.",
    },
    {
      id: "audio",
      name: "Audio track",
      status: "na",
      metric: "not inspected here",
      detail: "Extract the audio track and run it through the Audio workspace for voice-clone checks.",
    },
    {
      id: "compression",
      name: "Compression",
      status: "na",
      metric: info?.brand ? `brand ${info.brand}` : "unknown",
      detail: "Container brand and encoder strings show how the file was packaged.",
    },
  ];

  const verdict =
    score >= 68
      ? "Likely AI-generated video"
      : score >= 42
      ? "Some timing or detail anomalies"
      : aiTool
      ? "Generator named in metadata"
      : prov.device
      ? "Looks like a real recording"
      : "No AI evidence found";

  return {
    kind: "video",
    verdict,
    aiLikelihood: score,
    confidence: stats.length >= 3 ? 74 : 46,
    plain: aiTool
      ? "The video's own metadata says it came from an AI video tool. Treat the footage as synthetic."
      : prov.device || info?.creator
      ? "The file names the recording equipment and the frames behave like a camera clip. Nothing here indicates AI."
      : "The file has no device record, so this result is based on how the frames behave over time. It is an indicator, not a verdict.",
    summary: `${name}: ${
      aiTool ? `metadata names ${aiTool}` : prov.device ? `recorded by ${prov.device}` : "container metadata stripped"
    }. ${stats.length} frame(s) compared across the timeline.`,
    signals,
    metadata: {
      "Detected container": magic.label,
      "Major brand": info?.brand ?? "n/a",
      Duration: duration ? `${duration.toFixed(2)} s` : "unknown",
      Resolution: width && height ? `${width} × ${height}` : "unknown",
      "File size": `${(blob.size / 1024 / 1024).toFixed(2)} MB`,
      "Encoder / device": prov.device ?? info?.creator ?? "not recorded",
      "Frames sampled": String(stats.length),
      "Brightness drift": `${spread.toFixed(1)} / 255`,
      "Mean detail": avgDetail.toFixed(1),
      "Mean saturation": `${(satMean * 100).toFixed(0)}%`,
    },
    keyframes,
    provenance: plainProvenance("video", !!(prov.device || info?.creator), aiTool, "Frame stability was measured on top of it.", prov.device ?? info?.creator),
    checks,
    notes: [
      "Frame checks find tells, they do not prove generation. A locked-off security camera can look statistically similar to a rendered clip.",
      "Extract the audio track and analyse it separately — voice cloning is invisible to picture checks.",
    ],
  };
}

/* ------------------------------- audio ------------------------------- */

function fft(re: Float32Array, im: Float32Array) {
  const n = re.length;
  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      [re[i], re[j]] = [re[j], re[i]];
      [im[i], im[j]] = [im[j], im[i]];
    }
  }
  for (let len = 2; len <= n; len <<= 1) {
    const ang = (-2 * Math.PI) / len;
    const wRe = Math.cos(ang);
    const wIm = Math.sin(ang);
    for (let i = 0; i < n; i += len) {
      let curRe = 1;
      let curIm = 0;
      for (let k = 0; k < len / 2; k++) {
        const uRe = re[i + k];
        const uIm = im[i + k];
        const vRe = re[i + k + len / 2] * curRe - im[i + k + len / 2] * curIm;
        const vIm = re[i + k + len / 2] * curIm + im[i + k + len / 2] * curRe;
        re[i + k] = uRe + vRe;
        im[i + k] = uIm + vIm;
        re[i + k + len / 2] = uRe - vRe;
        im[i + k + len / 2] = uIm - vIm;
        const nextRe = curRe * wRe - curIm * wIm;
        curIm = curRe * wIm + curIm * wRe;
        curRe = nextRe;
      }
    }
  }
}

export async function analyzeAudio(blob: Blob, name: string): Promise<Analysis> {
  const bytes = new Uint8Array(await blob.arrayBuffer());
  const magic = detectMagic(bytes);
  const wav = readWav(bytes);
  const prov = scanBinaryProvenance(bytes, blob.type || magic.mime);
  const aiTool =
    prov.aiGenerator ?? prov.hits.find((h) => h.kind === "ai-label" && h.strength >= 70)?.label ?? null;

  const signals: Signal[] = [];
  const metadata: Record<string, string> = {
    "Detected container": magic.label,
    Codec: wav?.codec ?? (magic.kind === "mp3" ? "MPEG audio" : "unknown"),
    "Sample rate": wav ? `${wav.sampleRate} Hz` : "unknown",
    Channels: wav ? String(wav.channels) : "unknown",
    "Bit depth": wav ? `${wav.bits}-bit` : "unknown",
    Duration: wav ? `${wav.durationSeconds.toFixed(2)} s` : "unknown",
    "File size": `${(blob.size / 1024).toFixed(1)} KB`,
  };

  let waveform: number[] | undefined;
  let spectrum: number[] | undefined;
  let spectrumMaxHz = 0;
  let info: { cutoff: number; flatness: number; highBand: number; silence: number; clipping: number } | null = null;

  try {
    const AudioCtor: typeof AudioContext =
      window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new AudioCtor();
    const buffer = await ctx.decodeAudioData(await blob.arrayBuffer());
    const channel = buffer.getChannelData(0);
    const sr = buffer.sampleRate;
    metadata["Decoded sample rate"] = `${sr} Hz`;
    metadata["Decoded duration"] = `${buffer.duration.toFixed(2)} s`;
    metadata["Decoded channels"] = String(buffer.numberOfChannels);

    // Waveform envelope for the viewer
    const bars = 220;
    const step = Math.max(1, Math.floor(channel.length / bars));
    const envelope: number[] = [];
    for (let i = 0; i < bars; i++) {
      let peak = 0;
      for (let j = 0; j < step; j++) {
        const v = Math.abs(channel[i * step + j] ?? 0);
        if (v > peak) peak = v;
      }
      envelope.push(Number(peak.toFixed(3)));
    }
    waveform = envelope;

    const win = 2048;
    const totalWindows = Math.floor(channel.length / win);
    const skip = Math.max(1, Math.floor(totalWindows / 40));
    const avgMag = new Float64Array(win / 2);
    let windows = 0;
    let silentWindows = 0;
    let clipping = 0;
    for (let s = 0; s < channel.length; s++) if (Math.abs(channel[s]) > 0.995) clipping++;

    for (let w = 0; w + win <= channel.length && windows < 40; w += win * skip) {
      const re = new Float32Array(win);
      const im = new Float32Array(win);
      let rms = 0;
      for (let i = 0; i < win; i++) {
        re[i] = channel[w + i];
        rms += channel[w + i] * channel[w + i];
      }
      rms = Math.sqrt(rms / win);
      if (rms < 0.0008) silentWindows++;
      fft(re, im);
      for (let b = 1; b < win / 2; b++) avgMag[b] += Math.sqrt(re[b] * re[b] + im[b] * im[b]);
      windows++;
    }
    if (windows) for (let b = 0; b < avgMag.length; b++) avgMag[b] /= windows;

    let peak = 0;
    for (const v of avgMag) peak = Math.max(peak, v);
    const nyquist = sr / 2;
    let cutoffBin = avgMag.length - 1;
    for (let b = avgMag.length - 1; b > 1; b--) {
      if (avgMag[b] > peak * 0.01 && avgMag[b] > avgMag[b - 1] * 0.5) {
        cutoffBin = b;
        break;
      }
    }
    const cutoff = (cutoffBin / (avgMag.length - 1)) * nyquist;

    let geo = 0;
    let arith = 0;
    let count = 0;
    for (let b = 1; b < avgMag.length; b++) {
      if (avgMag[b] <= 0) continue;
      geo += Math.log(avgMag[b] + 1e-9);
      arith += avgMag[b];
      count++;
    }
    const flatness = count ? Math.exp(geo / count) / (arith / count) : 0;
    let highE = 0;
    let totalE = 0;
    for (let b = 1; b < avgMag.length; b++) {
      const f = (b / (avgMag.length - 1)) * nyquist;
      totalE += avgMag[b];
      if (f > 16000) highE += avgMag[b];
    }
    const highBand = totalE ? highE / totalE : 0;
    info = {
      cutoff,
      flatness,
      highBand,
      silence: windows ? silentWindows / windows : 0,
      clipping: clipping / channel.length,
    };

    // Normalised dB spectrum for drawing
    const bins = 128;
    const values: number[] = [];
    for (let i = 0; i < bins; i++) {
      const from = Math.floor((i / bins) * avgMag.length);
      const to = Math.max(from + 1, Math.floor(((i + 1) / bins) * avgMag.length));
      let sum = 0;
      for (let b = from; b < to; b++) sum += avgMag[b];
      const mag = sum / (to - from);
      const db = 20 * Math.log10(Math.max(mag, 1e-9) / Math.max(peak, 1e-9));
      values.push(Number(clamp((db + 90) / 90, 0, 1).toFixed(3)));
    }
    spectrum = values;
    spectrumMaxHz = Math.round(nyquist);

    metadata["Usable bandwidth"] = `${Math.round(cutoff)} Hz`;
    metadata["Above 16 kHz energy"] = `${(highBand * 100).toFixed(2)}%`;
    metadata["Spectral flatness"] = flatness.toFixed(3);
    metadata["Digitally silent windows"] = `${(info.silence * 100).toFixed(0)}%`;
    metadata["Clipping samples"] = `${(info.clipping * 100).toFixed(3)}%`;
    await ctx.close();
  } catch {
    signals.push({
      id: "decode",
      label: "Waveform could not be decoded",
      strength: 0.2,
      detail: "This browser could not decode the audio stream, so the result uses container metadata only.",
      tone: "neutral",
    });
  }

  // Only the 12–19.5 kHz shelf is characteristic of neural speech; music and test
  // tones are naturally band-limited far lower, and flagging them was a false positive.
  const bandLimited = magic.kind === "wav" && !!info && info.cutoff > 11500 && info.cutoff < 19500;
  let score: number;
  if (aiTool) score = 74;
  else if (info && !bandLimited) score = 12;
  else score = 20;
  if (info) {
    if (bandLimited) score += 22;
    if (info.silence > 0.28) score += 8;
    if (info.clipping > 0.002) score += 4;
    if (info.highBand < 0.002 && magic.kind === "wav") score += 6;
  }
  score = clamp(score, aiTool ? 66 : 4, aiTool ? 95 : 58);

  if (prov.hits.length) {
    for (const h of prov.hits.slice(0, 4)) {
      signals.push({
        id: h.id,
        label: h.label,
        strength: h.strength / 100,
        detail: `${h.meaning} Found in ${h.where}: “${h.evidence}”`,
        tone: h.tone,
      });
    }
  }
  signals.push({
    id: "cutoff",
    label: "Frequency ceiling",
    strength: bandLimited ? 0.6 : 0.2,
    detail: info
      ? `Usable sound stops at ${Math.round(info.cutoff)} Hz of the ${Math.round(
          spectrumMaxHz
        )} Hz available. Neural speech usually stops in a narrow 12–19 kHz shelf while a microphone keeps a little noise all the way up; music and test tones naturally stop lower, so a low ceiling alone is not treated as evidence.`
      : "No spectrum could be measured for this file.",
    tone: bandLimited ? "risk" : "good",
  });
  signals.push({
    id: "silence",
    label: "Pure-digital silence",
    strength: info && info.silence > 0.28 ? 0.45 : 0.1,
    detail: info
      ? `${(info.silence * 100).toFixed(0)}% of windows are digitally silent (exact zeros). Real rooms always have a noise floor; exact zeros mean editing or synthesis.`
      : "Not measured.",
    tone: info && info.silence > 0.28 ? "risk" : "neutral",
  });
  signals.push({
    id: "flatness",
    label: "Texture of the sound",
    strength: info ? Math.min(1, info.flatness * 6) : 0,
    detail: info
      ? `Spectral flatness ${info.flatness.toFixed(3)} (0 = pure tone, 1 = hiss). Vocoder output often sits in an unnatural middle band.`
      : "Not measured.",
    tone: "neutral",
  });

  const checks: ForensicCheck[] = [
    {
      id: "source",
      name: "Source record",
      status: aiTool ? "fail" : prov.hasAnyExif || prov.device ? "pass" : "warn",
      metric: aiTool ?? prov.device ?? prov.software ?? "not recorded",
      detail: aiTool
        ? "The container metadata names a synthesis tool."
        : "Recorder identity in the container. Chat apps usually strip it, so a warning here is not proof of synthesis.",
    },
    {
      id: "visual",
      name: "Waveform",
      status: waveform ? "pass" : "na",
      metric: waveform ? `${waveform.length} envelope points` : "undecodable",
      detail: "Peak envelope across the whole clip, used to spot splices and abrupt level jumps.",
    },
    {
      id: "compression",
      name: "Bandwidth",
      status: info ? (bandLimited ? "warn" : "pass") : "na",
      metric: info ? `${Math.round(info.cutoff)} Hz` : "n/a",
      detail: "Where the high frequencies stop. A lossless file that stops at 16–18 kHz points at a voice generator.",
    },
    {
      id: "temporal",
      name: "Silence / splices",
      status: info ? (info.silence > 0.28 ? "warn" : "pass") : "na",
      metric: info ? `${(info.silence * 100).toFixed(0)}% silent` : "n/a",
      detail: "Exact digital silence does not occur in a real room recording.",
    },
    {
      id: "audio",
      name: "Voice identity",
      status: "na",
      metric: "needs an enrolled sample",
      detail: "Speaker comparison requires a known reference recording of the same person.",
    },
  ];

  const verdict = aiTool
    ? "Generated or cloned audio likely"
    : score >= 55
    ? "Spectral signs of synthetic speech"
    : score >= 35
    ? "Some audio anomalies"
    : "No AI evidence found";

  return {
    kind: "audio",
    verdict,
    aiLikelihood: score,
    confidence: info ? 70 : 40,
    plain: aiTool
      ? "The file names a speech or music synthesis tool. That is provenance, not a guess."
      : bandLimited
      ? "The high frequencies stop early on a lossless recording — the most common giveaway of generated speech. A human should listen before this is relied on."
      : "Nothing in the spectrum or the metadata points to synthesis. This does not rule out a good voice clone, which needs a reference sample to detect.",
    summary: `${name}: ${verdict.toLowerCase()}. ${
      info ? `Sound reaches ${Math.round(info.cutoff)} Hz of ${Math.round(spectrumMaxHz)} Hz available.` : "Spectrum not available."
    }`,
    signals,
    metadata,
    waveform,
    spectrum,
    spectrumMaxHz,
    provenance: plainProvenance("audio", !!(prov.device || prov.software), aiTool, "Spectrum and silence checks were run on the decoded waveform.", prov.device),
    checks,
    notes: [
      "Voice-clone detection needs a reference recording of the real speaker; without one, bandwidth and silence are the reliable tells.",
      "Compressed formats (MP3, AAC) already lose high frequencies, so the bandwidth check only applies to lossless files.",
    ],
  };
}
