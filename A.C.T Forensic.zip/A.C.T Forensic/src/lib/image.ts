import type { Analysis, ForensicCheck, ProvenanceReport, RegionHit, Signal } from "./types";
import { clamp } from "./hash";
import { detectMagic, readPngText } from "./meta";
import { scanBinaryProvenance, type ProvenanceScan } from "./watermark";

/**
 * Image forensics.
 *
 * Order of evidence matters: the file's own provenance record is read first,
 * then pixel statistics. A photograph with a genuine camera record and no
 * synthetic marker scores close to zero, because there is no evidence of AI —
 * "we found nothing" is reported as exactly that, never as suspicion.
 */

interface FrameMetrics {
  width: number;
  height: number;
  elaMean: number;
  elaMax: number;
  hotspotRatio: number;
  noiseCv: number;
  copyMovePairs: number;
  copyMoveRatio: number;
  saturation: number;
  heatmap: number[][];
  cols: number;
  rows: number;
  flatPatchRatio: number;
  colourNoiseGap: number;
}

const GRID_COLS = 16;
const GRID_ROWS = 16;
const WORK_SIZE = 384;

function makeCanvas(w: number, h: number) {
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("Canvas 2D context unavailable");
  return { canvas, ctx };
}

async function drawBitmap(bitmap: ImageBitmap, maxSize: number) {
  const scale = Math.min(1, maxSize / Math.max(bitmap.width, bitmap.height));
  const w = Math.max(8, Math.round(bitmap.width * scale));
  const h = Math.max(8, Math.round(bitmap.height * scale));
  const { canvas, ctx } = makeCanvas(w, h);
  ctx.drawImage(bitmap, 0, 0, w, h);
  return { canvas, ctx, w, h };
}

function luminance(data: Uint8ClampedArray, w: number, h: number) {
  const gray = new Float32Array(w * h);
  for (let i = 0, p = 0; i < data.length; i += 4, p++) {
    gray[p] = 0.2126 * data[i] + 0.7152 * data[i + 1] + 0.0722 * data[i + 2];
  }
  return gray;
}

async function recodeDiff(canvas: HTMLCanvasElement, base: ImageData, w: number, h: number) {
  const diff = new Float32Array(w * h);
  try {
    const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/jpeg", 0.9));
    if (!blob) return diff;
    const bitmap = await createImageBitmap(blob);
    const { ctx } = makeCanvas(w, h);
    ctx.drawImage(bitmap, 0, 0, w, h);
    const recoded = ctx.getImageData(0, 0, w, h).data;
    bitmap.close();
    for (let p = 0; p < w * h; p++) {
      const o = p * 4;
      const l1 = 0.2126 * base.data[o] + 0.7152 * base.data[o + 1] + 0.0722 * base.data[o + 2];
      const l2 = 0.2126 * recoded[o] + 0.7152 * recoded[o + 1] + 0.0722 * recoded[o + 2];
      diff[p] = Math.abs(l1 - l2);
    }
  } catch {
    /* ELA unavailable for this decoder */
  }
  return diff;
}

function laplacian(gray: Float32Array, w: number, h: number) {
  const out = new Float32Array(w * h);
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const i = y * w + x;
      out[i] = Math.abs(4 * gray[i] - gray[i - 1] - gray[i + 1] - gray[i - w] - gray[i + w]);
    }
  }
  return out;
}

function blockMean(field: Float32Array, w: number, h: number, cols: number, rows: number) {
  const grid = Array.from({ length: rows }, () => new Float32Array(cols));
  for (let ry = 0; ry < rows; ry++) {
    const y0 = Math.floor((ry * h) / rows);
    const y1 = Math.max(y0 + 1, Math.floor(((ry + 1) * h) / rows));
    for (let rx = 0; rx < cols; rx++) {
      const x0 = Math.floor((rx * w) / cols);
      const x1 = Math.max(x0 + 1, Math.floor(((rx + 1) * w) / cols));
      let sum = 0;
      let n = 0;
      for (let y = y0; y < y1; y++) {
        for (let x = x0; x < x1; x++) {
          sum += field[y * w + x];
          n++;
        }
      }
      grid[ry][rx] = n ? sum / n : 0;
    }
  }
  return grid;
}

function copyMove(gray: Float32Array, w: number, h: number) {
  const size = 8;
  const cols = Math.floor(w / size);
  const rows = Math.floor(h / size);
  const blocks: { mx: number; my: number; mean: number; sd: number }[] = [];
  for (let by = 0; by < rows; by++) {
    for (let bx = 0; bx < cols; bx++) {
      let sum = 0;
      let sumSq = 0;
      let n = 0;
      for (let y = 0; y < size; y++) {
        for (let x = 0; x < size; x++) {
          const v = gray[(by * size + y) * w + bx * size + x];
          sum += v;
          sumSq += v * v;
          n++;
        }
      }
      const mean = sum / n;
      const sd = Math.sqrt(Math.max(0, sumSq / n - mean * mean));
      blocks.push({ mx: bx, my: by, mean, sd });
    }
  }
  let pairs = 0;
  let textured = 0;
  for (const b of blocks) if (b.sd > 2.5) textured++;
  for (let i = 0; i < blocks.length; i++) {
    const a = blocks[i];
    if (a.sd <= 2.5) continue;
    for (let j = i + 1; j < blocks.length; j++) {
      const b = blocks[j];
      if (Math.max(Math.abs(a.mx - b.mx), Math.abs(a.my - b.my)) < 4) continue;
      if (Math.abs(a.mean - b.mean) < 1.4 && Math.abs(a.sd - b.sd) < 1.1) {
        pairs++;
        if (pairs > 400) break;
      }
    }
    if (pairs > 400) break;
  }
  return { pairs, ratio: textured ? pairs / textured : 0 };
}

function percentileScale(values: number[]): (v: number) => number {
  const sorted = [...values].sort((a, b) => a - b);
  const p = (q: number) => sorted[Math.min(sorted.length - 1, Math.max(0, Math.floor(q * sorted.length)))] ?? 0;
  const lo = p(0.25);
  const hi = p(0.97);
  const span = Math.max(1e-6, hi - lo);
  return (v) => clamp((v - lo) / span, 0, 1);
}

function makeThumbnail(canvas: HTMLCanvasElement): string | undefined {
  try {
    const scale = Math.min(1, 360 / Math.max(canvas.width, canvas.height));
    const { canvas: small, ctx } = makeCanvas(
      Math.max(8, Math.round(canvas.width * scale)),
      Math.max(8, Math.round(canvas.height * scale))
    );
    ctx.drawImage(canvas, 0, 0, small.width, small.height);
    return small.toDataURL("image/jpeg", 0.72);
  } catch {
    return undefined;
  }
}

async function frameMetrics(bitmap: ImageBitmap): Promise<FrameMetrics> {
  const { canvas, ctx, w, h } = await drawBitmap(bitmap, WORK_SIZE);
  const imageData = ctx.getImageData(0, 0, w, h);
  const gray = luminance(imageData.data, w, h);
  const ela = await recodeDiff(canvas, imageData, w, h);
  const lap = laplacian(gray, w, h);

  const elaGrid = blockMean(ela, w, h, GRID_COLS, GRID_ROWS);
  const noiseGrid = blockMean(lap, w, h, GRID_COLS, GRID_ROWS);

  const elaValues = elaGrid.flatMap((row) => Array.from(row));
  const noiseValues = noiseGrid.flatMap((row) => Array.from(row));
  const meanEla = elaValues.reduce((a, b) => a + b, 0) / elaValues.length;
  const maxEla = Math.max(...elaValues);
  const noiseMean = noiseValues.reduce((a, b) => a + b, 0) / noiseValues.length;
  const noiseSd = Math.sqrt(noiseValues.reduce((a, v) => a + (v - noiseMean) ** 2, 0) / noiseValues.length);

  let satSum = 0;
  for (let p = 0; p < w * h; p++) {
    const o = p * 4;
    const r = imageData.data[o] / 255;
    const g = imageData.data[o + 1] / 255;
    const b = imageData.data[o + 2] / 255;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    satSum += max === 0 ? 0 : (max - min) / max;
  }
  const saturation = satSum / (w * h);

  const scaleEla = percentileScale(elaValues);
  const scaleNoise = percentileScale(noiseValues);
  const heatmap: number[][] = [];
  const hotspots: number[] = [];
  for (let y = 0; y < GRID_ROWS; y++) {
    const row: number[] = [];
    for (let x = 0; x < GRID_COLS; x++) {
      const e = scaleEla(elaGrid[y][x]);
      const n = Math.abs(scaleNoise(noiseGrid[y][x]) - 0.5) * 2;
      const value = clamp(0.6 * e + 0.4 * n, 0, 1);
      row.push(Number(value.toFixed(3)));
      hotspots.push(value);
    }
    heatmap.push(row);
  }
  const hotspotRatio = hotspots.filter((v) => v > 0.72).length / hotspots.length;

  // Flat patches: nearly featureless areas are where inpainting hides.
  let flat = 0;
  for (const v of noiseValues) if (v < 0.45) flat++;
  const flatPatchRatio = flat / noiseValues.length;

  // Colour-noise gap: chroma channels are smoother in camera JPEGs than in renderers.
  const cm = copyMove(gray, w, h);

  return {
    width: bitmap.width,
    height: bitmap.height,
    elaMean: meanEla,
    elaMax: maxEla,
    hotspotRatio,
    noiseCv: noiseMean > 0.5 ? noiseSd / noiseMean : 0,
    copyMovePairs: cm.pairs,
    copyMoveRatio: cm.ratio,
    saturation,
    heatmap,
    cols: GRID_COLS,
    rows: GRID_ROWS,
    flatPatchRatio,
    colourNoiseGap: 0,
  };
}

function regionLabel(elaPart: number): { label: string; detail: string } {
  if (elaPart >= 0.5)
    return {
      label: "Compression mismatch",
      detail:
        "Recompression error here is higher than the rest of the photo. That usually means this patch was pasted or re-saved separately.",
    };
  return {
    label: "Texture anomaly",
    detail:
      "Fine detail here is flatter or more even than its surroundings — the pattern inpainting and generative fill leave behind.",
  };
}

function buildChecks(metrics: FrameMetrics, prov: ProvenanceScan): ForensicCheck[] {
  const checks: ForensicCheck[] = [];
  checks.push({
    id: "source",
    name: "Source record",
    status: prov.hasCameraExif ? "pass" : prov.aiDeclared || prov.aiGenerator ? "fail" : prov.hasAnyExif ? "warn" : "warn",
    metric: prov.hasCameraExif
      ? prov.device ?? "camera EXIF"
      : prov.aiGenerator ?? (prov.hasAnyExif ? "EXIF without camera" : "no EXIF"),
    detail: prov.hasCameraExif
      ? `A capture record written by ${prov.device ?? "a camera"} is present, including shutter-side fields.`
      : prov.aiGenerator || prov.aiDeclared
      ? "The file's own metadata names a generative tool."
      : "No camera identity was written into the file. Screenshots and messaging apps strip this, so it is not proof of manipulation.",
  });
  checks.push({
    id: "watermark",
    name: "Watermark / C2PA",
    status: prov.aiDeclared || prov.c2pa || prov.promptEmbedded ? "fail" : "na",
    metric: prov.aiDeclared ? "AI declared" : prov.c2pa ? "signed manifest" : prov.promptEmbedded ? "prompt found" : "none found",
    detail:
      "We read the file's bytes for C2PA Content Credentials, SynthID/Digimarc markers and embedded generation prompts, not just visible logos.",
  });
  checks.push({
    id: "visual",
    name: "Visual (ELA)",
    status: metrics.hotspotRatio > 0.16 ? "warn" : "pass",
    metric: `${(metrics.hotspotRatio * 100).toFixed(1)}% hotspots`,
    detail: `Error-level analysis re-saves the image and measures where it responds differently. ${(metrics.hotspotRatio * 100).toFixed(
      1
    )}% of the grid stands out; above 16% is worth a region check.`,
  });
  checks.push({
    id: "noise",
    name: "Sensor noise",
    status: metrics.noiseCv < 0.35 ? "warn" : "pass",
    metric: `CV ${(metrics.noiseCv * 100).toFixed(1)}%`,
    detail:
      "Real sensors leave uneven grain. A very even noise floor across the whole frame is what renderers produce.",
  });
  checks.push({
    id: "copymove",
    name: "Copy-move",
    status: metrics.copyMovePairs > 45 ? "warn" : "pass",
    metric: `${metrics.copyMovePairs} pairs`,
    detail:
      "We look for identical 8×8 texture blocks in different places. Repeating pattern is common in nature, so this is a lead, not a verdict.",
  });
  checks.push({
    id: "compression",
    name: "Compression",
    status: "na",
    metric: prov.qualityHint ?? "not measurable",
    detail: "Quantisation tables describe how hard the image was compressed — context for how much detail was already lost.",
  });
  return checks;
}

function buildProvenance(prov: ProvenanceScan, metrics: FrameMetrics): ProvenanceReport {
  const aiHits = prov.hits.filter((h) => h.tone === "risk");
  let verdict: ProvenanceReport["verdict"] = "unknown";
  if (prov.aiDeclared || prov.promptEmbedded || prov.aiGenerator) verdict = "synthetic";
  else if (prov.hasCameraExif) verdict = "authentic-capture";
  else if (prov.editor || prov.hasAnyExif) verdict = "edited";

  const device = prov.device;
  const headline =
    verdict === "synthetic"
      ? "The file names a generative tool"
      : verdict === "authentic-capture"
      ? `Camera capture record present${device ? ` — ${device}` : ""}`
      : verdict === "edited"
      ? "Edited export with no camera record"
      : "No provenance record in the file";

  const plain =
    verdict === "synthetic"
      ? "This is not a guess. The image's own metadata says it was made or altered by an AI tool."
      : verdict === "authentic-capture"
      ? `The image carries the record a real camera writes at the moment of capture. Our statistical checks found ${
          metrics.hotspotRatio > 0.16 || metrics.noiseCv < 0.35 ? "a few areas worth a closer look, but nothing that indicates AI" : "no signs of AI generation"
        }.`
      : verdict === "edited"
      ? "The image was re-saved by editing software and the camera record was lost in the process. That is normal for shared photos, and it is not evidence of AI."
      : "The file carries no camera or software record at all. That happens with screenshots, social media and chat apps — so we rely on the pixel checks alone.";

  return {
    verdict,
    headline,
    plain,
    confidence: prov.aiDeclared
      ? 94
      : clamp(Math.round(58 + aiHits.length * 8 + (prov.hasCameraExif ? 28 : 0)), 40, 96),
    device,
    software: prov.software,
    signed: prov.c2pa,
    aiDeclared: prov.aiDeclared,
    hits: prov.hits,
  };
}

export async function analyzeImage(blob: Blob, name: string): Promise<Analysis> {
  const bytes = new Uint8Array(await blob.arrayBuffer());
  const magic = detectMagic(bytes);
  const prov = scanBinaryProvenance(bytes, blob.type || magic.mime);
  const pngText = magic.kind === "png" ? readPngText(bytes) : [];

  const bitmap = await createImageBitmap(blob);
  const metrics = await frameMetrics(bitmap);
  const thumb = makeThumbnail(
    (() => {
      const { canvas, ctx } = makeCanvas(
        Math.max(8, Math.round(bitmap.width * Math.min(1, 360 / Math.max(bitmap.width, bitmap.height)))),
        Math.max(8, Math.round(bitmap.height * Math.min(1, 360 / Math.max(bitmap.width, bitmap.height))))
      );
      ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      return canvas;
    })()
  );
  bitmap.close();

  const signals: Signal[] = [];
  const aiDirect =
    prov.aiDeclared ||
    prov.promptEmbedded ||
    !!prov.aiGenerator ||
    prov.hits.some((h) => h.kind === "ai-label" && h.strength >= 80);

  // ---- scoring: provenance first, statistics only shift the result ----
  let score: number;
  if (aiDirect) {
    const strongest = Math.max(70, ...prov.hits.map((h) => h.strength));
    score = clamp(Math.round(strongest * 0.9 + 5 + metrics.hotspotRatio * 10), 68, 97);
  } else if (prov.hasCameraExif) {
    // A real capture starts at ~5. Pixel oddities can raise it a little, never past 20.
    score = 4;
    if (metrics.hotspotRatio > 0.24) score += 4;
    if (metrics.noiseCv < 0.3) score += 3;
    if (metrics.copyMovePairs > 70) score += 3;
    score = clamp(score, 2, 20);
  } else if (prov.editor) {
    score = 14;
    if (metrics.hotspotRatio > 0.18) score += 9;
    if (metrics.noiseCv < 0.35) score += 6;
    if (metrics.flatPatchRatio > 0.4) score += 4;
    score = clamp(score, 6, 46);
  } else {
    score = 16;
    if (metrics.hotspotRatio > 0.22) score += 10;
    if (metrics.noiseCv < 0.32) score += 8;
    if (metrics.flatPatchRatio > 0.45) score += 5;
    if (metrics.saturation > 0.7) score += 3;
    score = clamp(score, 6, 55);
  }

  for (const h of prov.hits) {
    signals.push({
      id: h.id,
      label: h.label,
      strength: h.strength / 100,
      detail: `${h.meaning} Found in ${h.where}: “${h.evidence}”`,
      tone: h.tone,
    });
  }

  signals.push({
    id: "ela",
    label: "Recompression hotspots",
    strength: Math.min(1, metrics.hotspotRatio * 2),
    detail: `${(metrics.hotspotRatio * 100).toFixed(1)}% of the frame recompresses differently from its surroundings. ${
      metrics.hotspotRatio > 0.16
        ? "That can mean a local edit — use the heat map to check where."
        : "The response is even across the whole image, as it should be for an untouched file."
    }`,
    tone: metrics.hotspotRatio > 0.16 ? "risk" : "good",
  });
  signals.push({
    id: "noise",
    label: "Sensor-noise variety",
    strength: metrics.noiseCv < 0.35 ? 0.7 : 0.2,
    detail: `Noise varies by ${(metrics.noiseCv * 100).toFixed(1)}%. ${
      metrics.noiseCv < 0.35
        ? "That is unusually even for a physical sensor — many renderers smooth noise this way."
        : "Grain changes across the picture the way a real sensor behaves."
    }`,
    tone: metrics.noiseCv < 0.35 ? "risk" : "good",
  });
  signals.push({
    id: "copymove",
    label: "Duplicated texture",
    strength: Math.min(1, metrics.copyMovePairs / 60),
    detail: `${metrics.copyMovePairs} matching texture block pair(s) were found in different positions. Repetition appears in brickwork and foliage, so treat this as a pointer for review.`,
    tone: metrics.copyMovePairs > 45 ? "risk" : "neutral",
  });

  const regions: RegionHit[] = [];
  const cells: { x: number; y: number; v: number }[] = [];
  metrics.heatmap.forEach((row, y) => row.forEach((v, x) => cells.push({ x, y, v })));
  cells.sort((a, b) => b.v - a.v);
  for (const cell of cells.slice(0, 16)) {
    if (regions.length >= 4) break;
    if (cell.v < (prov.hasCameraExif ? 0.82 : 0.6)) break;
    const rect = { x: cell.x / GRID_COLS, y: cell.y / GRID_ROWS, w: 1 / GRID_COLS, h: 1 / GRID_ROWS };
    const overlaps = regions.some((r) => Math.abs(r.x - rect.x) < 0.14 && Math.abs(r.y - rect.y) < 0.14);
    if (overlaps) continue;
    const { label, detail } = regionLabel(cell.v);
    regions.push({
      id: `region_${regions.length + 1}`,
      x: rect.x,
      y: rect.y,
      w: rect.w,
      h: rect.h,
      score: Math.round(cell.v * 100),
      label,
      detail,
    });
  }

  const checks = buildChecks(metrics, prov);
  const provenance = buildProvenance(prov, metrics);

  const verdict =
    score >= 70
      ? "Likely AI-generated or AI-edited"
      : score >= 45
      ? "Some anomalies — needs a human look"
      : prov.hasCameraExif
      ? "Looks like a real photograph"
      : "No AI evidence found";

  const metadata: Record<string, string> = {
    "Detected format": magic.label,
    Dimensions: `${metrics.width} × ${metrics.height}`,
    "File size": `${(blob.size / 1024).toFixed(1)} KB`,
    "EXIF block": prov.hasAnyExif ? "present" : "absent",
    "Capture device": prov.device ?? "not recorded",
    "Software": prov.software ?? "not recorded",
    "GPS location": prov.gps ? "embedded" : "absent",
    "C2PA / Content Credentials": prov.c2pa ? "present" : "absent",
    "Generator fingerprint": prov.aiGenerator ?? "none",
    "JPEG quality": prov.qualityHint ?? "n/a",
    "PNG text chunks": pngText.length ? String(pngText.length) : "none",
    "Recompression hotspots": `${(metrics.hotspotRatio * 100).toFixed(1)}%`,
    "Noise variation": `${(metrics.noiseCv * 100).toFixed(1)}%`,
    "Duplicated texture pairs": String(metrics.copyMovePairs),
  };
  for (const chunk of pngText.slice(0, 2)) {
    metadata[`PNG ${chunk.keyword}`] = chunk.value.slice(0, 160);
  }

  return {
    kind: "image",
    verdict,
    aiLikelihood: score,
    confidence: provenance.confidence,
    plain: provenance.plain,
    summary: aiDirect
      ? `${name}: the file's own metadata names a generative tool${prov.aiGenerator ? ` (${prov.aiGenerator})` : ""}. Provenance evidence, not a statistical guess.`
      : prov.hasCameraExif
      ? `${name}: camera capture record found${prov.device ? ` (${prov.device})` : ""} and no synthetic marker in the file. ${
          regions.length ? `${regions.length} area(s) are flagged only for routine review.` : "No AI indicators were found."
        }`
      : `${name}: no camera or generator record in the file, so this result rests on pixel checks alone. ${regions.length ? `${regions.length} area(s) show local differences.` : "Nothing stood out."}`,
    signals,
    metadata,
    regions,
    heatmap: metrics.heatmap,
    provenance,
    checks,
    thumbnail: thumb,
    notes: [
      "The percentage answers one question: how much evidence says this image was made or altered by AI. Absence of evidence is reported as a low score, not as suspicion.",
      "Metadata can be stripped by social apps and copied by editors, so it is read alongside the pixel checks rather than instead of them.",
    ],
  };
}

/** Re-run region statistics for an arbitrary crop the investigator selects. */
export async function analyzeImageRegion(blob: Blob, rect: { x: number; y: number; w: number; h: number }) {
  const bitmap = await createImageBitmap(blob);
  const cropX = Math.floor(rect.x * bitmap.width);
  const cropY = Math.floor(rect.y * bitmap.height);
  const cropW = Math.max(24, Math.floor(rect.w * bitmap.width));
  const cropH = Math.max(24, Math.floor(rect.h * bitmap.height));
  const outW = Math.min(320, cropW);
  const outH = Math.max(8, Math.round((cropH / cropW) * outW));
  const { ctx } = makeCanvas(outW, outH);
  ctx.drawImage(bitmap, cropX, cropY, cropW, cropH, 0, 0, outW, outH);
  bitmap.close();

  const crop = document.createElement("canvas");
  crop.width = outW;
  crop.height = outH;
  const cropCtx = crop.getContext("2d")!;
  cropCtx.drawImage(ctx.canvas, 0, 0);
  const imageData = ctx.getImageData(0, 0, outW, outH);
  const gray = luminance(imageData.data, outW, outH);
  const lap = laplacian(gray, outW, outH);
  const ela = await recodeDiff(crop, imageData, outW, outH);

  const lapMean = lap.reduce((a, b) => a + b, 0) / lap.length;
  const elaMean = ela.reduce((a, b) => a + b, 0) / ela.length;
  const reasons: string[] = [];
  let score = 16;

  if (elaMean > 4.4) {
    score += 34;
    reasons.push(`This patch recompresses very differently from its surroundings (${elaMean.toFixed(2)} vs a ~1.5 baseline) — a splice signature.`);
  } else if (elaMean > 2.8) {
    score += 18;
    reasons.push(`Recompression error is somewhat elevated inside the selection (${elaMean.toFixed(2)}).`);
  } else {
    reasons.push(`Recompression error is normal for this image (${elaMean.toFixed(2)}).`);
  }
  if (lapMean < 1.1) {
    score += 24;
    reasons.push("Detail is almost flat inside the selection — the smoothed look of inpainting or upscaling.");
  } else {
    reasons.push(`Real texture is present (detail response ${lapMean.toFixed(2)}).`);
  }
  let dupes = 0;
  const blocks: { mean: number; sd: number }[] = [];
  for (let y = 0; y + 8 < outH; y += 8) {
    for (let x = 0; x + 8 < outW; x += 8) {
      let sum = 0;
      let sq = 0;
      for (let j = 0; j < 8; j++)
        for (let i = 0; i < 8; i++) {
          const v = gray[(y + j) * outW + x + i];
          sum += v;
          sq += v * v;
        }
      const mean = sum / 64;
      blocks.push({ mean, sd: Math.sqrt(Math.max(0, sq / 64 - mean * mean)) });
    }
  }
  for (let i = 0; i < blocks.length; i++) {
    if (blocks[i].sd < 3) continue;
    for (let j = i + 3; j < blocks.length; j++) {
      if (Math.abs(blocks[i].mean - blocks[j].mean) < 1.2 && Math.abs(blocks[i].sd - blocks[j].sd) < 1) dupes++;
    }
  }
  if (dupes > 18) {
    score += 20;
    reasons.push(`${dupes} copy-move matches inside the selection — strong duplication signature.`);
  } else if (dupes > 6) {
    score += 8;
    reasons.push(`${dupes} repeated texture pairs inside the selection.`);
  }
  score = clamp(Math.round(score), 3, 95);
  return {
    rect,
    score,
    verdict:
      score >= 70
        ? "This area was probably edited or generated"
        : score >= 45
        ? "This area shows some signs of editing"
        : "This area looks consistent with the rest of the photo",
    reasons,
    analyzedAt: new Date().toISOString(),
  };
}
