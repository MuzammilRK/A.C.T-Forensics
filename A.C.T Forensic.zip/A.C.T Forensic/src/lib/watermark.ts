import type { WatermarkHit } from "./types";
import { asciiStrings, GENERATOR_MARKERS, readPngText } from "./meta";

/**
 * Provenance & watermark reader.
 *
 * This module explains its evidence in plain words: every hit carries the exact
 * string that produced it, the place it was found, and what that means. It does
 * not guess. If a photo carries real camera EXIF and no synthetic marker, the
 * report says so and the AI score stays near zero.
 */

const AI_LABELS: { re: RegExp; label: string; strength: number }[] = [
  { re: /trainedAlgorithmicMedia/i, label: "C2PA / IPTC: trained algorithmic media", strength: 96 },
  { re: /compositeWithTrainedAlgorithmicMedia/i, label: "C2PA: composite with generated content", strength: 92 },
  { re: /algorithmicallyEnhanced/i, label: "IPTC: algorithmically enhanced", strength: 62 },
  { re: /synthid|synth\s?id/i, label: "SynthID invisible watermark reference", strength: 88 },
  { re: /content\s*credentials|contentauth|\bc2pa\b|jumbf/i, label: "Content Credentials (C2PA) manifest", strength: 55 },
  { re: /digimarc|truepic|steg\.ai|imatag/i, label: "Commercial provenance watermark service", strength: 70 },
  { re: /made with (google )?ai|generated with ai|ai[- ]generated/i, label: "AI-generated disclosure label", strength: 84 },
  { re: /dall[-\s·]?e|openai|chatgpt/i, label: "OpenAI generator signature", strength: 82 },
  { re: /midjourney/i, label: "Midjourney generator signature", strength: 86 },
  { re: /stable\s*diffusion|sdxl|comfyui|automatic1111|a1111|invokeai/i, label: "Stable Diffusion toolchain signature", strength: 86 },
  { re: /black\s*forest|flux\.1|\bflux\b/i, label: "FLUX (Black Forest Labs) signature", strength: 80 },
  { re: /adobe\s*firefly|firefly/i, label: "Adobe Firefly signature", strength: 74 },
  { re: /imagen\s*[0-9]|google\s*(deepmind|ai)\s*imagen/i, label: "Google Imagen signature", strength: 80 },
  { re: /gemini|bard/i, label: "Google Gemini signature", strength: 66 },
  { re: /claude|anthropic/i, label: "Anthropic Claude signature", strength: 72 },
  { re: /leonardo\.?ai|playground\s*ai|recraft|ideogram|runway|pika|luma|kling|veo\s*[0-9]?/i, label: "Generative media platform signature", strength: 72 },
  { re: /elevenlabs|eleven\s*labs|suno|udio|descript|synthesia|heygen/i, label: "Speech / music synthesis signature", strength: 84 },
  { re: /novelai|niji|dreamstudio|nightcafe|wombo|deepai|artbreeder/i, label: "Consumer AI art platform signature", strength: 76 },
];

const PROMPT_MARKERS =
  /(^|\n)\s*(steps|sampler|cfg scale|seed|model hash|negative prompt)\s*:/i;
const PROMPT_JSON = /"class_type"\s*:|"checkpoint"\s*:|"positive_prompt"\s*:/i;

const EDITOR_MARKERS = [
  { re: /adobe\s*photoshop|photoshop/i, label: "Adobe Photoshop" },
  { re: /lightroom/i, label: "Adobe Lightroom" },
  { re: /gimp/i, label: "GIMP" },
  { re: /affinity/i, label: "Affinity Photo" },
  { re: /snapseed/i, label: "Snapseed" },
  { re: /picsart/i, label: "PicsArt" },
  { re: /canva/i, label: "Canva" },
  { re: /figma/i, label: "Figma" },
  { re: /photopea/i, label: "Photopea" },
  { re: /screenshot|snipping tool|greenshot|sharex/i, label: "Screen capture tool" },
];

const CAMERA_MAKERS: { re: RegExp; label: string }[] = [
  { re: /\bApple\b|iPhone/i, label: "Apple iPhone" },
  { re: /\bCanon\b/i, label: "Canon" },
  { re: /\bNIKON\b|\bNikon\b/i, label: "Nikon" },
  { re: /\bSONY\b|\bSony\b/i, label: "Sony" },
  { re: /\bSamsung\b|\bGalaxy\b/i, label: "Samsung" },
  { re: /\bGoogle\b.*\bPixel\b|\bPixel\b/i, label: "Google Pixel" },
  { re: /\bGoPro\b/i, label: "GoPro" },
  { re: /\bDJI\b/i, label: "DJI" },
  { re: /\bFUJIFILM\b|\bFujifilm\b/i, label: "Fujifilm" },
  { re: /\bPanasonic\b|\bLumix\b/i, label: "Panasonic" },
  { re: /\bOlympus\b|\bOM Digital\b/i, label: "Olympus" },
  { re: /\bLeica\b/i, label: "Leica" },
  { re: /\bHasselblad\b/i, label: "Hasselblad" },
  { re: /\bOnePlus\b|\bXiaomi\b|\bMotorola\b|\bOPPO\b|\bVivo\b/i, label: "Android phone" },
  { re: /\bInsta360\b/i, label: "Insta360" },
];

export interface ExifTag {
  tag: number;
  name: string;
  value: string;
}

export interface JpegExif {
  tags: Record<string, string>;
  hasExif: boolean;
  hasGps: boolean;
  tagCount: number;
}

function readAscii(view: DataView, offset: number, count: number): string {
  let out = "";
  for (let i = 0; i < count && offset + i < view.byteLength; i++) {
    const c = view.getUint8(offset + i);
    if (c === 0) break;
    out += String.fromCharCode(c);
  }
  return out.trim();
}

function tiffValue(
  view: DataView,
  entryOffset: number,
  little: boolean,
  nextOffsetBase: number
): { name: string; value: string; type: number } | null {
  const type = view.getUint16(entryOffset + 2, little);
  const count = view.getUint32(entryOffset + 4, little);
  const size = type === 2 ? 1 : type === 3 ? 2 : type === 4 ? 4 : type === 5 ? 8 : 1;
  const total = size * count;
  let dataOffset = entryOffset + 8;
  if (total > 4) {
    const rel = view.getUint32(entryOffset + 8, little);
    dataOffset = nextOffsetBase + rel;
  }
  if (dataOffset < 0 || dataOffset >= view.byteLength) return null;
  if (type === 2) return { name: "", value: readAscii(view, dataOffset, Math.min(count, 256)), type };
  if (type === 3 && count >= 1)
    return { name: "", value: String(view.getUint16(dataOffset, little)), type };
  if (type === 4 && count >= 1) return { name: "", value: String(view.getUint32(dataOffset, little)), type };
  if (type === 5 && count >= 1) {
    const num = view.getUint32(dataOffset, little);
    const den = view.getUint32(dataOffset + 4, little) || 1;
    return { name: "", value: den ? (num / den).toFixed(3).replace(/\.0+$/, "") : String(num), type };
  }
  return null;
}

const TAG_NAMES: Record<number, string> = {
  0x010f: "Make",
  0x0110: "Model",
  0x0112: "Orientation",
  0x011a: "XResolution",
  0x0131: "Software",
  0x0132: "DateTime",
  0x013b: "Artist",
  0x8298: "Copyright",
  0x829a: "ExposureTime",
  0x829d: "FNumber",
  0x8827: "ISO",
  0x9003: "DateTimeOriginal",
  0x920a: "FocalLength",
  0xa002: "PixelXDimension",
  0xa003: "PixelYDimension",
  0xa434: "LensModel",
  0x010e: "ImageDescription",
};

/** Reads the EXIF block out of a JPEG/TIFF-origin byte stream. */
export function readJpegExif(bytes: Uint8Array): JpegExif {
  const empty: JpegExif = { tags: {}, hasExif: false, hasGps: false, tagCount: 0 };
  let exifStart = -1;
  const limit = Math.min(bytes.length - 8, 512 * 1024);
  for (let i = 0; i < limit; i++) {
    if (
      bytes[i] === 0x45 &&
      bytes[i + 1] === 0x78 &&
      bytes[i + 2] === 0x69 &&
      bytes[i + 3] === 0x66 &&
      bytes[i + 4] === 0 &&
      bytes[i + 5] === 0
    ) {
      exifStart = i + 6;
      break;
    }
  }
  if (exifStart < 0 || exifStart + 8 > bytes.length) return empty;

  try {
    const view = new DataView(bytes.buffer, bytes.byteOffset + exifStart, bytes.length - exifStart);
    const endian = view.getUint16(0);
    const little = endian === 0x4949;
    if (!little && endian !== 0x4d4d) return empty;
    if (view.getUint16(2, little) !== 42) return empty;
    const ifd0 = view.getUint32(4, little);
    if (ifd0 + 2 > view.byteLength) return empty;

    const tags: Record<string, string> = {};
    let tagCount = 0;
    const readIfd = (offset: number, depth: number) => {
      if (depth > 2 || offset + 2 > view.byteLength) return;
      const entries = view.getUint16(offset, little);
      if (entries > 400) return;
      for (let i = 0; i < entries; i++) {
        const entry = offset + 2 + i * 12;
        if (entry + 12 > view.byteLength) break;
        const tag = view.getUint16(entry, little);
        tagCount++;
        if (tag === 0x8769) {
          readIfd(view.getUint32(entry + 8, little), depth + 1);
          continue;
        }
        if (tag === 0x8825) {
          empty.hasGps = true;
          continue;
        }
        const name = TAG_NAMES[tag];
        if (!name) continue;
        const parsed = tiffValue(view, entry, little, 0);
        if (parsed && parsed.value) tags[name] = parsed.value;
      }
    };
    readIfd(ifd0, 0);
    return { tags, hasExif: Object.keys(tags).length > 0, hasGps: empty.hasGps, tagCount };
  } catch {
    return empty;
  }
}

export interface ProvenanceScan {
  hits: WatermarkHit[];
  device: string | null;
  software: string | null;
  hasCameraExif: boolean;
  hasAnyExif: boolean;
  gps: boolean;
  c2pa: boolean;
  aiDeclared: boolean;
  promptEmbedded: boolean;
  aiGenerator: string | null;
  editor: string | null;
  qualityHint: string | null;
  stringsSeen: number;
}

function hit(
  id: string,
  kind: WatermarkHit["kind"],
  label: string,
  strength: number,
  evidence: string,
  where: string,
  tone: WatermarkHit["tone"],
  meaning: string
): WatermarkHit {
  return { id, kind, label, strength, evidence: evidence.slice(0, 220), where, tone, meaning };
}

/** Estimate JPEG compression from the first quantisation table (rough but useful context). */
function jpegQualityHint(bytes: Uint8Array): string | null {
  for (let i = 0; i < Math.min(bytes.length - 4, 200000); i++) {
    if (bytes[i] === 0xff && bytes[i + 1] === 0xdb) {
      const length = (bytes[i + 2] << 8) | bytes[i + 3];
      const tableStart = i + 5;
      if (i + length > bytes.length || tableStart + 64 > bytes.length) return null;
      let sum = 0;
      for (let k = 0; k < 64; k++) sum += bytes[tableStart + k];
      const avg = sum / 64;
      if (avg < 1.2) return "very high quality (near-lossless re-encode)";
      if (avg < 3) return "high quality";
      if (avg < 7) return "standard quality";
      if (avg < 14) return "strong compression (resaved or messaged)";
      return "heavy compression";
    }
  }
  return null;
}

/**
 * Scans the file's own bytes (its "source code") for provenance statements,
 * watermarks and AI disclosures.
 */
export function scanBinaryProvenance(bytes: Uint8Array, mime: string): ProvenanceScan {
  const hits: WatermarkHit[] = [];
  const strings = asciiStrings(bytes, 6, 900);
  const joined = strings.join("\n");
  const head = new TextDecoder("latin1").decode(bytes.subarray(0, Math.min(bytes.length, 700_000)));
  const haystack = `${head}\n${joined}`;

  let device: string | null = null;
  let software: string | null = null;
  let hasAnyExif = false;
  let gps = false;

  if (/jpeg|jpg|heic|tiff|image/i.test(mime) || bytes[0] === 0xff) {
    const exif = readJpegExif(bytes);
    hasAnyExif = exif.hasExif;
    gps = exif.hasGps;
    if (exif.tags.Make || exif.tags.Model) {
      device = [exif.tags.Make, exif.tags.Model].filter(Boolean).join(" ");
    }
    if (exif.tags.Software) software = exif.tags.Software;
    const shown = Object.entries(exif.tags)
      .filter(([k]) => ["Make", "Model", "Software", "DateTimeOriginal", "LensModel", "ISO", "FNumber", "ExposureTime", "FocalLength"].includes(k))
      .map(([k, v]) => `${k}=${v}`)
      .join(", ");
    if (shown && (exif.tags.Make || exif.tags.Model)) {
      hits.push(
        hit(
          "exif-camera",
          "camera-exif",
          "Camera capture record found",
          70,
          shown,
          "EXIF IFD0 / ExifIFD",
          "good",
          "A physical camera wrote this metadata at capture time. It is the strongest sign of a real photograph — though it can be copied, so pair it with the statistical checks."
        )
      );
    } else if (exif.hasExif) {
      hits.push(
        hit(
          "exif-other",
          "editor",
          "EXIF block present, no camera maker",
          30,
          shown || `${exif.tagCount} tags`,
          "EXIF",
          "neutral",
          "The file has EXIF but no camera identity — typical of an edited export or a screenshot pipeline."
        )
      );
    }
    if (gps) {
      hits.push(
        hit("gps", "camera-exif", "GPS coordinates embedded", 40, "GPS IFD present", "EXIF GPS IFD", "good",
          "Location data was written by a capture device. Useful corroboration for a photo's origin.")
      );
    }
  }

  // XMP packet (JPEG APP1, PNG iTXt, WebP, sidecar)
  const xmpMatch = /<x:xmpmeta[\s\S]{0,20000}?<\/x:xmpmeta>/i.exec(head);
  if (xmpMatch) {
    const xmp = xmpMatch[0];
    const creatorTool = /xmp:CreatorTool="([^"]{1,120})"/i.exec(xmp)?.[1] ?? /<xmp:CreatorTool>([^<]{1,120})</i.exec(xmp)?.[1];
    const dcCreator = /<dc:creator>[\s\S]{0,400}?<rdf:li[^>]*>([^<]{1,120})</i.exec(xmp)?.[1];
    const sourceType = /Iptc4xmpExt:DigitalSourceType[^>]*>([^<]{1,160})</i.exec(xmp)?.[1]
      ?? /DigitalSourceType="([^"]{1,160})"/i.exec(xmp)?.[1];
    const label = /<photoshop:Instructions>([^<]{1,200})</i.exec(xmp)?.[1];
    const summary = [
      creatorTool ? `CreatorTool=${creatorTool}` : "",
      dcCreator ? `creator=${dcCreator}` : "",
      sourceType ? `DigitalSourceType=${sourceType}` : "",
    ]
      .filter(Boolean)
      .join(", ");
    if (summary) {
      hits.push(
        hit("xmp", "generator-metadata", "XMP authorship record", sourceType ? 80 : 35, summary, "XMP packet", "neutral",
          "XMP is the industry's descriptive metadata block. CreatorTool names the software that last wrote the file.")
      );
      if (creatorTool && !software) software = creatorTool;
    }
    if (sourceType) {
      const aiSource = /trainedAlgorithmic|compositeWithTrained/i.test(sourceType);
      hits.push(
        hit(
          aiSource ? "xmp-ai-source" : "xmp-source",
          aiSource ? "ai-label" : "generator-metadata",
          aiSource ? "XMP declares AI-generated media" : "XMP digital source type declared",
          aiSource ? 95 : 45,
          sourceType,
          "Iptc4xmpExt:DigitalSourceType",
          aiSource ? "risk" : "neutral",
          aiSource
            ? "This is not a guess: the file itself declares that its pixels were produced by a trained model. That is a direct provenance admission."
            : "The file declares where its content came from. Compare it with the camera record."
        )
      );
    }
    const historyCount = (xmp.match(/stEvt:action/g) ?? []).length;
    if (historyCount) {
      hits.push(
        hit("xmp-history", "claim", `Edit history inside the file (${historyCount} step${historyCount > 1 ? "s" : ""})`,
          20, `${historyCount} stEvt:action entries`, "XMP xmpMM:History", "neutral",
          "The editing history travels with the image, so you can see which tools touched it and in what order.")
      );
    }
    if (label) {
      hits.push(hit("xmp-label", "ai-label", "Author instruction embedded", 25, label, "photoshop:Instructions", "neutral",
        "An embedded instruction or caption can reveal the workflow used to produce the image."));
    }
  }

  // PNG text chunks
  if (/png|image/i.test(mime) && bytes[0] === 0x89) {
    const chunks = readPngText(bytes);
    for (const chunk of chunks) {
      const key = chunk.keyword.toLowerCase();
      if (/parameters|prompt|workflow|comment|software|source/i.test(key)) {
        const looksAi = PROMPT_MARKERS.test(chunk.value) || PROMPT_JSON.test(chunk.value);
        hits.push(
          hit(
            `png-${key}`,
            looksAi ? "prompt" : "generator-metadata",
            looksAi ? "Image-generation parameters embedded" : `PNG text chunk "${chunk.keyword}"`,
            looksAi ? 90 : 30,
            chunk.value.replace(/\s+/g, " ").slice(0, 200),
            `PNG ${chunk.keyword} chunk`,
            looksAi ? "risk" : "neutral",
            looksAi
              ? "Sampler, steps, seed and prompt are the working notes of a diffusion model. Their presence is direct evidence the image was generated."
              : "Text chunks often record the software, author or copyright — useful provenance context."
          )
        );
        if (/steps|sampler|cfg/i.test(chunk.value)) {
          hits.push(
            hit("png-prompt", "prompt", "Generation recipe in the file", 88,
              chunk.value.slice(0, 180), `PNG ${chunk.keyword}`,
              "risk", "The exact prompt and sampler settings were saved with the image.")
          );
        }
      }
    }
  }

  // C2PA / JUMBF boxes
  const c2paIndex = head.toLowerCase().search(/c2pa|jumbf|content credentials|contentauth/);
  const c2pa = c2paIndex >= 0;
  if (c2pa) {
    const snippet = head.slice(Math.max(0, c2paIndex - 40), Math.min(head.length, c2paIndex + 160)).replace(/[^\x20-\x7e]/g, "·");
    hits.push(
      hit("c2pa", "c2pa", "C2PA Content Credentials container", 70, snippet, "JUMBF box (C2PA)", "neutral",
        "C2PA is a cryptographically signed provenance manifest. It can state the capture device, the edits applied and whether AI was used — and it can be verified.")
    );
  }

  // AI declarations anywhere in the bytes
  for (const rule of AI_LABELS) {
    const m = rule.re.exec(haystack);
    if (!m) continue;
    // The XMP block already reports trainedAlgorithmicMedia with more context.
    if (/trained algorithmic/i.test(rule.label) && hits.some((h) => h.id === "xmp-ai-source")) continue;
    if (hits.some((h) => h.id === `ai-${rule.label}`)) continue;
    const idx = Math.max(0, m.index - 60);
    hits.push(
      hit(
        `ai-${rule.label}`,
        "ai-label",
        rule.label,
        rule.strength,
        haystack.slice(idx, idx + 180).replace(/[^\x20-\x7e·]/g, " ").replace(/\s+/g, " "),
        "embedded metadata / strings",
        "risk",
        "A generative-tool name or AI disclosure is written into the file itself. One hit is direct provenance; several together are conclusive."
      )
    );
    break;
  }

  const generator = GENERATOR_MARKERS.find((m) => m.pattern.test(haystack));
  const aiGenerator = generator?.label ?? null;
  if (generator && !hits.some((h) => h.kind === "ai-label")) {
    hits.push(
      hit("generator", "generator-metadata", `Generator fingerprint: ${generator.label}`, generator.weight,
        (new RegExp(generator.pattern.source, "i").exec(haystack)?.[0] ?? generator.label),
        "embedded strings", "risk",
        `The file carries a ${generator.label} signature. Provenance markers like this are far stronger evidence than any statistical score.`)
    );
  }

  if (PROMPT_MARKERS.test(haystack) && !hits.some((h) => h.id === "png-prompt")) {
    const m = PROMPT_MARKERS.exec(haystack);
    hits.push(
      hit("prompt-any", "prompt", "Generation settings found in the file", 84, m?.[0] ?? "steps / sampler / seed",
        "embedded strings", "risk",
        "Diffusion tools save sampler, steps and seed next to the pixels. These settings are not present in camera files.")
    );
  }

  const editor = EDITOR_MARKERS.find((m) => m.re.test(haystack));
  if (editor) {
    hits.push(
      hit("editor", "editor", `Edited with ${editor.label}`, 20, editor.label, "metadata / strings", "neutral",
        "An editor was used. Editing is normal and does not mean AI; the section below shows whether anything was regenerated.")
    );
  }

  const cameraFromText = CAMERA_MAKERS.find((m) => m.re.test(haystack));
  if (!device && cameraFromText) {
    device = cameraFromText.label;
    hits.push(
      hit("device-strings", "camera-exif", `Device name in file: ${cameraFromText.label}`, 45, cameraFromText.label,
        "embedded strings", "good",
        "A camera model name appears in the file. It supports authenticity but is easier to forge than a full EXIF block.")
    );
  }

  const aiDeclared = hits.some((h) => h.kind === "ai-label" && h.strength >= 80);
  const promptEmbedded = hits.some((h) => h.kind === "prompt");
  const hasCameraExif = hits.some((h) => h.id === "exif-camera");

  return {
    hits,
    device,
    software,
    hasCameraExif,
    hasAnyExif,
    gps,
    c2pa,
    aiDeclared,
    promptEmbedded,
    aiGenerator,
    editor: editor?.label ?? null,
    qualityHint: jpegQualityHint(bytes),
    stringsSeen: strings.length,
  };
}

/** Hidden-text watermark / AI-tell inspection for documents and plain text. */
export function inspectInvisibleText(text: string): WatermarkHit[] {
  const hits: WatermarkHit[] = [];
  const zeroWidth = text.match(/[\u200b-\u200f\u2060-\u2064\ufeff]/g) ?? [];
  const variants = text.match(/[\ufe00-\ufe0f\u{e0100}-\u{e01ef}]/gu) ?? [];
  const tagChars = text.match(/[\u{e0000}-\u{e007f}]/gu) ?? [];

  if (zeroWidth.length >= 4) {
    hits.push(
      hit("zero-width", "invisible-text", "Zero-width characters embedded in the text", 72,
        `${zeroWidth.length} invisible code points (U+200B…U+FEFF)`,
        "character stream", "risk",
        "Invisible characters can carry a hidden payload — a watermark used to trace a copy, or a prompt-injection payload invisible to a human reader. Strip them before publishing.")
    );
  }
  if (tagChars.length) {
    hits.push(
      hit("tag-chars", "invisible-text", "Unicode tag characters found", 85,
        `${tagChars.length} tag code points (U+E0000 block)`, "character stream", "risk",
        "Tag characters are invisible in every editor but can encode a full hidden message. Models and watermark tools use them; a human never types them.")
    );
  }
  if (variants.length > 6) {
    hits.push(
      hit("variation-selectors", "invisible-text", "Variation-selector cluster", 55,
        `${variants.length} variation selectors`, "character stream", "neutral",
        "Long runs of variation selectors are a known carrier for invisible watermarking. Normal prose uses almost none.")
    );
  }
  const aiVoice = /as an (ai|artificial intelligence) (language )?model|i cannot browse|i'm sorry, but i (can't|cannot) assist/i.exec(text);
  if (aiVoice) {
    hits.push(
      hit("ai-voice", "ai-label", "Assistant boilerplate left in the text", 90, aiVoice[0],
        "visible text", "risk",
        "The text still contains a language model's own refusal or self-description. This is a copy-paste artefact, not an authorship inference.")
    );
  }
  return hits;
}
