import { useSyncExternalStore } from "react";
import type { CaseFile, EvidenceItem, PostureAnswers, ScanResult, WebsiteAudit } from "./types";
import { sha256, uid } from "./hash";

const STORAGE_KEY = "act-forensics.v2";

export interface AppState {
  cases: CaseFile[];
  activeCaseId: string;
}

export const defaultPosture: PostureAnswers = {
  https: true,
  mfa: false,
  rateLimit: false,
  strongPasswords: true,
  waf: false,
  sessionExpiry: false,
  leastPrivilege: false,
  logging: true,
  encryptionAtRest: false,
  dependencyScanning: false,
};

/** Blobs live only in memory — used for region re-analysis and integrity re-checks. */
export const mediaCache = new Map<string, Blob>();

function emptyCase(name = "Untitled case"): CaseFile {
  const stamp = new Date().toISOString();
  return {
    id: uid("case"),
    name,
    reference: `ACT-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
    createdAt: stamp,
    evidence: [],
    scans: [],
    audits: [],
    posture: { ...defaultPosture },
  };
}

function initialState(): AppState {
  const createdAt = new Date().toISOString();
  const first: CaseFile = {
    id: uid("case"),
    name: "Harbour fraud — digital exhibits",
    reference: "ACT-2026-0142",
    createdAt,
    evidence: [],
    scans: [],
    audits: [],
    posture: { ...defaultPosture },
  };
  return { cases: [first], activeCaseId: first.id };
}

function load(): AppState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return initialState();
    const parsed = JSON.parse(raw) as AppState;
    if (!parsed.cases?.length) return initialState();
    // Older sessions predate website audits; default them instead of breaking.
    parsed.cases = parsed.cases.map((c) => ({ ...c, audits: c.audits ?? [] }));
    return parsed;
  } catch {
    return initialState();
  }
}

let state: AppState = load();
const listeners = new Set<() => void>();

function commit(next: AppState) {
  state = next;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  } catch {
    /* storage may be full or blocked; session state still works */
  }
  listeners.forEach((l) => l());
}

export function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function getState(): AppState {
  return state;
}

export function useAppStore(): AppState {
  return useSyncExternalStore(subscribe, getState, getState);
}

export function activeCase(s: AppState = state): CaseFile {
  return s.cases.find((c) => c.id === s.activeCaseId) ?? s.cases[0];
}

export function updateCase(caseId: string, updater: (c: CaseFile) => CaseFile) {
  commit({
    ...state,
    cases: state.cases.map((c) => (c.id === caseId ? updater(c) : c)),
  });
}

export function createCase(name: string): string {
  const fresh = emptyCase(name.trim() || "Untitled case");
  commit({ cases: [...state.cases, fresh], activeCaseId: fresh.id });
  return fresh.id;
}

export function deleteCase(caseId: string) {
  const remaining = state.cases.filter((c) => c.id !== caseId);
  if (!remaining.length) {
    const fresh = emptyCase();
    commit({ cases: [fresh], activeCaseId: fresh.id });
    return;
  }
  commit({
    cases: remaining,
    activeCaseId: state.activeCaseId === caseId ? remaining[0].id : state.activeCaseId,
  });
}

export function setActiveCase(caseId: string) {
  commit({ ...state, activeCaseId: caseId });
}

export function addEvidence(caseId: string, item: EvidenceItem) {
  updateCase(caseId, (c) => ({ ...c, evidence: [item, ...c.evidence] }));
}

export function updateEvidence(caseId: string, itemId: string, patch: Partial<EvidenceItem>) {
  updateCase(caseId, (c) => ({
    ...c,
    evidence: c.evidence.map((e) => (e.id === itemId ? { ...e, ...patch } : e)),
  }));
}

export function removeEvidence(caseId: string, itemId: string) {
  mediaCache.delete(itemId);
  updateCase(caseId, (c) => ({ ...c, evidence: c.evidence.filter((e) => e.id !== itemId) }));
}

export function addScan(caseId: string, scan: ScanResult) {
  updateCase(caseId, (c) => ({ ...c, scans: [scan, ...c.scans].slice(0, 40) }));
}

export function addAudit(caseId: string, audit: WebsiteAudit) {
  updateCase(caseId, (c) => ({ ...c, audits: [audit, ...(c.audits ?? [])].slice(0, 20) }));
}

export function setPosture(caseId: string, posture: PostureAnswers) {
  updateCase(caseId, (c) => ({ ...c, posture }));
}

export async function verifyIntegrity(caseId: string, item: EvidenceItem): Promise<EvidenceItem["integrity"]> {
  const blob = mediaCache.get(item.id);
  let result: NonNullable<EvidenceItem["integrity"]>;
  if (!blob) {
    result = { status: "unavailable", checkedAt: new Date().toISOString() };
  } else {
    const buffer = await blob.arrayBuffer();
    const fresh = await sha256(buffer);
    result = {
      status: fresh === item.hash ? "verified" : "modified",
      checkedAt: new Date().toISOString(),
    };
  }
  updateEvidence(caseId, item.id, { integrity: result });
  return result;
}

export function replaceCase(next: CaseFile) {
  commit({ ...state, cases: state.cases.map((c) => (c.id === next.id ? next : c)), activeCaseId: next.id });
}

export function resetAll() {
  const fresh = initialState();
  commit(fresh);
}
