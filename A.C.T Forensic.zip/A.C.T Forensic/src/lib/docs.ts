import { inflateSync, unzipSync, strFromU8 } from "fflate";
import { asciiStrings, readPdfInfo } from "./meta";

export interface ExtractedDocument {
  text: string;
  metadata: Record<string, string>;
  method: string;
  notes: string[];
}

const decode = (bytes: Uint8Array) => {
  try {
    return new TextDecoder("utf-8", { fatal: false }).decode(bytes);
  } catch {
    return new TextDecoder("latin1").decode(bytes);
  }
};

function stripXml(xml: string): string {
  return xml
    .replace(/<w:tab[^>]*\/>/g, "\t")
    .replace(/<\/w:p>/g, "\n")
    .replace(/<w:br[^>]*\/>/g, "\n")
    .replace(/<[^>]+>/g, "")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#\d+;/g, " ")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n");
}

function extractDocxText(bytes: Uint8Array): { text: string; notes: string[] } {
  const notes: string[] = [];
  const files = unzipSync(bytes);
  const names = Object.keys(files);
  const docXml = files["word/document.xml"];
  if (!docXml) return { text: "", notes: ["No word/document.xml found in the archive."] };
  let text = stripXml(strFromU8(docXml));
  if (files["docProps/app.xml"]) {
    const app = strFromU8(files["docProps/app.xml"]);
    const application = app.match(/<Application>([^<]*)<\/Application>/)?.[1];
    if (application) notes.push(`Produced by application tag: ${application}`);
  }
  const core = files["docProps/core.xml"] ? strFromU8(files["docProps/core.xml"]) : "";
  const creator = core.match(/<dc:creator>([^<]*)<\/dc:creator>/)?.[1];
  const modified = core.match(/<dcterms:modified[^>]*>([^<]*)</)?.[1];
  if (creator) notes.push(`Document author metadata: ${creator}`);
  if (modified) notes.push(`Last modified metadata: ${modified}`);
  const revisions = core.match(/<cp:revision>([^<]*)</)?.[1];
  if (revisions) notes.push(`Revision counter: ${revisions} (low counters can indicate first-pass generation)`);
  if (names.includes("word/vbaProject.bin")) notes.push("Contains macros (vbaProject.bin) — treat as active content.");
  text = text.slice(0, 120000);
  return { text, notes };
}

function inflatePdfStreams(bytes: Uint8Array): string[] {
  const streams: string[] = [];
  const latin = new TextDecoder("latin1").decode(bytes);
  const re = /stream\r?\n/g;
  let match: RegExpExecArray | null;
  let guard = 0;
  while ((match = re.exec(latin)) && guard < 400) {
    guard++;
    const start = match.index + match[0].length;
    const end = latin.indexOf("endstream", start);
    if (end < 0) break;
    const raw = bytes.subarray(start, end);
    try {
      const out = inflateSync(raw);
      streams.push(new TextDecoder("latin1").decode(out));
    } catch {
      const guess = new TextDecoder("latin1").decode(raw.subarray(0, 20000));
      if (/BT|Tj|TJ/.test(guess)) streams.push(guess);
    }
    re.lastIndex = end + 9;
  }
  return streams;
}

function pdfTextFromContent(content: string): string {
  const chunks: string[] = [];
  const re = /\((?:\\.|[^\\()])*\)/g;
  let m: RegExpExecArray | null;
  let guard = 0;
  while ((m = re.exec(content)) && guard < 8000) {
    guard++;
    const raw = m[0].slice(1, -1);
    const decoded = raw
      .replace(/\\([nrtbf()\\])/g, (_x, c: string) =>
        c === "n" ? "\n" : c === "r" ? "" : c === "t" ? "\t" : c
      )
      .replace(/\\([0-7]{1,3})/g, (_x, oct: string) => String.fromCharCode(parseInt(oct, 8)));
    if (/[a-zA-Z]{2,}/.test(decoded)) chunks.push(decoded);
  }
  return chunks.join(" ").replace(/\s+/g, " ").trim();
}

export function extractDocument(bytes: Uint8Array, kind: string, mime: string): ExtractedDocument {
  const notes: string[] = [];
  const metadata: Record<string, string> = {};

  if (kind === "docx") {
    try {
      const { text, notes: docNotes } = extractDocxText(bytes);
      return {
        text,
        metadata: { Container: "OOXML (DOCX)", ...(docNotes.length ? { "Embedded hints": String(docNotes.length) } : {}) },
        method: "OOXML unzip + XML text extraction",
        notes: docNotes,
      };
    } catch (err) {
      return { text: "", metadata: {}, method: "failed", notes: [`DOCX parsing failed: ${String(err)}`] };
    }
  }

  if (kind === "pdf") {
    const info = readPdfInfo(bytes);
    Object.assign(metadata, info);
    const rawText = new TextDecoder("latin1").decode(bytes);
    const activeMarkers: string[] = [];
    for (const [marker, label] of [
      ["/JavaScript", "Embedded JavaScript"],
      ["/JS", "JavaScript action"],
      ["/Launch", "Launch action (can execute local files)"],
      ["/OpenAction", "Automatic action on open"],
      ["/EmbeddedFile", "Embedded file attachment"],
      ["/AA", "Additional-actions dictionary"],
    ] as const) {
      if (rawText.includes(marker)) activeMarkers.push(label);
    }
    if (activeMarkers.length) notes.push(`Active content detected: ${activeMarkers.join(", ")}.`);
    const streams = inflatePdfStreams(bytes);
    let text = streams.map(pdfTextFromContent).join("\n").trim();
    if (text.length < 80) {
      const strings = asciiStrings(bytes, 8, 500).filter((s) => /[a-zA-Z]{3,}\s+[a-zA-Z]{3,}/.test(s));
      text = strings.join(" ").slice(0, 40000);
      if (text) notes.push("Text recovered from uncompressed object streams (partial extraction).");
    }
    metadata["Text streams decoded"] = String(streams.length);
    if (/ChatGPT|OpenAI|Gemini|Claude|Canva|ReportLab|LaTeX|Word/i.test(JSON.stringify(info))) {
      notes.push("Producer/creator metadata names a document generator — useful for provenance comparison.");
    }
    return {
      text: text.slice(0, 150000),
      metadata,
      method: `PDF stream inflation (${streams.length} streams)`,
      notes,
    };
  }

  // Plain text family
  const text = decode(bytes);
  const printable = text.replace(/[^\x09\x0a\x0d\x20-\x7e\u00a0-\uffff]/g, "");
  if (printable.length < text.length * 0.85) {
    notes.push("High proportion of non-printable bytes — file may be mislabelled or corrupted.");
  }
  metadata["Detected type"] = mime || kind;
  metadata["Characters"] = String(text.length);
  return {
    text: text.slice(0, 200000),
    metadata,
    method: "UTF-8 / Latin-1 text decode",
    notes,
  };
}
