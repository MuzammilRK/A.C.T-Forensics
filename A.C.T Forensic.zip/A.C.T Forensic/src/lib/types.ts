export type EvidenceKind = "image" | "video" | "audio" | "document" | "code" | "unknown";

export type Severity = "critical" | "high" | "medium" | "low" | "info";

export interface Signal {
  id: string;
  label: string;
  /** 0..1 contribution strength */
  strength: number;
  detail: string;
  tone: "risk" | "neutral" | "good";
}

export interface RegionHit {
  id: string;
  x: number; // 0..1
  y: number;
  w: number;
  h: number;
  score: number; // 0..100
  label: string;
  detail: string;
}

export interface SentenceFinding {
  text: string;
  score: number; // 0..100 AI likelihood
  reasons: string[];
}

export interface WatermarkHit {
  id: string;
  kind: "c2pa" | "generator-metadata" | "prompt" | "ai-label" | "invisible-text" | "camera-exif" | "editor" | "claim";
  label: string;
  strength: number; // 0..100
  evidence: string;
  where: string;
  tone: "risk" | "neutral" | "good";
  meaning: string;
}

export type CheckStatus = "pass" | "warn" | "fail" | "na";

export interface ForensicCheck {
  id: string;
  name: string;
  status: CheckStatus;
  metric: string;
  detail: string;
}

export interface ProvenanceReport {
  verdict: "authentic-capture" | "edited" | "synthetic" | "unknown";
  headline: string;
  plain: string;
  confidence: number;
  device: string | null;
  software: string | null;
  signed: boolean;
  aiDeclared: boolean;
  hits: WatermarkHit[];
}

export interface Keyframe {
  t: number;
  thumb: string;
  note: string;
  score: number;
}

export interface Analysis {
  kind: EvidenceKind;
  verdict: string;
  aiLikelihood: number; // 0..100
  confidence: number; // 0..100
  summary: string;
  /** One plain-language sentence a non-technical reader can act on. */
  plain?: string;
  signals: Signal[];
  metadata: Record<string, string>;
  regions?: RegionHit[];
  heatmap?: number[][];
  sentences?: SentenceFinding[];
  excerpt?: string;
  notes?: string[];
  provenance?: ProvenanceReport;
  checks?: ForensicCheck[];
  thumbnail?: string;
  waveform?: number[];
  spectrum?: number[];
  spectrumMaxHz?: number;
  keyframes?: Keyframe[];
}

export interface RegionQuery {
  rect: { x: number; y: number; w: number; h: number };
  score: number;
  verdict: string;
  reasons: string[];
  analyzedAt: string;
}

export interface EvidenceItem {
  id: string;
  name: string;
  mime: string;
  size: number;
  kind: EvidenceKind;
  hash: string;
  hashAt: string;
  addedAt: string;
  analysis: Analysis;
  source: "upload" | "demo";
  regionQuery?: RegionQuery;
  integrity?: { status: "verified" | "modified" | "unavailable"; checkedAt: string };
  textQuery?: { question: string; quote: string; score: number; verdict: string; reasons: string[] };
}

export interface VulnFinding {
  id: string;
  title: string;
  severity: Severity;
  category: string;
  cwe: string;
  location: string;
  snippet: string;
  detail: string;
  fix: string;
  confidence: number;
  weight: number;
}

export type ScanKind = "source" | "dependencies" | "posture";

export interface ScanResult {
  id: string;
  kind: ScanKind;
  target: string;
  createdAt: string;
  score: number; // 0..100 risk
  grade: string;
  findings: VulnFinding[];
  stats: Record<string, number | string>;
}

export interface GraphNode {
  id: string;
  label: string;
  layer: number;
  kind: "entry" | "weakness" | "asset" | "impact" | "evidence";
  severity?: Severity;
  detail?: string;
}

export interface GraphEdge {
  from: string;
  to: string;
  weight: number;
  label?: string;
}

export interface AttackPath {
  nodes: string[];
  probability: number;
  narrative: string;
  mitigation: string;
}

export interface CaseFile {
  id: string;
  name: string;
  reference: string;
  createdAt: string;
  evidence: EvidenceItem[];
  scans: ScanResult[];
  audits?: WebsiteAudit[];
  posture: PostureAnswers;
}

export interface WebFinding {
  id: string;
  title: string;
  severity: Severity;
  category: string;
  evidence: string;
  detail: string;
  fix: string;
  reference: string;
}

export interface WebsiteAudit {
  id: string;
  url: string;
  host: string;
  createdAt: string;
  score: number;
  grade: string;
  plain: string;
  via: string;
  headersAvailable: boolean;
  findings: WebFinding[];
  headers: { name: string; value: string; ok: boolean; note: string }[];
  inventory: Record<string, string>;
  topFixes: string[];
}

export interface PostureAnswers {
  https: boolean;
  mfa: boolean;
  rateLimit: boolean;
  strongPasswords: boolean;
  waf: boolean;
  sessionExpiry: boolean;
  leastPrivilege: boolean;
  logging: boolean;
  encryptionAtRest: boolean;
  dependencyScanning: boolean;
}

export const severityOrder: Severity[] = ["critical", "high", "medium", "low", "info"];

export function severityValue(s: Severity): number {
  return { critical: 10, high: 7.5, medium: 5, low: 2.5, info: 1 }[s];
}
