import type { CaseFile, GraphEdge, GraphNode, ScanResult, Severity } from "./types";
import { severityValue } from "./types";

/** Builds the Evidence Threat-Link Graph: entry points → weaknesses → assets → impacts,
 *  with evidence items attached to the assets they put at risk. */

export interface ThreatGraph {
  nodes: GraphNode[];
  edges: GraphEdge[];
  paths: {
    nodes: GraphNode[];
    probability: number;
    narrative: string;
    mitigation: string;
    severity: Severity;
  }[];
}

const ENTRY: Record<string, string> = {
  Injection: "entry_upload",
  Authentication: "entry_login",
  Session: "entry_login",
  "Access control": "entry_case_api",
  API: "entry_case_api",
  "Supply chain": "entry_packages",
  Upload: "entry_upload",
  Cryptography: "asset_vault",
  Transport: "entry_web",
  Misconfiguration: "entry_web",
  Secrets: "entry_packages",
  "Login & network posture": "entry_login",
};

const ASSET: Record<string, string> = {
  Injection: "asset_db",
  Authentication: "asset_session",
  Session: "asset_session",
  "Access control": "asset_db",
  API: "asset_db",
  "Supply chain": "asset_app",
  Upload: "asset_vault",
  Cryptography: "asset_vault",
  Transport: "asset_vault",
  Misconfiguration: "asset_app",
  Secrets: "asset_app",
  "Login & network posture": "asset_session",
};

export function buildThreatGraph(caseFile: CaseFile, includeEvidence = true): ThreatGraph {
  const nodes: GraphNode[] = [
    { id: "entry_web", label: "Public web surface", layer: 0, kind: "entry", detail: "Internet-facing pages, static assets and the report viewer." },
    { id: "entry_login", label: "Investigator login portal", layer: 0, kind: "entry", detail: "Credential and session endpoints." },
    { id: "entry_case_api", label: "Case management API", layer: 0, kind: "entry", detail: "REST endpoints that read and write case records." },
    { id: "entry_upload", label: "Evidence upload API", layer: 0, kind: "entry", detail: "Multipart evidence intake, hashing and storage." },
    { id: "entry_packages", label: "Third-party dependencies", layer: 0, kind: "entry", detail: "Libraries and build tooling pulled into the application." },
    { id: "asset_app", label: "Application server", layer: 2, kind: "asset", detail: "Runtime that holds secrets and talks to storage." },
    { id: "asset_session", label: "Investigator sessions", layer: 2, kind: "asset", detail: "Bearer tokens and cookies tied to examiner identity." },
    { id: "asset_db", label: "Case database", layer: 2, kind: "asset", detail: "Case metadata, statements, custody records." },
    { id: "asset_vault", label: "Evidence vault", layer: 2, kind: "asset", detail: "Original media, hashes and extracted artefacts." },
    { id: "asset_logs", label: "Audit log", layer: 2, kind: "asset", detail: "Append-only access trail used to prove integrity in court." },
    { id: "impact_takeover", label: "Unauthorised case access", layer: 3, kind: "impact", detail: "Attacker operates with investigator privileges." },
    { id: "impact_tamper", label: "Evidence manipulation", layer: 3, kind: "impact", detail: "Originals or findings altered, defeating prosecution." },
    { id: "impact_custody", label: "Chain-of-custody failure", layer: 3, kind: "impact", detail: "Integrity cannot be evidenced; evidence becomes inadmissible." },
  ];
  const edges: GraphEdge[] = [];
  const addEdge = (from: string, to: string, weight: number, label?: string) => {
    if (edges.some((e) => e.from === from && e.to === to)) return;
    edges.push({ from, to, weight, label });
  };

  addEdge("entry_login", "asset_session", 0.9, "issues session");
  addEdge("entry_case_api", "asset_db", 0.85, "reads/writes");
  addEdge("entry_upload", "asset_vault", 0.85, "stores");
  addEdge("entry_web", "asset_app", 0.6, "exposes");
  addEdge("entry_packages", "asset_app", 0.75, "runs inside");
  addEdge("asset_app", "asset_db", 0.7);
  addEdge("asset_app", "asset_vault", 0.7);
  addEdge("asset_vault", "asset_logs", 0.5, "hash record");
  addEdge("asset_session", "asset_db", 0.6);
  addEdge("asset_db", "impact_tamper", 0.85);
  addEdge("asset_vault", "impact_tamper", 0.9);
  addEdge("asset_session", "impact_takeover", 0.75);
  addEdge("asset_app", "impact_takeover", 0.8);
  addEdge("asset_logs", "impact_custody", 0.8);
  addEdge("asset_db", "impact_custody", 0.5);

  const scans: ScanResult[] = caseFile.scans;
  const allFindings = scans.flatMap((s) => s.findings.map((f) => ({ ...f, scanId: s.id })));
  const top = [...allFindings].sort((a, b) => severityValue(b.severity) - severityValue(a.severity)).slice(0, 8);

  for (const finding of top) {
    const id = `weak_${finding.id}`;
    const entry = ENTRY[finding.category] ?? "entry_web";
    const asset = ASSET[finding.category] ?? "asset_app";
    nodes.push({
      id,
      label: finding.title.length > 52 ? `${finding.title.slice(0, 50)}…` : finding.title,
      layer: 1,
      kind: "weakness",
      severity: finding.severity,
      detail: `${finding.detail} Fix: ${finding.fix}`,
    });
    addEdge(entry, id, Math.min(0.95, 0.45 + severityValue(finding.severity) / 14), finding.category);
    addEdge(id, asset, Math.min(0.92, 0.5 + finding.weight / 25));
  }

  if (includeEvidence) {
    for (const item of caseFile.evidence) {
      const risky = item.analysis.aiLikelihood >= 45 || item.integrity?.status === "modified";
      if (!risky && caseFile.evidence.length > 6) continue;
      const id = `ev_${item.id}`;
      nodes.push({
        id,
        label: item.name.length > 40 ? `${item.name.slice(0, 38)}…` : item.name,
        layer: 2,
        kind: "evidence",
        severity: item.integrity?.status === "modified" ? "critical" : item.analysis.aiLikelihood >= 68 ? "high" : "medium",
        detail: `${item.analysis.verdict} · ${item.analysis.aiLikelihood}% likelihood · SHA-256 ${item.hash.slice(0, 24)}…`,
      });
      const weight = Math.max(0.35, item.analysis.aiLikelihood / 100);
      addEdge(id, "asset_vault", weight, `${item.analysis.aiLikelihood}% suspicion`);
      if (item.analysis.aiLikelihood >= 60) addEdge(id, "impact_tamper", Math.min(0.9, weight));
    }
  }

  // Rank paths from entries to impacts
  const byId = new Map(nodes.map((n) => [n.id, n]));
  const adj = new Map<string, GraphEdge[]>();
  for (const e of edges) {
    if (!adj.has(e.from)) adj.set(e.from, []);
    adj.get(e.from)!.push(e);
  }
  const impacts = nodes.filter((n) => n.kind === "impact").map((n) => n.id);
  const rawPaths: { ids: string[]; prob: number }[] = [];

  const walk = (current: string, path: string[], prob: number) => {
    if (rawPaths.length > 400) return;
    if (impacts.includes(current)) {
      rawPaths.push({ ids: path, prob });
      return;
    }
    if (path.length > 5) return;
    for (const edge of adj.get(current) ?? []) {
      if (path.includes(edge.to)) continue;
      walk(edge.to, [...path, edge.to], prob * edge.weight);
    }
  };
  const entries = nodes.filter((n) => n.kind === "entry").map((n) => n.id);
  for (const e of entries) walk(e, [e], 1);

  const mitigationFor = (nodeIds: string[]) => {
    const weak = nodeIds.map((id) => byId.get(id)).filter((n): n is GraphNode => !!n && n.kind === "weakness");
    if (!weak.length) return "No exploitable weakness detected on this route — continue monitoring dependencies and access logs.";
    return weak[0].detail ?? "Apply the recommended fix from the vulnerability register.";
  };

  const ranked = rawPaths
    .filter((p) => p.ids.some((id) => byId.get(id)?.kind === "weakness"))
    .sort((a, b) => b.prob - a.prob)
    .slice(0, 6)
    .map((p) => {
      const pathNodes = p.ids.map((id) => byId.get(id)!).filter(Boolean);
      const weakness = pathNodes.find((n) => n.kind === "weakness");
      const impact = pathNodes[pathNodes.length - 1];
      return {
        nodes: pathNodes,
        probability: Math.round(Math.min(0.97, p.prob) * 100),
        severity: weakness?.severity ?? "medium",
        narrative: `${pathNodes.map((n) => n.label).join(" → ")}. An attacker reaching ${weakness?.label ?? "the asset"} can chain it into ${impact.label.toLowerCase()}.`,
        mitigation: mitigationFor(p.ids),
      };
    });

  if (!ranked.length) {
    const fallback = scans.flatMap((s) => s.findings).sort((a, b) => severityValue(b.severity) - severityValue(a.severity))[0];
    if (fallback) {
      const weak = nodes.find((n) => n.id === `weak_${fallback.id}`);
      const entry = nodes.find((n) => n.id === (ENTRY[fallback.category] ?? "entry_web"));
      if (weak && entry) {
        ranked.push({
          nodes: [entry, weak, byId.get(ASSET[fallback.category] ?? "asset_app")!, byId.get("impact_tamper")!],
          probability: 38,
          severity: fallback.severity,
          narrative: `${entry.label} → ${weak.label} → evidence manipulation.`,
          mitigation: fallback.fix,
        });
      }
    }
  }

  return { nodes, edges, paths: ranked };
}

export function linkSummary(caseFile: CaseFile) {
  const findings = caseFile.scans.flatMap((s) => s.findings);
  return caseFile.evidence.map((item) => {
    const matched = findings
      .filter((f) => {
        if (item.analysis.kind === "code") return f.category === "Injection" || f.category === "Supply chain";
        if (item.analysis.kind === "image" || item.analysis.kind === "video") return f.category === "Upload" || f.category === "Access control";
        return f.category === "Access control" || f.category === "Cryptography";
      })
      .sort((a, b) => severityValue(b.severity) - severityValue(a.severity));
    return {
      evidence: item,
      exposures: matched.slice(0, 3),
      risk: Math.min(
        100,
        Math.round(item.analysis.aiLikelihood * 0.75 + (item.integrity?.status === "modified" ? 30 : 0) + matched.length * 6)
      ),
    };
  });
}
