import type { CaseFile } from "./types";
import { buildThreatGraph } from "./graph";
import { formatBytes } from "./hash";

export interface ManifestRow {
  name: string;
  kind: string;
  size: string;
  sha256: string;
  registered: string;
  status: string;
}

export function buildManifest(caseFile: CaseFile): ManifestRow[] {
  return caseFile.evidence.map((e) => ({
    name: e.name,
    kind: e.kind,
    size: formatBytes(e.size),
    sha256: e.hash,
    registered: e.hashAt,
    status: e.integrity?.status ?? "baseline recorded",
  }));
}

export function buildReportJson(caseFile: CaseFile) {
  const graph = buildThreatGraph(caseFile);
  const findings = caseFile.scans.flatMap((s) => s.findings);
  return {
    generator: "A.C.T Forensics v1.0",
    generatedAt: new Date().toISOString(),
    case: {
      id: caseFile.id,
      name: caseFile.name,
      reference: caseFile.reference,
      openedAt: caseFile.createdAt,
    },
    summary: {
      exhibits: caseFile.evidence.length,
      meanSyntheticLikelihood: caseFile.evidence.length
        ? Math.round(caseFile.evidence.reduce((a, e) => a + e.analysis.aiLikelihood, 0) / caseFile.evidence.length)
        : 0,
      scans: caseFile.scans.length,
      findings: findings.length,
      critical: findings.filter((f) => f.severity === "critical").length,
      high: findings.filter((f) => f.severity === "high").length,
      attackPaths: graph.paths.length,
    },
    exhibits: caseFile.evidence.map((e) => ({
      name: e.name,
      kind: e.kind,
      mime: e.mime,
      sizeBytes: e.size,
      sha256: e.hash,
      hashRegisteredAt: e.hashAt,
      integrity: e.integrity?.status ?? "baseline recorded",
      verdict: e.analysis.verdict,
      syntheticLikelihood: e.analysis.aiLikelihood,
      confidence: e.analysis.confidence,
      plainLanguage: e.analysis.plain,
      signals: e.analysis.signals.map((s) => ({ label: s.label, detail: s.detail })),
      checks: e.analysis.checks ?? [],
      provenance: e.analysis.provenance ?? null,
      metadata: e.analysis.metadata,
      regionQuery: e.regionQuery
        ? { score: e.regionQuery.score, verdict: e.regionQuery.verdict, reasons: e.regionQuery.reasons }
        : null,
      quotedPortion: e.textQuery ?? null,
    })),
    scans: caseFile.scans.map((s) => ({
      target: s.target,
      kind: s.kind,
      score: s.score,
      grade: s.grade,
      createdAt: s.createdAt,
      findings: s.findings,
    })),
    attackPaths: graph.paths.map((p) => ({
      chain: p.nodes.map((n) => n.label),
      likelihood: p.probability,
      narrative: p.narrative,
      mitigation: p.mitigation,
    })),
    websiteAudits: (caseFile.audits ?? []).map((a) => ({
      url: a.url,
      score: a.score,
      grade: a.grade,
      scannedAt: a.createdAt,
      fetchedVia: a.via,
      headersInspected: a.headersAvailable,
      findings: a.findings,
      headers: a.headers,
      inventory: a.inventory,
    })),
    posture: caseFile.posture,
    methodology: [
      "Provenance: C2PA/JUMBF manifests, XMP DigitalSourceType, EXIF camera records, PNG text chunks and embedded generation prompts are read directly from the file bytes before any statistical test.",
      "Images: error-level analysis via JPEG recompression, Laplacian noise-floor consistency, copy-move block matching, EXIF/XMP/PNG-text provenance.",
      "Video: container and encoder metadata plus sampled-frame exposure and colour-consistency checks.",
      "Audio: container metadata, spectral cutoff, high-band energy, digital-silence share and clipping.",
      "Documents: text extraction (PDF streams, DOCX OOXML), active-content detection and stylistic AI-authorship modelling.",
      "Integrity: SHA-256 computed in-browser with WebCrypto at intake and recomputed on verification.",
      "Applications: static rules with CWE mapping, dependency advisory comparison, and a login/network posture audit.",
    ],
    disclaimer:
      "Likelihood scores are investigative indicators produced by deterministic heuristics. They are not a legal determination of authenticity or authorship and must be corroborated by an accredited examiner with access to original media.",
  };
}

export function buildReportMarkdown(caseFile: CaseFile): string {
  const json = buildReportJson(caseFile);
  const lines: string[] = [];
  lines.push(`# A.C.T Forensics — Forensic Analysis Report`);
  lines.push("");
  lines.push(`**Case:** ${json.case.name}  `);
  lines.push(`**Reference:** ${json.case.reference}  `);
  lines.push(`**Opened:** ${new Date(json.case.openedAt).toLocaleString()}  `);
  lines.push(`**Report generated:** ${new Date(json.generatedAt).toLocaleString()}`);
  lines.push("");
  lines.push(`## 1. Summary`);
  lines.push("");
  lines.push(`| Metric | Value |`);
  lines.push(`| --- | --- |`);
  lines.push(`| Exhibits analysed | ${json.summary.exhibits} |`);
  lines.push(`| Mean synthetic likelihood | ${json.summary.meanSyntheticLikelihood}% |`);
  lines.push(`| Application scans | ${json.summary.scans} |`);
  lines.push(`| Findings (critical / high) | ${json.summary.findings} (${json.summary.critical} / ${json.summary.high}) |`);
  lines.push(`| Predicted attack paths | ${json.summary.attackPaths} |`);
  lines.push("");
  lines.push(`## 2. Digital evidence`);
  json.exhibits.forEach((e, i) => {
    lines.push("");
    lines.push(`### 2.${i + 1} ${e.name}`);
    lines.push("");
    lines.push(`- Type: ${e.kind} · ${e.sizeBytes} bytes · ${e.mime || "unknown MIME"}`);
    lines.push(`- SHA-256: \`${e.sha256}\` (registered ${new Date(e.hashRegisteredAt).toLocaleString()})`);
    lines.push(`- Integrity: ${e.integrity}`);
    lines.push(`- Finding: **${e.verdict}** — ${e.syntheticLikelihood}% synthetic likelihood (confidence ${e.confidence}%)`);
    if (e.plainLanguage) lines.push(`- In plain words: ${e.plainLanguage}`);
    if (e.provenance) {
      lines.push(`- Provenance: ${e.provenance.headline}`);
      e.provenance.hits.slice(0, 5).forEach((h) => lines.push(`  - ${h.label} (${h.where}): ${h.evidence}`));
    }
    e.checks.filter((c) => c.status === "warn" || c.status === "fail").forEach((c) =>
      lines.push(`  - ${c.name}: ${c.metric} — ${c.detail}`)
    );
    e.signals.slice(0, 6).forEach((s) => lines.push(`  - ${s.label}: ${s.detail}`));
    if (e.regionQuery) {
      lines.push(`- Region query: ${e.regionQuery.score}% — ${e.regionQuery.verdict}`);
    }
    if (e.quotedPortion) {
      lines.push(`- Quoted portion check: ${e.quotedPortion.score}% — ${e.quotedPortion.verdict}`);
    }
  });
  lines.push("");
  lines.push(`## 3. Application weaknesses`);
  lines.push("");
  if (!json.scans.length) lines.push("_No application scans were recorded._");
  json.scans.forEach((s, i) => {
    lines.push(`### 3.${i + 1} ${s.target} — risk ${s.score}/100 (grade ${s.grade})`);
    lines.push("");
    lines.push(`| Severity | Finding | CWE | Location | Fix |`);
    lines.push(`| --- | --- | --- | --- | --- |`);
    s.findings.forEach((f) => {
      lines.push(`| ${f.severity} | ${f.title} | ${f.cwe} | ${f.location} | ${f.fix.replace(/\|/g, "/")} |`);
    });
    lines.push("");
  });
  lines.push(`## 3b. Website source review`);
  lines.push("");
  if (!json.websiteAudits.length) lines.push("_No websites were scanned._");
  json.websiteAudits.forEach((a, i) => {
    lines.push(`### 3b.${i + 1} ${a.url} — risk ${a.score}/100 (grade ${a.grade})`);
    lines.push(`Scanned ${new Date(a.scannedAt).toLocaleString()} (${a.fetchedVia}).`);
    lines.push("");
    a.findings.forEach((f) => lines.push(`- **${f.severity.toUpperCase()}** ${f.title} — ${f.detail} Fix: ${f.fix}`));
    lines.push("");
  });
  lines.push(`## 4. Predicted attack paths`);
  lines.push("");
  if (!json.attackPaths.length) lines.push("_No attack paths could be generated._");
  json.attackPaths.forEach((p, i) => {
    lines.push(`${i + 1}. **${p.likelihood}% — ${p.chain.join(" → ")}**`);
    lines.push(`   - ${p.narrative}`);
    lines.push(`   - Recommended fix: ${p.mitigation}`);
  });
  lines.push("");
  lines.push(`## 5. Integrity manifest`);
  lines.push("");
  lines.push(`| Exhibit | SHA-256 | Registered | Status |`);
  lines.push(`| --- | --- | --- | --- |`);
  buildManifest(caseFile).forEach((m) => {
    lines.push(`| ${m.name} | \`${m.sha256}\` | ${new Date(m.registered).toLocaleString()} | ${m.status} |`);
  });
  lines.push("");
  lines.push(`## 6. Methodology & limitations`);
  lines.push("");
  json.methodology.forEach((m) => lines.push(`- ${m}`));
  lines.push("");
  lines.push(`> ${json.disclaimer}`);
  return lines.join("\n");
}
