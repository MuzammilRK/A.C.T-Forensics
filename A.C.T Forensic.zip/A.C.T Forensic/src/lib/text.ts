import type { SentenceFinding, Signal } from "./types";
import { clamp } from "./hash";

/** Heuristic AI-authorship detector. Explainable, deterministic, runs fully offline. */

const AI_PHRASES: { re: RegExp; label: string; weight: number }[] = [
  { re: /it is (important|worth|crucial) to (note|mention|remember)/i, label: "\"it is important to note\" framing", weight: 16 },
  { re: /in today'?s (fast-paced|ever-changing|digital|modern)/i, label: "generic scene-setting opener", weight: 18 },
  { re: /\b(furthermore|moreover|additionally|consequently)\b/i, label: "formal connective", weight: 7 },
  { re: /\b(delve|delving)\b/i, label: "\"delve\"", weight: 14 },
  { re: /\b(underscore[sd]?|underscoring)\b/i, label: "\"underscore\"", weight: 9 },
  { re: /a testament to|stands as a testament/i, label: "\"testament to\"", weight: 16 },
  { re: /\b(seamless(ly)?|robust|cutting-edge|state-of-the-art)\b/i, label: "marketing adjective", weight: 9 },
  { re: /\b(leverage|leveraging|harness(ing)?)\b/i, label: "\"leverage / harness\"", weight: 8 },
  { re: /\b(pivotal|crucial|paramount|multifaceted|holistic)\b/i, label: "inflated evaluative adjective", weight: 8 },
  { re: /\bever-(evolving|changing|growing)\b/i, label: "\"ever-evolving\"", weight: 14 },
  { re: /\b(landscape|realm|tapestry|myriad|plethora)\b/i, label: "abstract noun padding", weight: 8 },
  { re: /\b(in conclusion|to summari[sz]e|overall,)/i, label: "formulaic closing", weight: 10 },
  { re: /not only .{3,60} but also/i, label: "\"not only … but also\" construction", weight: 12 },
  { re: /\b(plays? a (vital|crucial|key|significant) role)\b/i, label: "\"plays a … role\"", weight: 11 },
  { re: /\b(transformative|revolutioni[sz]e|game-?changer|unlock the (potential|power))\b/i, label: "hype vocabulary", weight: 12 },
  { re: /\b(foster(ing)?|facilitate|empower(ing)?)\b/i, label: "policy-register verb", weight: 6 },
  { re: /\b(firstly|secondly|thirdly|lastly)\b/i, label: "enumerative connector", weight: 6 },
  { re: /\b(it is essential|it is imperative|it should be noted)\b/i, label: "impersonal directive", weight: 11 },
];

const CONTRACTION = /\b\w+'(t|s|re|ve|ll|d|m)\b/gi;
const EM_DASH = /—|–/g;
const TRANSITION_START =
  /^(However|Moreover|Furthermore|Additionally|Consequently|Ultimately|Overall|In conclusion|Firstly|Secondly|Finally|Notably|Indeed|Thus|Therefore)\b/i;

export interface TextStats {
  words: number;
  sentences: number;
  paragraphs: number;
  avgSentenceWords: number;
  sentenceStdev: number;
  typeTokenRatio: number;
  contractionsPer100: number;
  emDashPer100: number;
  avgSentenceLengthLabel: string;
}

export interface TextAnalysisResult {
  aiLikelihood: number;
  verdict: string;
  confidence: number;
  signals: Signal[];
  sentences: SentenceFinding[];
  stats: TextStats;
  excerpt: string;
}

export function splitSentences(text: string): string[] {
  const cleaned = text.replace(/\s+/g, " ").trim();
  if (!cleaned) return [];
  const parts = cleaned.match(/[^.!?…]+(?:[.!?…]+|$)/g) ?? [cleaned];
  return parts.map((s) => s.trim()).filter((s) => s.split(/\s+/).length > 2);
}

function wordsOf(text: string): string[] {
  return text.toLowerCase().match(/[a-z']+/g) ?? [];
}

export function analyzeText(raw: string, opts: { context?: string } = {}): TextAnalysisResult {
  const text = raw.replace(/\r/g, "").trim();
  const words = wordsOf(text);
  const sentences = splitSentences(text);
  const paragraphs = text.split(/\n\s*\n/).filter((p) => p.trim().length > 40).length || 1;
  const sentenceLengths = sentences.map((s) => s.split(/\s+/).length);
  const avg = sentenceLengths.reduce((a, b) => a + b, 0) / Math.max(1, sentenceLengths.length);
  const variance =
    sentenceLengths.reduce((a, len) => a + (len - avg) ** 2, 0) / Math.max(1, sentenceLengths.length);
  const stdev = Math.sqrt(variance);
  const unique = new Set(words);
  const ttr = unique.size / Math.max(1, words.length);
  const contractions = (text.match(CONTRACTION) ?? []).length;
  const emDashes = (text.match(EM_DASH) ?? []).length;
  const per100 = words.length ? 100 / words.length : 0;

  const phraseHits: { label: string; count: number; weight: number }[] = [];
  for (const p of AI_PHRASES) {
    const matches = text.match(new RegExp(p.re.source, p.re.flags.includes("g") ? p.re.flags : p.re.flags + "g"));
    if (matches?.length) phraseHits.push({ label: p.label, count: matches.length, weight: p.weight });
  }
  const phraseScore = Math.min(34, phraseHits.reduce((a, h) => a + h.weight * Math.min(3, h.count) * 0.7, 0));
  const transitionStarts = sentences.filter((s) => TRANSITION_START.test(s)).length;
  const transitionRatio = transitionStarts / Math.max(1, sentences.length);

  // Sentence-length uniformity: human prose mixes long and very short sentences.
  const cv = stdev / Math.max(1, avg);
  let uniformity = 0;
  if (sentences.length >= 4) {
    if (cv < 0.22) uniformity = 18;
    else if (cv < 0.32) uniformity = 13;
    else if (cv < 0.42) uniformity = 6;
    else uniformity = 0;
  }

  const contractionRate = contractions * per100;
  const contractionSignal = contractions === 0 && words.length > 80 ? 9 : contractionRate < 0.25 && words.length > 120 ? 4 : 0;
  const emDashSignal = emDashes * per100 > 0.8 ? 7 : emDashes > 0 ? 2 : 0;
  const transitionSignal = Math.min(9, transitionRatio * 26);
  const diversitySignal = words.length > 150 && ttr < 0.42 ? 7 : words.length > 150 && ttr < 0.48 ? 3 : 0;
  const paragraphSignal = paragraphs >= 4 && paragraphs <= 8 ? 4 : 0;
  const numberedList = /(^|\n)\s*\d+\.\s+\S+/g.test(text) && paragraphs > 2 ? 4 : 0;
  const noTyposSignal = words.length > 120 && /\b(teh|adn|recieve|occured|seperate)\b/i.test(text) ? -6 : 0;

  const base = 11;
  const rawScore =
    base +
    phraseScore +
    uniformity +
    contractionSignal +
    emDashSignal +
    transitionSignal +
    diversitySignal +
    paragraphSignal +
    numberedList +
    noTyposSignal;

  const aiLikelihood = clamp(Math.round(rawScore), 2, 97);
  const confidence = clamp(Math.round(28 + Math.min(52, words.length / 6) + (phraseHits.length ? 12 : 0)), 20, 96);

  const signals: Signal[] = [
    {
      id: "phrases",
      label: "LLM-style phrasing",
      strength: clamp(phraseScore, 0, 100) / 100,
      detail: phraseHits.length
        ? `${phraseHits.reduce((a, h) => a + h.count, 0)} characteristic phrases found: ${phraseHits
            .slice(0, 4)
            .map((h) => h.label)
            .join(", ")}.`
        : "No formulaic LLM phrasing patterns were found.",
      tone: phraseHits.length ? "risk" : "good",
    },
    {
      id: "uniformity",
      label: "Sentence-length uniformity",
      strength: uniformity / 18,
      detail: `Average ${avg.toFixed(1)} words per sentence, σ ${stdev.toFixed(1)} (coefficient of variation ${cv.toFixed(
        2
      )}). ${uniformity > 10 ? "Unusually even rhythm for human drafting." : "Natural variation between long and short sentences."}`,
      tone: uniformity > 10 ? "risk" : "good",
    },
    {
      id: "contractions",
      label: "Informal-register cues",
      strength: contractionSignal / 9,
      detail:
        contractions === 0
          ? "No contractions detected across the sample — common in generated text and formal policy writing."
          : `${contractions} contraction(s) used (${contractionRate.toFixed(2)} per 100 words).`,
      tone: contractionSignal > 4 ? "risk" : "neutral",
    },
    {
      id: "connectors",
      label: "Connector & transition density",
      strength: transitionSignal / 9,
      detail: `${transitionStarts} sentence(s) open with a formal transition (${(transitionRatio * 100).toFixed(
        0
      )}% of sentences).`,
      tone: transitionSignal > 6 ? "risk" : "neutral",
    },
    {
      id: "diversity",
      label: "Lexical diversity",
      strength: diversitySignal / 7,
      detail: `Type-token ratio ${ttr.toFixed(2)} over ${words.length} words${
        diversitySignal ? " — low variety suggests templated generation." : "."
      }`,
      tone: diversitySignal ? "risk" : "good",
    },
    {
      id: "dashes",
      label: "Typographic habits",
      strength: emDashSignal / 7,
      detail: `${emDashes} em/en dash(es); ${numberedList ? "structured numbered list detected" : "no enumerated scaffold"}.`,
      tone: emDashSignal > 4 ? "risk" : "neutral",
    },
  ];

  const perSentence = sentences.map((s) => scoreSentence(s, sentences.length >= 3 ? avg : 0));
  const excerpt = text.length > 360 ? `${text.slice(0, 360)}…` : text;

  let verdict = "Consistent with human authorship";
  if (aiLikelihood >= 70) verdict = "Strong indicators of AI generation";
  else if (aiLikelihood >= 45) verdict = "Mixed signals — possible AI assistance";

  return {
    aiLikelihood,
    verdict,
    confidence,
    signals,
    sentences: perSentence,
    excerpt,
    stats: {
      words: words.length,
      sentences: sentences.length,
      paragraphs,
      avgSentenceWords: Number(avg.toFixed(1)),
      sentenceStdev: Number(stdev.toFixed(1)),
      typeTokenRatio: Number(ttr.toFixed(2)),
      contractionsPer100: Number(contractionRate.toFixed(2)),
      emDashPer100: Number((emDashes * per100).toFixed(2)),
      avgSentenceLengthLabel: `${avg.toFixed(0)} words`,
    },
  };
  // opts.context reserved for caller-specific framing
  void opts;
}

export function scoreSentence(sentence: string, corpusAvg = 0): SentenceFinding {
  const reasons: string[] = [];
  let score = 26;
  for (const p of AI_PHRASES) {
    if (p.re.test(sentence)) {
      score += p.weight;
      reasons.push(`Contains ${p.label}`);
    }
  }
  const words = sentence.split(/\s+/).filter(Boolean).length;
  if (corpusAvg > 0) {
    if (Math.abs(words - corpusAvg) <= 2 && words >= 14) {
      score += 8;
      reasons.push("Typical generated sentence length within the document's uniform rhythm");
    }
    if (words >= 34) {
      score -= 6;
      reasons.push("Long, clause-heavy structure (more common in human drafting)");
    }
  }
  if (TRANSITION_START.test(sentence)) {
    score += 6;
    reasons.push("Opens with a formulaic transition");
  }
  if (CONTRACTION.test(sentence)) {
    score -= 8;
    reasons.push("Uses a contraction (informal human cue)");
  }
  if (/[0-9]{1,3}(\.\d+)?%|\b(19|20)\d{2}\b|[$€£]\d/.test(sentence)) {
    score -= 6;
    reasons.push("Carries specific figures or dates");
  }
  if (/["“]/.test(sentence)) {
    score -= 4;
    reasons.push("Contains a direct quotation");
  }
  if (!reasons.length) reasons.push("No strong stylistic markers");
  return { text: sentence, score: clamp(Math.round(score), 3, 98), reasons };
}

/** Analyse only the portion a user quoted, e.g. "this paragraph, is it AI?" */
export function analyzeQuotedPortion(question: string, quote: string) {
  const result = analyzeText(quote);
  const flagged = result.sentences.filter((s) => s.score >= 60);
  const reasons: string[] = [];
  if (flagged.length) {
    reasons.push(
      `${flagged.length} of ${result.sentences.length} sentences in the quoted portion carry AI markers (up to ${Math.max(
        ...flagged.map((s) => s.score)
      )}%).`
    );
    for (const s of flagged.slice(0, 3)) reasons.push(`“${s.text.slice(0, 110)}…” → ${s.reasons[0]}.`);
  } else {
    reasons.push("The quoted sentences do not match the platform's AI-phrasing or rhythm models.");
  }
  reasons.push(
    result.aiLikelihood >= 70
      ? "Overall stylistic profile is generated-text-like."
      : result.aiLikelihood >= 45
      ? "Mixed indicators: some generated-style scaffolding present."
      : "Profile is closer to human authorship than to generated text."
  );
  const verdict =
    result.aiLikelihood >= 70
      ? "The quoted portion is likely AI-generated"
      : result.aiLikelihood >= 45
      ? "The quoted portion shows partial AI indicators"
      : "The quoted portion does not look AI-generated";
  return {
    question,
    quote,
    score: result.aiLikelihood,
    verdict,
    reasons,
    sentenceScores: result.sentences,
  };
}
