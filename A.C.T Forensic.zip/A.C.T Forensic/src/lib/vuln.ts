import type { PostureAnswers, Severity, VulnFinding } from "./types";
import { uid } from "./hash";

interface Rule {
  id: string;
  re: RegExp;
  title: string;
  severity: Severity;
  category: string;
  cwe: string;
  detail: string;
  fix: string;
  weight: number;
}

const RULES: Rule[] = [
  {
    id: "eval",
    re: /\beval\s*\(|new\s+Function\s*\(/,
    title: "Dynamic code execution via eval / Function",
    severity: "critical",
    category: "Injection",
    cwe: "CWE-95",
    detail: "User-controlled data reaching eval() lets an attacker execute arbitrary code inside the application process — the shortest route from an input field to a full compromise.",
    fix: "Remove eval/new Function. Use a JSON parser, a lookup table of allowed operations, or a sandboxed interpreter.",
    weight: 10,
  },
  {
    id: "innerhtml",
    re: /\.innerHTML\s*=|dangerouslySetInnerHTML|document\.write\s*\(/,
    title: "Unsanitised HTML sink (XSS)",
    severity: "high",
    category: "Injection",
    cwe: "CWE-79",
    detail: "Strings written into HTML sinks execute in the victim's session, enabling evidence-page defacement, token theft and forensic-report tampering.",
    fix: "Render as text, or sanitise with DOMPurify and a strict CSP that forbids inline script.",
    weight: 8.5,
  },
  {
    id: "sqli",
    re: /(SELECT|INSERT|UPDATE|DELETE)[^;\n]{0,80}(\+\s*\w+|\$\{)/i,
    title: "SQL query built by string concatenation",
    severity: "critical",
    category: "Injection",
    cwe: "CWE-89",
    detail: "Concatenated SQL allows an attacker to rewrite case queries, exfiltrate evidence records or delete the chain-of-custody log.",
    fix: "Use parameterised queries / prepared statements. Never interpolate request data into SQL.",
    weight: 9.5,
  },
  {
    id: "nosql",
    re: /\$where\s*:|new\s+RegExp\s*\(\s*req\.(query|body)/,
    title: "NoSQL injection surface",
    severity: "high",
    category: "Injection",
    cwe: "CWE-943",
    detail: "Operator injection in Mongo-style queries can bypass filters and dump case data.",
    fix: "Validate with a schema (zod/joi), cast types, and reject objects in scalar fields.",
    weight: 7,
  },
  {
    id: "jwt-none",
    re: /algorithm[s]?\s*[:=]\s*\[?['"]none['"]|verify\s*:\s*false|jwt\.decode\s*\(/,
    title: "JWT signature not verified",
    severity: "critical",
    category: "Authentication",
    cwe: "CWE-347",
    detail: "Accepting unsigned tokens or decoding without verification lets anyone mint an investigator session.",
    fix: "Pin algorithms to RS256/ES256, verify issuer and audience, and never accept 'none'.",
    weight: 9,
  },
  {
    id: "secret",
    re: /(api[_-]?key|secret|password|token)\s*[:=]\s*['"][A-Za-z0-9_\-]{16,}['"]/i,
    title: "Hard-coded credential in source",
    severity: "critical",
    category: "Secrets",
    cwe: "CWE-798",
    detail: "A secret committed to source is readable by anyone with repository access and survives in history after deletion.",
    fix: "Move the value to a secret manager / environment variable and rotate it immediately.",
    weight: 9,
  },
  {
    id: "md5",
    re: /\b(md5|sha1)\s*\(|createHash\(\s*['"](md5|sha1)['"]/i,
    title: "Broken hash algorithm for integrity",
    severity: "high",
    category: "Cryptography",
    cwe: "CWE-328",
    detail: "MD5/SHA-1 collisions are practical. Evidence hashed this way can be swapped without detection.",
    fix: "Use SHA-256 (or SHA-3) for evidence integrity, with an HMAC or signature over the manifest.",
    weight: 7.5,
  },
  {
    id: "cors",
    re: /Access-Control-Allow-Origin['"]?\s*[:,]\s*['"]\*|cors\(\s*\)/,
    title: "Wildcard CORS on a sensitive API",
    severity: "high",
    category: "API",
    cwe: "CWE-942",
    detail: "Any origin can call the evidence API with the victim's cookies, enabling cross-site exfiltration.",
    fix: "Allow only the case-management origins, and require credentials plus CSRF protection.",
    weight: 7,
  },
  {
    id: "norate",
    re: /app\.post\(\s*['"]\/(login|auth|verify-otp)/,
    title: "Login route without visible rate limiting",
    severity: "medium",
    category: "Authentication",
    cwe: "CWE-307",
    detail: "Unthrottled credential endpoints allow password spraying against investigator accounts.",
    fix: "Add per-IP and per-account rate limits, exponential backoff, and lockout alerts.",
    weight: 5,
  },
  {
    id: "httponly",
    re: /cookie\([^)]*\)|setHeader\(\s*['"]Set-Cookie['"]/,
    title: "Session cookie flags need review",
    severity: "medium",
    category: "Session",
    cwe: "CWE-1004",
    detail: "Cookies set without HttpOnly/Secure/SameSite can be read by injected script or sent over plaintext.",
    fix: "Set HttpOnly; Secure; SameSite=Strict, and scope the cookie path to the API.",
    weight: 4.5,
  },
  {
    id: "http",
    re: /http:\/\/(?!localhost|127\.0\.0\.1)/,
    title: "Plaintext HTTP endpoint",
    severity: "medium",
    category: "Transport",
    cwe: "CWE-319",
    detail: "Evidence transfers over HTTP can be intercepted and altered in transit, breaking integrity guarantees.",
    fix: "Force HTTPS everywhere, enable HSTS with preload, and reject downgrade redirects.",
    weight: 5,
  },
  {
    id: "upload",
    re: /multer\(|upload\.single|move_uploaded_file|File\(.*\)/,
    title: "File upload handling requires validation",
    severity: "high",
    category: "Upload",
    cwe: "CWE-434",
    detail: "Uploads are the primary evidence intake path. Without type, size and content validation an attacker can store executable content or bomb the vault.",
    fix: "Validate magic bytes, cap size, randomise stored names, store outside the web root, and scan with AV.",
    weight: 7.5,
  },
  {
    id: "path",
    re: /readFile(?:Sync)?\s*\(\s*(req\.|path\.join\([^)]*req\.)/,
    title: "Path traversal in file read",
    severity: "critical",
    category: "Upload",
    cwe: "CWE-22",
    detail: "Request data joined into a filesystem path can escape the evidence directory and read arbitrary server files.",
    fix: "Resolve against a fixed base, reject '..', and use opaque storage IDs rather than user filenames.",
    weight: 9,
  },
  {
    id: "debug",
    re: /\bDEBUG\s*=\s*True|app\.run\([^)]*debug\s*=\s*True|console\.log\(.*(password|token)/i,
    title: "Debug mode or secret logging",
    severity: "medium",
    category: "Misconfiguration",
    cwe: "CWE-489",
    detail: "Debug tracebacks and token logs leak internals and credentials to anyone who triggers an error.",
    fix: "Disable debug in production and redact secrets in structured logging.",
    weight: 4.5,
  },
  {
    id: "authz",
    re: /app\.get\(\s*['"]\/api\/(cases|evidence)[^'"]*['"]\s*,\s*(?!.*auth)/,
    title: "Case/evidence route appears unauthenticated",
    severity: "high",
    category: "Access control",
    cwe: "CWE-306",
    detail: "Evidence endpoints without an auth middleware expose case material to unauthenticated callers.",
    fix: "Require authentication on every evidence route and enforce per-case authorisation (IDOR checks).",
    weight: 8,
  },
  {
    id: "ssrf",
    re: /axios\.(get|post)\(\s*(req\.|url)|fetch\(\s*(req\.|url)/,
    title: "Server-side request forgery surface",
    severity: "high",
    category: "API",
    cwe: "CWE-918",
    detail: "Fetching user-supplied URLs from the server can reach internal metadata services and cloud credentials.",
    fix: "Allow-list outbound hosts, block private ranges, and disable redirects.",
    weight: 7,
  },
  {
    id: "prototype",
    re: /Object\.assign\(\s*\w+\s*,\s*req\.body|merge\(\s*\w+\s*,\s*req\.body/,
    title: "Mass assignment / prototype pollution",
    severity: "medium",
    category: "API",
    cwe: "CWE-915",
    detail: "Copying a request body onto a model lets an attacker set role, hash or custody fields directly.",
    fix: "Whitelist mutable fields with an explicit schema and strip prototype keys.",
    weight: 5,
  },
  {
    id: "deserial",
    re: /pickle\.loads|yaml\.load\(|unserialize\s*\(/,
    title: "Unsafe deserialisation",
    severity: "critical",
    category: "Injection",
    cwe: "CWE-502",
    detail: "Deserialising untrusted bytes can execute code during object construction.",
    fix: "Use JSON with schema validation, or safe_load for YAML.",
    weight: 9,
  },
];

const SEVERITY_SCORE: Record<Severity, number> = {
  critical: 10,
  high: 7.5,
  medium: 5,
  low: 2.5,
  info: 1,
};

export function scanSource(source: string, target: string): {
  findings: VulnFinding[];
  score: number;
  grade: string;
  stats: Record<string, number | string>;
} {
  const lines = source.split(/\r?\n/);
  const findings: VulnFinding[] = [];
  for (const rule of RULES) {
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (!rule.re.test(line)) continue;
      if (findings.some((f) => f.location === `line ${i + 1}` && f.category === rule.category)) continue;
      findings.push({
        id: uid("vuln"),
        title: rule.title,
        severity: rule.severity,
        category: rule.category,
        cwe: rule.cwe,
        location: `line ${i + 1}`,
        snippet: line.trim().slice(0, 200),
        detail: rule.detail,
        fix: rule.fix,
        confidence: 82,
        weight: rule.weight,
      });
      break;
    }
  }

  // Dependency hygiene from inline imports
  const riskyDeps = [
    { name: "lodash", re: /from\s+['"]lodash['"]|require\(['"]lodash['"]\)/ },
    { name: "moment", re: /from\s+['"]moment['"]/ },
    { name: "request", re: /from\s+['"]request['"]/ },
    { name: "jsonwebtoken", re: /from\s+['"]jsonwebtoken['"]/ },
    { name: "pdfjs-dist", re: /from\s+['"]pdfjs-dist['"]/ },
    { name: "xlsx", re: /from\s+['"]xlsx['"]/ },
  ];
  const imported = riskyDeps.filter((d) => d.re.test(source)).map((d) => d.name);
  if (imported.length) {
    findings.push({
      id: uid("vuln"),
      title: `Sensitive third-party libraries imported: ${imported.join(", ")}`,
      severity: "medium",
      category: "Supply chain",
      cwe: "CWE-1104",
      location: "imports",
      snippet: imported.join(", "),
      detail:
        "Third-party libraries are the most common source of exploitable vulnerabilities. Every imported package widens the attack surface of the evidence pipeline.",
      fix: "Pin versions, run npm audit / OSV scanning in CI, and replace abandoned packages.",
      confidence: 68,
      weight: 5,
    });
  }

  findings.sort((a, b) => SEVERITY_SCORE[b.severity] - SEVERITY_SCORE[a.severity]);
  const deduped = findings.slice(0, 24);
  const score = riskScore(deduped);
  return {
    findings: deduped,
    score,
    grade: gradeFor(score),
    stats: {
      "Lines scanned": lines.length,
      "Rules evaluated": RULES.length,
      "Findings": deduped.length,
      "Critical": deduped.filter((f) => f.severity === "critical").length,
      "High": deduped.filter((f) => f.severity === "high").length,
      Target: target,
    },
  };
}

interface DepRule {
  name: string;
  badBelow: string;
  note: string;
  severity: Severity;
}

const DEP_RULES: DepRule[] = [
  { name: "lodash", badBelow: "4.17.21", note: "Prototype pollution / command injection fixes", severity: "high" },
  { name: "express", badBelow: "4.19.2", note: "Open redirect and XSS advisories", severity: "medium" },
  { name: "jsonwebtoken", badBelow: "9.0.0", note: "Verification bypass advisories in v8", severity: "critical" },
  { name: "axios", badBelow: "1.6.0", note: "SSRF and credential-leak fixes", severity: "high" },
  { name: "multer", badBelow: "1.4.5-lts.1", note: "DoS via malformed multipart bodies", severity: "high" },
  { name: "moment", badBelow: "2.29.4", note: "Path traversal in locale loading", severity: "medium" },
  { name: "xlsx", badBelow: "0.19.3", note: "Prototype pollution and ReDoS", severity: "high" },
  { name: "pdfjs-dist", badBelow: "4.2.67", note: "Arbitrary JS execution when opening crafted PDFs", severity: "critical" },
  { name: "next", badBelow: "14.2.15", note: "Cache poisoning / auth bypass advisories", severity: "high" },
  { name: "react-dom", badBelow: "18.3.1", note: "XSS in server-rendered content", severity: "medium" },
  { name: "sharp", badBelow: "0.33.0", note: "libvips vulnerabilities", severity: "high" },
  { name: "jspdf", badBelow: "2.5.1", note: "PDF generation injection", severity: "medium" },
];

function cmpVersion(a: string, b: string): number {
  const pa = a.replace(/^[^\d]*/, "").split(/[.\-+]/).map((n) => parseInt(n, 10) || 0);
  const pb = b.replace(/^[^\d]*/, "").split(/[.\-+]/).map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const x = pa[i] ?? 0;
    const y = pb[i] ?? 0;
    if (x !== y) return x - y;
  }
  return 0;
}

export function scanDependencies(raw: string): {
  findings: VulnFinding[];
  score: number;
  grade: string;
  stats: Record<string, number | string>;
} {
  let pkg: { dependencies?: Record<string, string>; devDependencies?: Record<string, string>; name?: string };
  try {
    pkg = JSON.parse(raw);
  } catch {
    return { findings: [], score: 0, grade: "—", stats: { Error: "Manifest is not valid JSON" } };
  }
  const deps = { ...(pkg.dependencies ?? {}), ...(pkg.devDependencies ?? {}) };
  const findings: VulnFinding[] = [];
  for (const [name, version] of Object.entries(deps)) {
    const rule = DEP_RULES.find((r) => r.name === name);
    if (!rule) continue;
    const clean = version.replace(/^[~^=<> ]+/, "");
    if (cmpVersion(clean, rule.badBelow) < 0) {
      findings.push({
        id: uid("vuln"),
        title: `${name} ${version} below patched release ${rule.badBelow}`,
        severity: rule.severity,
        category: "Supply chain",
        cwe: "CWE-1104",
        location: `dependency ${name}`,
        snippet: `"${name}": "${version}"`,
        detail: `This release predates fixes for known issues: ${rule.note}. Third-party libraries are the most common entry point for attackers targeting evidence systems.`,
        fix: `Upgrade ${name} to ${rule.badBelow} or later, lock the version, and add OSV/npm-audit to CI.`,
        confidence: 74,
        weight: SEVERITY_SCORE[rule.severity],
      });
    }
  }
  const noLock = !/package-lock|pnpm-lock|yarn\.lock/.test(raw);
  if (Object.keys(deps).length > 0) {
    findings.push({
      id: uid("vuln"),
      title: "Dependency integrity controls",
      severity: noLock ? "medium" : "low",
      category: "Supply chain",
      cwe: "CWE-1104",
      location: "manifest",
      snippet: `${Object.keys(deps).length} packages declared`,
      detail: noLock
        ? "No lockfile reference was supplied with the manifest, so builds may resolve unreviewed transitive versions."
        : "A lockfile reference is present; pinning is in place.",
      fix: "Commit the lockfile, enable Dependabot/Renovate, and verify package provenance (SLSA / npm attestations).",
      confidence: 60,
      weight: 4,
    });
  }
  return {
    findings,
    score: riskScore(findings),
    grade: gradeFor(riskScore(findings)),
    stats: {
      "Packages declared": Object.keys(deps).length,
      "Flagged packages": findings.length,
      "Critical": findings.filter((f) => f.severity === "critical").length,
      "High": findings.filter((f) => f.severity === "high").length,
      Package: pkg.name ?? "unknown",
    },
  };
}

const POSTURE_ITEMS: { key: keyof PostureAnswers; label: string; severity: Severity; detail: string; fix: string; cwe: string }[] = [
  {
    key: "https",
    label: "No enforced HTTPS / HSTS",
    severity: "high",
    detail: "Plaintext transport lets an attacker alter evidence in flight, defeating later SHA-256 verification.",
    fix: "Redirect all traffic to HTTPS and send Strict-Transport-Security.",
    cwe: "CWE-319",
  },
  {
    key: "mfa",
    label: "No multi-factor authentication",
    severity: "critical",
    detail: "A single phished password yields full case access — the highest-impact weakness in forensic portals.",
    fix: "Enforce TOTP/WebAuthn for every investigator and privileged operator.",
    cwe: "CWE-308",
  },
  {
    key: "rateLimit",
    label: "Login endpoint not rate-limited",
    severity: "high",
    detail: "Credential stuffing against investigator accounts becomes trivial.",
    fix: "Per-IP and per-account throttling with lockout and alerting.",
    cwe: "CWE-307",
  },
  {
    key: "strongPasswords",
    label: "Weak password policy",
    severity: "medium",
    detail: "Short minimums and no breach-list checks allow guessable credentials.",
    fix: "12+ characters, breached-password screening, and no forced rotation.",
    cwe: "CWE-521",
  },
  {
    key: "waf",
    label: "No WAF / API gateway in front of the app",
    severity: "medium",
    detail: "Injection and scanning traffic reaches application code directly.",
    fix: "Deploy a WAF with managed OWASP rules and bot protection.",
    cwe: "CWE-693",
  },
  {
    key: "sessionExpiry",
    label: "Sessions never expire",
    severity: "medium",
    detail: "Stolen sessions remain valid indefinitely, including on shared court workstations.",
    fix: "Idle timeout of 15 minutes, absolute timeout of 8 hours, and rotation on privilege change.",
    cwe: "CWE-613",
  },
  {
    key: "leastPrivilege",
    label: "No least-privilege separation",
    severity: "high",
    detail: "Any authenticated user can reach every case, enabling insider tampering.",
    fix: "Role-based access per case, with examiner / reviewer / admin separation and audit trails.",
    cwe: "CWE-269",
  },
  {
    key: "logging",
    label: "Insufficient tamper-evident logging",
    severity: "high",
    detail: "Without append-only audit logs, evidence access and hash checks cannot be proven in court.",
    fix: "Write access logs to append-only storage, hash-chain the entries, and monitor anomalies.",
    cwe: "CWE-778",
  },
  {
    key: "encryptionAtRest",
    label: "Evidence not encrypted at rest",
    severity: "high",
    detail: "Stolen disks or bucket misconfiguration expose sensitive case material.",
    fix: "AES-256 at rest with envelope keys in a KMS; rotate and audit key use.",
    cwe: "CWE-311",
  },
  {
    key: "dependencyScanning",
    label: "No continuous dependency scanning",
    severity: "medium",
    detail: "Known-vulnerable libraries stay in production long after disclosure.",
    fix: "Enable Dependabot/OSV-Scanner in CI with build-blocking thresholds.",
    cwe: "CWE-1104",
  },
];

export function auditPosture(answers: PostureAnswers, target: string): {
  findings: VulnFinding[];
  score: number;
  grade: string;
  stats: Record<string, number | string>;
} {
  const findings: VulnFinding[] = [];
  for (const item of POSTURE_ITEMS) {
    if (answers[item.key]) continue;
    findings.push({
      id: uid("vuln"),
      title: item.label,
      severity: item.severity,
      category: "Login & network posture",
      cwe: item.cwe,
      location: "posture audit",
      snippet: `${item.key}: false`,
      detail: item.detail,
      fix: item.fix,
      confidence: 90,
      weight: SEVERITY_SCORE[item.severity],
    });
  }
  const enabled = POSTURE_ITEMS.filter((i) => answers[i.key]).length;
  const score = riskScore(findings);
  return {
    findings,
    score,
    grade: gradeFor(score),
    stats: {
      "Controls passed": `${enabled}/${POSTURE_ITEMS.length}`,
      Findings: findings.length,
      Target: target,
    },
  };
}

export function riskScore(findings: VulnFinding[]): number {
  const weighted = findings.reduce((a, f) => a + f.weight, 0);
  const critical = findings.filter((f) => f.severity === "critical").length;
  const high = findings.filter((f) => f.severity === "high").length;
  const raw = weighted * 1.9 + critical * 6 + high * 2.5;
  return Math.max(0, Math.min(100, Math.round(raw)));
}

export function gradeFor(score: number): string {
  if (score >= 80) return "F";
  if (score >= 65) return "D";
  if (score >= 45) return "C";
  if (score >= 25) return "B";
  return "A";
}

export function sampleVulnerableSource(): string {
  return `// legacy evidence portal (sample)
const express = require("express");
const jwt = require("jsonwebtoken");
const multer = require("multer");
const md5 = require("md5");
const app = express();
const DB_PASSWORD = "Sup3rS3cretEvidenceKey!";

app.use(cors());
app.post("/api/login", (req, res) => {
  const user = db.query("SELECT * FROM users WHERE email = '" + req.body.email + "'");
  const token = jwt.sign({ id: user.id, role: "admin" }, "dev-secret", { algorithm: "none" });
  res.cookie("session", token);
  res.json({ token });
});

app.get("/api/cases", (req, res) => {
  res.json(db.query("SELECT * FROM cases"));
});

app.post("/api/evidence", multer({ dest: "/tmp" }).single("file"), (req, res) => {
  const digest = md5(fs.readFileSync(req.file.path));
  document.getElementById("hash").innerHTML = digest;
  res.json({ ok: true, digest });
});

app.get("/api/evidence/file", (req, res) => {
  res.sendFile(path.join("/var/evidence", req.query.name));
});

app.listen(3000, () => console.log("password=" + DB_PASSWORD));
`;
}
