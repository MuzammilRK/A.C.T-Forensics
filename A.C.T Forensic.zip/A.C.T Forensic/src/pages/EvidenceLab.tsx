import { useEffect, useMemo, useRef, useState } from "react";
import type { PointerEvent as ReactPointerEvent } from "react";
import type { EvidenceItem, EvidenceKind, ForensicCheck } from "../lib/types";
import { activeCase, addEvidence, mediaCache, removeEvidence, updateEvidence, useAppStore } from "../lib/store";
import { analyzeFile } from "../lib/scanFile";
import { analyzeImageRegion } from "../lib/image";
import { analyzeQuotedPortion } from "../lib/text";
import { downloadText, formatBytes, formatDate, uid } from "../lib/hash";
import { Empty, Icon, ScoreRing, kindIcon, scoreColor } from "../components/ui";

/* ------------------------------ sections ------------------------------ */

type SectionKey = "all" | EvidenceKind;

const SECTIONS: {
  key: SectionKey;
  label: string;
  icon: string;
  blurb: string;
  accept: string;
  formats: string;
  areas: { name: string; text: string }[];
}[] = [
  {
    key: "all",
    label: "All exhibits",
    icon: "evidence",
    blurb: "Everything in this case, newest first.",
    accept: "image/*,video/*,audio/*,.pdf,.docx,.txt,.md,.csv,.js,.ts,.tsx,.py,.json,.html",
    formats: "Any supported file",
    areas: [],
  },
  {
    key: "image",
    label: "Images",
    icon: "image",
    blurb: "Photos, screenshots and exports — read for watermarks, camera records and edited regions.",
    accept: "image/*",
    formats: "JPG · PNG · WebP · GIF · BMP",
    areas: [
      { name: "Watermarks", text: "C2PA Content Credentials, SynthID and generator names read straight from the file's bytes." },
      { name: "Source record", text: "EXIF camera make, model, lens and capture time — the record a real camera writes." },
      { name: "Visual", text: "Error-level analysis highlights areas that recompress differently from the rest." },
      { name: "Noise", text: "Real sensors leave uneven grain; renderers leave smooth, even noise." },
      { name: "Copy-move", text: "Identical texture blocks in different places point to cloning." },
    ],
  },
  {
    key: "video",
    label: "Video",
    icon: "video",
    blurb: "Clips inspected frame by frame for lighting, detail and generator metadata.",
    accept: "video/*",
    formats: "MP4 · MOV · WebM",
    areas: [
      { name: "Source record", text: "Camera and encoder identity inside the container." },
      { name: "Visual frames", text: "Five frames across the timeline are compared side by side." },
      { name: "Temporal", text: "Real light drifts. Generated video often holds a locked exposure." },
      { name: "Detail", text: "Texture that stays uniformly soft is a common render artefact." },
      { name: "Audio", text: "Extract the track and run it through the Audio section." },
    ],
  },
  {
    key: "audio",
    label: "Audio",
    icon: "audio",
    blurb: "Interviews and calls, measured for bandwidth, silence and synthesis markers.",
    accept: "audio/*",
    formats: "WAV · MP3 · OGG · M4A",
    areas: [
      { name: "Waveform", text: "The full peak envelope, so splices and level jumps are visible." },
      { name: "Bandwidth", text: "Voice generators usually stop at 16–18 kHz; microphones keep going." },
      { name: "Silence", text: "Exact digital silence does not happen in a real room." },
      { name: "Source record", text: "Recorder and encoder identity in the container." },
      { name: "Voice identity", text: "Speaker comparison needs a known reference sample." },
    ],
  },
  {
    key: "document",
    label: "Documents",
    icon: "doc",
    blurb: "Statements, contracts and PDFs — style, hidden characters and producer metadata.",
    accept: ".pdf,.docx,.txt,.md,.csv,.rtf,.log",
    formats: "PDF · DOCX · TXT · MD · CSV",
    areas: [
      { name: "Producer", text: "Which program exported the document, and whether it names a generative tool." },
      { name: "Writing style", text: "Phrasing and rhythm compared with machine-writing patterns." },
      { name: "Hidden text", text: "Zero-width and Unicode tag characters that a reader cannot see." },
      { name: "History", text: "Author name and revision counter left by an office suite." },
      { name: "Active content", text: "Scripts and macros that run when the file is opened." },
    ],
  },
  {
    key: "code",
    label: "Source code",
    icon: "code",
    blurb: "Application files checked for the weaknesses an attacker would use.",
    accept: ".js,.ts,.tsx,.jsx,.py,.php,.rb,.java,.json,.yml,.yaml,.sql,.html,.env",
    formats: "JS · TS · PY · PHP · JSON · YAML",
    areas: [
      { name: "Rules", text: "Twenty injection, auth, secret and transport patterns, mapped to CWE." },
      { name: "Fixes", text: "Every finding carries the exact change that closes it." },
      { name: "Hidden text", text: "Invisible characters can ride along in source files too." },
      { name: "Attack paths", text: "Application findings feed the attack-path graph automatically." },
    ],
  },
];

export function EvidenceLab({ focusId, onConsumed }: { focusId: string | null; onConsumed: () => void }) {
  const state = useAppStore();
  const caseFile = activeCase(state);
  const [tab, setTab] = useState<SectionKey>("all");
  const [uploading, setUploading] = useState<{ name: string; pct: number; msg: string }[]>([]);
  const [drag, setDrag] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  const section = SECTIONS.find((s) => s.key === tab) ?? SECTIONS[0];

  useEffect(() => {
    if (focusId) {
      const item = caseFile.evidence.find((e) => e.id === focusId);
      if (item) setTab(item.kind);
      setSelectedId(focusId);
      onConsumed();
    }
  }, [focusId, onConsumed, caseFile.evidence]);

  const filtered = tab === "all" ? caseFile.evidence : caseFile.evidence.filter((e) => e.kind === tab);
  const selected = caseFile.evidence.find((e) => e.id === selectedId) ?? null;

  const ingest = async (files: FileList | File[]) => {
    for (const file of Array.from(files)) {
      const entry = { name: file.name, pct: 0, msg: "Reading file" };
      setUploading((prev) => [...prev, entry]);
      try {
        const { hash, kind, analysis } = await analyzeFile(file, (msg, pct) =>
          setUploading((prev) => prev.map((u) => (u.name === file.name ? { ...u, msg, pct } : u)))
        );
        const item: EvidenceItem = {
          id: uid("ev"),
          name: file.name,
          mime: file.type || "application/octet-stream",
          size: file.size,
          kind,
          hash,
          hashAt: new Date().toISOString(),
          addedAt: new Date().toISOString(),
          analysis,
          source: "upload",
        };
        mediaCache.set(item.id, file);
        addEvidence(caseFile.id, item);
        setUploading((prev) => prev.map((u) => (u.name === file.name ? { ...u, pct: 100, msg: "Analysed" } : u)));
        setTab(kind);
        setTimeout(() => setUploading((prev) => prev.filter((u) => u.name !== file.name)), 1400);
      } catch (err) {
        setUploading((prev) =>
          prev.map((u) => (u.name === file.name ? { ...u, msg: `Failed: ${String(err)}`, pct: 100 } : u))
        );
      }
    }
  };

  if (selected) {
    return (
      <ExhibitWorkspace
        item={selected}
        caseId={caseFile.id}
        onBack={() => setSelectedId(null)}
        onNext={(id) => setSelectedId(id)}
        siblings={filtered.map((e) => e.id)}
      />
    );
  }

  return (
    <div className="stack" style={{ gap: 16 }}>
      <div className="page-head">
        <div>
          <div className="eyebrow">Evidence lab</div>
          <h1 className="page-title">Look inside the file</h1>
          <p className="page-sub">
            Upload anything. We read the file's own source metadata for AI watermarks and camera records first, then
            check the pixels. A real photo should score close to zero — if it does not, the signals will tell you why.
          </p>
        </div>
        <button className="btn btn-primary" onClick={() => fileInput.current?.click()} type="button">
          <Icon name="upload" /> Add evidence
        </button>
      </div>

      <input
        ref={fileInput}
        type="file"
        multiple
        accept={section.accept}
        hidden
        onChange={(e) => {
          if (e.target.files?.length) void ingest(e.target.files);
          e.target.value = "";
        }}
      />

      <div className="typed-tabs">
        {SECTIONS.map((s) => {
          const count = s.key === "all" ? caseFile.evidence.length : caseFile.evidence.filter((e) => e.kind === s.key).length;
          return (
            <button
              key={s.key}
              type="button"
              className={`typed-tab ${tab === s.key ? "active" : ""}`}
              onClick={() => setTab(s.key)}
            >
              <Icon name={s.icon} size={15} />
              <span>{s.label}</span>
              <b>{count}</b>
            </button>
          );
        })}
      </div>

      <section className="section-intro">
        <div>
          <h2>{section.label}</h2>
          <p>{section.blurb}</p>
        </div>
        <div className="section-areas">
          {section.areas.length ? (
            section.areas.map((a) => (
              <div key={a.name} className="section-area">
                <b>{a.name}</b>
                <span>{a.text}</span>
              </div>
            ))
          ) : (
            <div className="section-area">
              <b>{caseFile.evidence.length} exhibits</b>
              <span>Pick a section above, or open any row to see the full analysis.</span>
            </div>
          )}
        </div>
      </section>

      <div
        className={`drop-strip ${drag ? "drag" : ""}`}
        onDragOver={(e) => {
          e.preventDefault();
          setDrag(true);
        }}
        onDragLeave={() => setDrag(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDrag(false);
          if (e.dataTransfer.files.length) void ingest(e.dataTransfer.files);
        }}
        onClick={() => fileInput.current?.click()}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === "Enter") fileInput.current?.click();
        }}
      >
        <Icon name="upload" size={16} />
        <span>
          Drop {section.key === "all" ? "files" : section.label.toLowerCase()} here, or click to browse
        </span>
        <em>{section.formats} · analysed locally, nothing is uploaded anywhere</em>
      </div>

      {uploading.length > 0 && (
        <div className="card card-pad stack" style={{ gap: 12 }}>
          {uploading.map((u) => (
            <div key={u.name}>
              <div className="row" style={{ justifyContent: "space-between", fontSize: 11.5, marginBottom: 6 }}>
                <span className="mono">{u.name}</span>
                <span className="muted">{u.msg}</span>
              </div>
              <div className="progress">
                <div style={{ width: `${u.pct}%` }} />
              </div>
            </div>
          ))}
        </div>
      )}

      {filtered.length === 0 ? (
        <Empty title={`No ${section.key === "all" ? "exhibits" : section.label.toLowerCase()} yet`} icon={section.icon}>
          Add a file above, or load the demo case from the Overview to see a fully analysed example of each type.
        </Empty>
      ) : (
        <div className="batch">
          <div className="batch-head">
            <span>Batch queue</span>
            <span>
              {filtered.length} item{filtered.length === 1 ? "" : "s"}
            </span>
          </div>
          {filtered.map((item) => (
            <ExhibitRow key={item.id} item={item} onOpen={() => setSelectedId(item.id)} />
          ))}
        </div>
      )}
    </div>
  );
}

/* -------------------------------- row -------------------------------- */

function toneOf(score: number): "danger" | "warn" | "ok" {
  return score >= 65 ? "danger" : score >= 40 ? "warn" : "ok";
}

function ExhibitRow({ item, onOpen }: { item: EvidenceItem; onOpen: () => void }) {
  const tone = toneOf(item.analysis.aiLikelihood);
  const hits = item.analysis.provenance?.hits.filter((h) => h.tone === "risk").length ?? 0;
  const label = item.kind === "code" ? "risk" : "AI";
  return (
    <button type="button" className={`batch-row tone-${tone}`} onClick={onOpen}>
      <span className="batch-icon">
        <Icon name={kindIcon(item.kind)} size={17} />
      </span>
      <span className="batch-name">
        <b>{item.name}</b>
        <em>
          {item.kind.toUpperCase()} · {formatBytes(item.size)} · SHA-256 {item.hash.slice(0, 10)}…
        </em>
      </span>
      <span className="batch-verdict">{item.analysis.verdict}</span>
      <span className={`batch-score tone-${tone}`}>
        {item.analysis.aiLikelihood}%<em>{label}</em>
      </span>
      <span className={`batch-flag tone-${tone}`}>
        {hits > 0 ? `${hits} marker${hits > 1 ? "s" : ""}` : item.integrity?.status === "modified" ? "modified" : "open"}
      </span>
    </button>
  );
}

/* ----------------------------- workspace ----------------------------- */

function ExhibitWorkspace({
  item,
  caseId,
  onBack,
  onNext,
  siblings,
}: {
  item: EvidenceItem;
  caseId: string;
  onBack: () => void;
  onNext: (id: string) => void;
  siblings: string[];
}) {
  const [url, setUrl] = useState<string | null>(null);
  const [verifying, setVerifying] = useState(false);
  const [detailTab, setDetailTab] = useState<"signals" | "metadata" | "custody">("signals");
  const [notesOpen, setNotesOpen] = useState(false);

  useEffect(() => {
    const blob = mediaCache.get(item.id);
    if (!blob) return setUrl(null);
    const objectUrl = URL.createObjectURL(blob);
    setUrl(objectUrl);
    return () => URL.revokeObjectURL(objectUrl);
  }, [item.id]);

  const checks = item.analysis.checks ?? [];
  const prov = item.analysis.provenance;
  const tone = toneOf(item.analysis.aiLikelihood);
  const index = siblings.indexOf(item.id);
  const nextId = siblings[(index + 1) % Math.max(1, siblings.length)];

  const exportPack = () => {
    downloadText(
      `${item.name.replace(/[^\w.-]+/g, "_")}.act-pack.json`,
      JSON.stringify(
        {
          exhibit: item.name,
          sha256: item.hash,
          kind: item.kind,
          verdict: item.analysis.verdict,
          aiLikelihood: item.analysis.aiLikelihood,
          plainLanguage: item.analysis.plain,
          provenance: item.analysis.provenance,
          checks: item.analysis.checks,
          metadata: item.analysis.metadata,
          signals: item.analysis.signals,
          exportedAt: new Date().toISOString(),
        },
        null,
        2
      )
    );
  };

  return (
    <div className="stack" style={{ gap: 14 }}>
      <div className="ws-bar">
        <button className="btn btn-sm btn-ghost" type="button" onClick={onBack}>
          ← All exhibits
        </button>
        <div className="ws-title">
          <b>{item.name}</b>
          <span>
            {item.kind} · {formatBytes(item.size)} · added {formatDate(item.addedAt)}
          </span>
        </div>
        <span className={`ws-pill tone-${tone}`}>{item.analysis.verdict}</span>
        <button
          className="btn btn-sm"
          type="button"
          disabled={!nextId || nextId === item.id}
          onClick={() => nextId && onNext(nextId)}
        >
          Next <Icon name="arrow" size={12} />
        </button>
      </div>

      {checks.length > 0 && (
        <div className="checks-strip">
          {checks.map((c) => (
            <CheckCard key={c.id} check={c} />
          ))}
        </div>
      )}

      <div className="ws-grid">
        <div className="ws-main">
          <Viewer item={item} url={url} caseId={caseId} />
          {item.analysis.sentences?.length || item.analysis.excerpt ? (
            <TextPanel item={item} caseId={caseId} />
          ) : null}
        </div>

        <aside className="ws-side">
          <div className={`verdict-card tone-${tone}`}>
            <div className="verdict-head">
              <span>{item.kind === "code" ? "Risk assessment" : "Authenticity assessment"}</span>
              <ScoreRing value={item.analysis.aiLikelihood} size={96} label={item.kind === "code" ? "risk" : "AI"} stroke={7} />
            </div>
            <h2>{item.analysis.verdict}</h2>
            <p>{item.analysis.plain ?? item.analysis.summary}</p>
            <div className="verdict-meta">
              <div>
                <span>Confidence</span>
                <b>{item.analysis.confidence}%</b>
              </div>
              <div>
                <span>{prov?.verdict === "authentic-capture" ? "Camera record" : "Provenance"}</span>
                <b>{prov ? prov.verdict.replace("-", " ") : "unknown"}</b>
              </div>
              <div>
                <span>Hash</span>
                <b className="mono">{item.hash.slice(0, 10)}…</b>
              </div>
            </div>
          </div>

          {prov && <ProvenanceCard provenance={prov} />}

          <div className="side-card">
            <div className="side-tabs">
              {(["signals", "metadata", "custody"] as const).map((t) => (
                <button key={t} type="button" className={detailTab === t ? "active" : ""} onClick={() => setDetailTab(t)}>
                  {t === "signals" ? "Signals" : t === "metadata" ? "Metadata" : "Custody"}
                </button>
              ))}
            </div>
            {detailTab === "signals" && (
              <div className="signal-list">
                {item.analysis.signals.map((s) => (
                  <div key={s.id} className={`signal-row ${s.tone}`}>
                    <span className="dot" />
                    <div>
                      <b>{s.label}</b>
                      <p>{s.detail}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
            {detailTab === "metadata" && (
              <dl className="kv tight">
                {Object.entries(item.analysis.metadata).map(([k, v]) => (
                  <div key={k} style={{ display: "contents" }}>
                    <dt>{k}</dt>
                    <dd>{v}</dd>
                  </div>
                ))}
                <dt>SHA-256</dt>
                <dd className="mono" style={{ fontSize: 10 }}>
                  {item.hash}
                </dd>
              </dl>
            )}
            {detailTab === "custody" && <Custody item={item} />}
          </div>

          <div className="side-card">
            <div className="side-title">What this means</div>
            <ul className="note-list">
              {(item.analysis.notes ?? []).map((n) => (
                <li key={n}>{n}</li>
              ))}
              {prov?.verdict === "authentic-capture" && (
                <li>
                  A camera record plus an absence of AI markers is the strongest available result. Keep the original file
                  untouched and re-verify its SHA-256 before it is used in any proceeding.
                </li>
              )}
            </ul>
          </div>
        </aside>
      </div>

      <div className="action-bar">
        <button className="btn" type="button" onClick={() => setNotesOpen(true)}>
          <Icon name="search" size={14} /> Review details
        </button>
        <div className={`action-verdict tone-${tone}`}>
          <Icon name={tone === "ok" ? "check" : "alert"} size={16} />
          {tone === "ok"
            ? item.kind === "code"
              ? "No serious weakness found"
              : "No AI evidence found"
            : `${item.analysis.aiLikelihood}% ${item.kind === "code" ? "risk" : "AI likelihood"}`}
        </div>
        <button className="btn btn-primary" type="button" onClick={exportPack}>
          <Icon name="download" size={14} /> Export pack
        </button>
      </div>

      {notesOpen && (
        <div className="modal-backdrop" onClick={() => setNotesOpen(false)}>
          <div className="modal" style={{ width: 620 }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-head">
              <Icon name="evidence" />
              <div style={{ flex: 1 }}>
                <h2 style={{ fontSize: 16 }}>Review details</h2>
                <div className="tiny muted">Plain-language reading of every number in this exhibit.</div>
              </div>
              <button className="close-btn" type="button" onClick={() => setNotesOpen(false)}>
                <Icon name="close" size={14} />
              </button>
            </div>
            <div className="modal-body stack" style={{ gap: 12 }}>
              {checks.map((c) => (
                <div key={`d-${c.id}`} className="review-row">
                  <StatusDot status={c.status} />
                  <div>
                    <b>
                      {c.name} <span className="mono muted">{c.metric}</span>
                    </b>
                    <p>{c.detail}</p>
                  </div>
                </div>
              ))}
              <div className="review-row">
                <StatusDot status="na" />
                <div>
                  <b>Integrity</b>
                  <p>
                    The file was fingerprinted with SHA-256 when it was added
                    {item.integrity ? ` and last re-checked ${formatDate(item.integrity.checkedAt)}: ${item.integrity.status}` : ". Re-check it to prove the bytes have not changed since."}
                  </p>
                </div>
              </div>
              <div className="row" style={{ justifyContent: "flex-end", gap: 8 }}>
                <button
                  className="btn btn-sm"
                  type="button"
                  disabled={verifying}
                  onClick={async () => {
                    setVerifying(true);
                    const { verifyIntegrity } = await import("../lib/store");
                    await verifyIntegrity(caseId, item);
                    setVerifying(false);
                  }}
                >
                  <Icon name="shield" size={12} /> {verifying ? "Re-hashing…" : "Re-check hash"}
                </button>
                <button
                  className="btn btn-sm btn-danger"
                  type="button"
                  onClick={() => {
                    removeEvidence(caseId, item.id);
                    onBack();
                  }}
                >
                  <Icon name="trash" size={12} /> Remove exhibit
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function StatusDot({ status }: { status: ForensicCheck["status"] }) {
  return <span className={`status-dot s-${status}`} />;
}

function CheckCard({ check }: { check: ForensicCheck }) {
  const label =
    check.status === "pass" ? "clear" : check.status === "warn" ? "review" : check.status === "fail" ? "flagged" : "n/a";
  return (
    <div className={`check-card s-${check.status}`}>
      <div className="check-top">
        <StatusDot status={check.status} />
        <span>{check.name}</span>
        <b>{label}</b>
      </div>
      <div className="check-metric">{check.metric}</div>
      <p>{check.detail}</p>
    </div>
  );
}

function ProvenanceCard({ provenance }: { provenance: NonNullable<EvidenceItem["analysis"]["provenance"]> }) {
  const ai = provenance.verdict === "synthetic";
  return (
    <div className={`side-card prov ${ai ? "prov-ai" : provenance.verdict === "authentic-capture" ? "prov-good" : ""}`}>
      <div className="side-title">
        <Icon name={ai ? "alert" : "shield"} size={13} /> Watermarks &amp; source record
      </div>
      <div className="prov-headline">{provenance.headline}</div>
      <p className="prov-plain">{provenance.plain}</p>
      <div className="prov-hits">
        {provenance.hits.length === 0 && <div className="prov-empty">No watermark, C2PA manifest or generator name was found in the file.</div>}
        {provenance.hits.map((h) => (
          <div key={h.id} className={`prov-hit ${h.tone}`}>
            <div className="prov-hit-top">
              <b>{h.label}</b>
              <span>{h.strength}%</span>
            </div>
            <code>{h.where}</code>
            {h.evidence && <code className="evidence">“{h.evidence}”</code>}
            <p>{h.meaning}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function Custody({ item }: { item: EvidenceItem }) {
  const steps = [
    { label: "Registered in case", when: item.addedAt, note: `${formatBytes(item.size)} intake` },
    { label: "SHA-256 computed", when: item.hashAt, note: `${item.hash.slice(0, 18)}…` },
    { label: "Automated analysis", when: item.addedAt, note: `${item.analysis.signals.length} signals recorded` },
    item.integrity
      ? { label: "Integrity re-check", when: item.integrity.checkedAt, note: item.integrity.status }
      : { label: "Integrity re-check", when: null, note: "not yet run" },
  ];
  return (
    <ol className="custody">
      {steps.map((s) => (
        <li key={s.label}>
          <span className="custody-dot" />
          <div>
            <b>{s.label}</b>
            <em>{s.note}</em>
            <span>{s.when ? formatDate(s.when) : "—"}</span>
          </div>
        </li>
      ))}
    </ol>
  );
}

/* -------------------------------- viewers -------------------------------- */

function Viewer({ item, url, caseId }: { item: EvidenceItem; url: string | null; caseId: string }) {
  if (item.kind === "image") return <ImagePanel item={item} url={url} caseId={caseId} />;
  if (item.kind === "audio") return <AudioPanel item={item} url={url} />;
  if (item.kind === "video") return <VideoPanel item={item} url={url} />;
  if (item.kind === "code") return <CodePanel item={item} />;
  return <DocumentPanel item={item} url={url} />;
}

function heatColor(v: number): string {
  if (v < 0.4) return `rgba(34, 211, 197, ${(0.14 + v * 0.5).toFixed(3)})`;
  if (v < 0.68) return `rgba(240, 190, 70, ${(0.25 + (v - 0.4) * 1.6).toFixed(3)})`;
  return `rgba(255, 90, 105, ${Math.min(0.85, 0.4 + (v - 0.68) * 1.6).toFixed(3)})`;
}

function ImagePanel({ item, url, caseId }: { item: EvidenceItem; url: string | null; caseId: string }) {
  const [drag, setDrag] = useState<{ ax: number; ay: number; bx: number; by: number } | null>(null);
  const [showHeat, setShowHeat] = useState(true);
  const [busy, setBusy] = useState(false);
  const [zoom, setZoom] = useState(false);
  const previewRef = useRef<HTMLDivElement>(null);

  const selection = drag
    ? {
        x: Math.min(drag.ax, drag.bx),
        y: Math.min(drag.ay, drag.by),
        w: Math.abs(drag.bx - drag.ax),
        h: Math.abs(drag.by - drag.ay),
      }
    : item.regionQuery?.rect ?? null;

  const relative = (event: ReactPointerEvent) => {
    const rect = previewRef.current?.getBoundingClientRect();
    if (!rect) return { x: 0, y: 0 };
    return {
      x: Math.max(0, Math.min(1, (event.clientX - rect.left) / rect.width)),
      y: Math.max(0, Math.min(1, (event.clientY - rect.top) / rect.height)),
    };
  };

  const runRegion = async (rect: { x: number; y: number; w: number; h: number }) => {
    const blob = mediaCache.get(item.id);
    if (!blob || rect.w < 0.02 || rect.h < 0.02) return;
    setBusy(true);
    try {
      const result = await analyzeImageRegion(blob, rect);
      updateEvidence(caseId, item.id, { regionQuery: result });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="panel">
      <div className="panel-head">
        <span>Forensic workspace</span>
        <div className="panel-actions">
          <button className={`chip-btn ${showHeat ? "on" : ""}`} type="button" onClick={() => setShowHeat((v) => !v)}>
            ELA heat map
          </button>
          <button className={`chip-btn ${zoom ? "on" : ""}`} type="button" onClick={() => setZoom((v) => !v)}>
            {zoom ? "Fit" : "Zoom"}
          </button>
          {busy && <span className="chip chip-cyan">analysing region…</span>}
        </div>
      </div>
      <div
        className={`viewer ${zoom ? "zoomed" : ""}`}
        ref={previewRef}
        onPointerDown={(e) => {
          if (!url) return;
          e.currentTarget.setPointerCapture(e.pointerId);
          const p = relative(e);
          setDrag({ ax: p.x, ay: p.y, bx: p.x, by: p.y });
        }}
        onPointerMove={(e) => {
          if (!drag) return;
          const p = relative(e);
          setDrag({ ...drag, bx: p.x, by: p.y });
        }}
        onPointerUp={() => {
          if (!drag) return;
          const rect = {
            x: Math.min(drag.ax, drag.bx),
            y: Math.min(drag.ay, drag.by),
            w: Math.abs(drag.bx - drag.ax),
            h: Math.abs(drag.by - drag.ay),
          };
          setDrag(null);
          void runRegion(rect);
        }}
      >
        {url ? (
          <img src={url} alt={item.name} draggable={false} />
        ) : item.analysis.thumbnail ? (
          <img src={item.analysis.thumbnail} alt={`${item.name} preview`} draggable={false} />
        ) : (
          <div className="viewer-empty">Preview unavailable — re-add the file to interrogate regions.</div>
        )}
        {showHeat && item.analysis.heatmap && (
          <svg
            className="heat"
            viewBox={`0 0 ${item.analysis.heatmap[0].length} ${item.analysis.heatmap.length}`}
            preserveAspectRatio="none"
          >
            {item.analysis.heatmap.map((row, y) =>
              row.map((v, x) => <rect key={`${x}-${y}`} x={x} y={y} width={1.01} height={1.01} fill={heatColor(v)} />)
            )}
          </svg>
        )}
        {selection && selection.w > 0.005 && (
          <div
            className="sel"
            style={{
              left: `${selection.x * 100}%`,
              top: `${selection.y * 100}%`,
              width: `${selection.w * 100}%`,
              height: `${selection.h * 100}%`,
            }}
          />
        )}
        <div className="viewer-hint">Drag a box on the image to ask about one specific area</div>
      </div>
      <div className="heat-legend">
        <span>untouched</span>
        <span className="heat-scale" />
        <span>edited / regenerated</span>
      </div>

      {item.regionQuery && (
        <div className="region-result">
          <div className="row" style={{ justifyContent: "space-between" }}>
            <b>Selected area</b>
            <span style={{ color: scoreColor(item.regionQuery.score) }}>{item.regionQuery.score}% manipulation signal</span>
          </div>
          <p>{item.regionQuery.verdict}.</p>
          <ul>
            {item.regionQuery.reasons.map((r) => (
              <li key={r}>{r}</li>
            ))}
          </ul>
        </div>
      )}

      {item.analysis.regions && item.analysis.regions.length > 0 && (
        <div className="region-grid">
          {item.analysis.regions.map((r) => (
            <button
              key={r.id}
              type="button"
              className="region-chip"
              onClick={() => void runRegion({ x: r.x, y: r.y, w: Math.max(r.w * 3, 0.08), h: Math.max(r.h * 3, 0.08) })}
            >
              <b>{r.label}</b>
              <span>
                {r.score}% · at {Math.round(r.x * 100)}% / {Math.round(r.y * 100)}%
              </span>
              <em>{r.detail}</em>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function AudioPanel({ item, url }: { item: EvidenceItem; url: string | null }) {
  const waveform = item.analysis.waveform ?? [];
  const spectrum = item.analysis.spectrum ?? [];
  return (
    <div className="panel">
      <div className="panel-head">
        <span>Submitted audio</span>
        <span className="chip">{item.analysis.metadata.Duration ?? ""}</span>
      </div>
      <div className="audio-body">
        {url ? (
          <audio src={url} controls className="audio-player" />
        ) : (
          <p className="tiny muted">Playback needs the original file in this session.</p>
        )}
        <div className="wave">
          {waveform.length ? (
            waveform.map((v, i) => (
              <span key={i} style={{ height: `${Math.max(3, v * 100)}%` }} />
            ))
          ) : (
            <div className="viewer-empty">Waveform not available for this container.</div>
          )}
        </div>
        <div className="axis">
          <span>0 s</span>
          <span>{item.analysis.metadata.Duration ?? ""}</span>
        </div>
      </div>
      <div className="sub-head">Frequency energy</div>
      <div className="spectrum">
        {spectrum.length ? (
          spectrum.map((v, i) => (
            <span key={i} style={{ height: `${Math.max(2, v * 100)}%` }} className={i > spectrum.length * 0.78 ? "hi" : ""} />
          ))
        ) : (
          <div className="viewer-empty">Spectrum unavailable.</div>
        )}
      </div>
      <div className="axis">
        <span>low</span>
        <span>{item.analysis.spectrumMaxHz ? `${Math.round(item.analysis.spectrumMaxHz / 1000)} kHz` : ""}</span>
      </div>
      <p className="panel-note">
        The highlighted right-hand band is above 16 kHz — where generated speech usually stops and a real microphone keeps
        a little noise.
      </p>
    </div>
  );
}

function VideoPanel({ item, url }: { item: EvidenceItem; url: string | null }) {
  return (
    <div className="panel">
      <div className="panel-head">
        <span>Video workspace</span>
        <span className="chip">{item.analysis.metadata.Resolution ?? ""}</span>
      </div>
      {url ? (
        <video src={url} controls className="video-player" />
      ) : (
        <div className="viewer-empty">Playback needs the original file in this session.</div>
      )}
      {item.analysis.keyframes && item.analysis.keyframes.length > 0 && (
        <>
          <div className="sub-head">Sampled frames</div>
          <div className="frames">
            {item.analysis.keyframes.map((k) => (
              <figure key={k.t}>
                <img src={k.thumb} alt={`frame at ${k.t}s`} />
                <figcaption>
                  {k.t}s<em>{k.note}</em>
                </figcaption>
              </figure>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function DocumentPanel({ item, url }: { item: EvidenceItem; url: string | null }) {
  const sentences = item.analysis.sentences ?? [];
  return (
    <div className="panel">
      <div className="panel-head">
        <span>Document workspace</span>
        <span className="chip">{item.analysis.metadata["Words extracted"] ?? "0"} words</span>
      </div>
      {sentences.length > 0 ? (
        <div className="sentence-map">
          {sentences.map((s, i) => (
            <span key={i} className={`sent ${s.score >= 70 ? "hi" : s.score >= 45 ? "mid" : ""}`} title={s.reasons.join(" · ")}>
              {s.text}{" "}
            </span>
          ))}
        </div>
      ) : (
        <div className="excerpt">{item.analysis.excerpt || "No text layer could be extracted."}</div>
      )}
      <p className="panel-note">
        Each sentence is coloured by its own score: <b className="hi">red</b> is strongly machine-like, <b className="mid">amber</b> mixed,
        plain text human-like. Hover a sentence to see why.
      </p>
      {url && <a className="btn btn-sm" style={{ marginTop: 10 }} href={url} download={item.name}>Download original</a>}
    </div>
  );
}

function CodePanel({ item }: { item: EvidenceItem }) {
  const lines = (item.analysis.excerpt ?? "").split("\n").slice(0, 220);
  return (
    <div className="panel">
      <div className="panel-head">
        <span>Source workspace</span>
        <span className="chip">{item.analysis.metadata.Language ?? "code"}</span>
      </div>
      <div className="code-view">
        {lines.map((l, i) => (
          <div key={i}>
            <span className="ln">{i + 1}</span>
            <code>{l || " "}</code>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ------------------------------- text panel ------------------------------- */

function TextPanel({ item, caseId }: { item: EvidenceItem; caseId: string }) {
  const [quote, setQuote] = useState("");
  const [question, setQuestion] = useState("Is this portion AI-generated?");
  const sentences = item.analysis.sentences ?? [];

  const run = () => {
    const source = quote.trim() || item.analysis.excerpt?.slice(0, 1200) || "";
    if (!source) return;
    const res = analyzeQuotedPortion(question, source);
    updateEvidence(caseId, item.id, {
      textQuery: { question: res.question, quote: res.quote, score: res.score, verdict: res.verdict, reasons: res.reasons },
    });
  };

  const flagged = useMemo(() => sentences.filter((s) => s.score >= 50).length, [sentences]);

  return (
    <div className="panel">
      <div className="panel-head">
        <span>Ask about one portion</span>
        <span className="chip">{flagged} sentence(s) flagged</span>
      </div>
      <p className="panel-note">
        Click a sentence below or paste an exact passage. Only that portion is scored, and the answer explains itself.
      </p>
      <div className="quote-sentences">
        {sentences.slice(0, 12).map((s, i) => (
          <button key={i} type="button" className={`quote-sentence ${s.score >= 60 ? "flag" : ""}`} onClick={() => setQuote(s.text)}>
            <b>{s.score}%</b>
            {s.text}
          </button>
        ))}
      </div>
      <div className="field">
        <span>Question</span>
        <input className="input" value={question} onChange={(e) => setQuestion(e.target.value)} />
      </div>
      <div className="field" style={{ marginTop: 8 }}>
        <span>Quoted portion</span>
        <textarea
          className="textarea"
          style={{ minHeight: 84 }}
          value={quote}
          placeholder="Paste the passage you are asking about…"
          onChange={(e) => setQuote(e.target.value)}
        />
      </div>
      <button className="btn btn-primary btn-sm" style={{ marginTop: 10 }} type="button" onClick={run}>
        <Icon name="search" size={12} /> Analyse this portion
      </button>
      {item.textQuery && (
        <div className="region-result" style={{ marginTop: 12 }}>
          <div className="row" style={{ justifyContent: "space-between" }}>
            <b>{item.textQuery.verdict}</b>
            <span style={{ color: scoreColor(item.textQuery.score) }}>{item.textQuery.score}% AI likelihood</span>
          </div>
          <ul>
            {item.textQuery.reasons.map((r) => (
              <li key={r}>{r}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
