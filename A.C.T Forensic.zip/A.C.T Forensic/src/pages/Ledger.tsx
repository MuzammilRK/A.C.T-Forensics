import { useState } from "react";
import { activeCase, useAppStore, verifyIntegrity } from "../lib/store";
import { buildManifest } from "../lib/report";
import { downloadText, formatBytes, formatDate } from "../lib/hash";
import { CopyButton, Empty, Icon } from "../components/ui";

export function Ledger() {
  const state = useAppStore();
  const caseFile = activeCase(state);
  const [busy, setBusy] = useState<string | null>(null);
  const [checkingAll, setCheckingAll] = useState(false);

  const verifyOne = async (id: string) => {
    const item = caseFile.evidence.find((e) => e.id === id);
    if (!item) return;
    setBusy(id);
    await verifyIntegrity(caseFile.id, item);
    setBusy(null);
  };

  const verifyAll = async () => {
    setCheckingAll(true);
    for (const item of caseFile.evidence) {
      await verifyIntegrity(caseFile.id, item);
    }
    setCheckingAll(false);
  };

  const manifest = buildManifest(caseFile);
  const verified = caseFile.evidence.filter((e) => e.integrity?.status === "verified").length;
  const modified = caseFile.evidence.filter((e) => e.integrity?.status === "modified").length;

  return (
    <div className="stack" style={{ gap: 18 }}>
      <div className="page-head">
        <div>
          <div className="eyebrow">Chain of custody</div>
          <h1 className="page-title">SHA-256 integrity ledger</h1>
          <p className="page-sub">
            Every exhibit is fingerprinted at intake. Re-verification recomputes the digest locally and compares it with
            the registered baseline — any byte-level change is surfaced immediately.
          </p>
        </div>
        <div className="row">
          <button className="btn" type="button" onClick={verifyAll} disabled={checkingAll || !caseFile.evidence.length}>
            <Icon name="refresh" size={14} /> {checkingAll ? "Verifying…" : "Verify all"}
          </button>
          <button
            className="btn"
            type="button"
            disabled={!manifest.length}
            onClick={() => downloadText(`${caseFile.reference}-manifest.json`, JSON.stringify(manifest, null, 2))}
          >
            <Icon name="download" size={14} /> Export manifest
          </button>
        </div>
      </div>

      <div className="grid grid-4">
        <div className="stat">
          <div className="stat-label">Exhibits registered</div>
          <div className="stat-value">{caseFile.evidence.length}</div>
        </div>
        <div className="stat">
          <div className="stat-label">Digest matches</div>
          <div className="stat-value accent-cyan">{verified}</div>
        </div>
        <div className="stat">
          <div className="stat-label">Altered after intake</div>
          <div className="stat-value accent-red">{modified}</div>
        </div>
        <div className="stat">
          <div className="stat-label">Algorithm</div>
          <div className="stat-value" style={{ fontSize: 20, paddingTop: 8 }}>
            SHA-256
          </div>
          <div className="stat-note">WebCrypto · 256-bit digest</div>
        </div>
      </div>

      {caseFile.evidence.length === 0 ? (
        <Empty title="No exhibits registered" icon="ledger">
          Add exhibits in the Evidence Lab. Each file is hashed on intake and appears here with its manifest entry.
        </Empty>
      ) : (
        <section className="card">
          <div className="card-head">
            <Icon name="ledger" size={15} />
            <div className="card-title">Custody register — {caseFile.reference}</div>
            <span className="card-sub">{caseFile.evidence.length} entries</span>
          </div>
          <div style={{ padding: "4px 10px 12px", overflowX: "auto" }}>
            <table className="table">
              <thead>
                <tr>
                  <th>Exhibit</th>
                  <th>SHA-256 digest</th>
                  <th>Registered</th>
                  <th>Last check</th>
                  <th>Status</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {caseFile.evidence.map((item) => (
                  <tr key={item.id}>
                    <td>
                      <strong>{item.name}</strong>
                      <div className="tiny" style={{ color: "var(--muted-2)", marginTop: 2 }}>
                        {item.kind.toUpperCase()} · {formatBytes(item.size)}
                      </div>
                    </td>
                    <td>
                      <div className="mono tiny" style={{ maxWidth: 320, overflowWrap: "anywhere" }}>
                        {item.hash}
                      </div>
                      <div style={{ marginTop: 4 }}>
                        <CopyButton text={item.hash} label="Copy" />
                      </div>
                    </td>
                    <td className="tiny">{formatDate(item.hashAt)}</td>
                    <td className="tiny">{item.integrity ? formatDate(item.integrity.checkedAt) : "—"}</td>
                    <td>
                      <span
                        className={`badge ${
                          item.integrity?.status === "verified"
                            ? "badge-good"
                            : item.integrity?.status === "modified"
                            ? "badge-critical"
                            : "badge-info"
                        }`}
                      >
                        {item.integrity?.status ?? "baseline"}
                      </span>
                    </td>
                    <td>
                      <button
                        className="btn btn-sm btn-ghost"
                        type="button"
                        disabled={busy === item.id}
                        onClick={() => void verifyOne(item.id)}
                      >
                        {busy === item.id ? "…" : "Verify"}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      <div className="grid grid-2">
        <section className="card card-pad">
          <div className="label">Why SHA-256</div>
          <p className="tiny muted" style={{ marginTop: 8, lineHeight: 1.75 }}>
            A 256-bit cryptographic digest is effectively unique to a file's bytes. Changing a single pixel changes the
            hash completely, so a digest recorded at seizure can prove an exhibit is unaltered when it reaches court.
            Unlike MD5 or SHA-1, SHA-256 has no practical collision attacks.
          </p>
          <div className="row" style={{ marginTop: 12, gap: 6 }}>
            <span className="chip chip-cyan">collision resistant</span>
            <span className="chip">deterministic</span>
            <span className="chip">one-way</span>
          </div>
        </section>
        <section className="card card-pad">
          <div className="label">Session limitation</div>
          <p className="tiny muted" style={{ marginTop: 8, lineHeight: 1.75 }}>
            Re-verification needs the original file bytes, which are held only for the current browser session. The
            registered digest persists, so a production deployment re-checks against vaulted originals. Files marked
            <span className="mono"> unavailable </span>
            were registered in an earlier session — re-upload the original to re-verify it.
          </p>
          <div className="row" style={{ marginTop: 12, gap: 6 }}>
            <span className="chip">local-first</span>
            <span className="chip">no third-party upload</span>
          </div>
        </section>
      </div>
    </div>
  );
}
