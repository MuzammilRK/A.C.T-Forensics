import { useMemo, useState } from "react";
import type { GraphNode } from "../lib/types";
import { activeCase, useAppStore } from "../lib/store";
import { buildThreatGraph, linkSummary } from "../lib/graph";
import { GraphView } from "../components/GraphView";
import { Empty, Icon, SeverityBadge, kindIcon } from "../components/ui";
import { formatBytes } from "../lib/hash";

export function AttackPaths() {
  const state = useAppStore();
  const caseFile = activeCase(state);
  const graph = useMemo(() => buildThreatGraph(caseFile, false), [caseFile]);
  const [active, setActive] = useState(0);
  const [node, setNode] = useState<GraphNode | null>(null);
  const path = graph.paths[active] ?? graph.paths[0];
  const activeNodes = path ? path.nodes.map((n) => n.id) : [];

  return (
    <div className="stack" style={{ gap: 18 }}>
      <div className="page-head">
        <div>
          <div className="eyebrow">Predictive analysis</div>
          <h1 className="page-title">Attack-path prediction</h1>
          <p className="page-sub">
            Weaknesses found by the scanner are chained from entry point to asset to impact. Each route is scored by the
            product of its edge likelihoods so remediation can be prioritised by real exposure.
          </p>
        </div>
        <div className="row">
          <span className="chip chip-cyan">{graph.paths.length} ranked routes</span>
          <span className="chip">
            {graph.nodes.filter((n) => n.kind === "weakness").length} weakness nodes
          </span>
        </div>
      </div>

      {graph.paths.length === 0 ? (
        <Empty title="No attack paths yet" icon="graph">
          Run an application scan or complete the login &amp; network posture audit. Paths are generated automatically
          from findings and the assets they can reach.
        </Empty>
      ) : (
        <div className="grid" style={{ gridTemplateColumns: "minmax(0, 1.6fr) minmax(0, 1fr)", alignItems: "start" }}>
          <div className="stack">
            <GraphView graph={graph} activeNodes={activeNodes} onSelect={setNode} />
            {node && (
              <div className="card card-pad">
                <div className="row" style={{ justifyContent: "space-between" }}>
                  <div className="row" style={{ gap: 8 }}>
                    <span className="badge badge-info">{node.kind}</span>
                    {node.severity && <SeverityBadge severity={node.severity} />}
                    <strong style={{ fontSize: 13 }}>{node.label}</strong>
                  </div>
                  <button className="btn btn-sm btn-ghost" onClick={() => setNode(null)} type="button">
                    Dismiss
                  </button>
                </div>
                <p className="tiny muted" style={{ marginTop: 8, lineHeight: 1.65 }}>
                  {node.detail ?? "No additional detail recorded for this node."}
                </p>
              </div>
            )}
          </div>

          <div className="stack" style={{ gap: 10 }}>
            <div className="label">Ranked exploitation routes</div>
            {graph.paths.map((p, i) => (
              <div
                key={p.nodes.map((n) => n.id).join("-")}
                className={`path-card ${i === active ? "active" : ""}`}
                onClick={() => setActive(i)}
              >
                <div className="row" style={{ justifyContent: "space-between", marginBottom: 6 }}>
                  <div className="row" style={{ gap: 6 }}>
                    <span className="mono tiny" style={{ color: "var(--muted-2)" }}>
                      PATH {String(i + 1).padStart(2, "0")}
                    </span>
                    <SeverityBadge severity={p.severity} />
                  </div>
                  <span className="prob">{p.probability}% likelihood</span>
                </div>
                <div className="path-chain">
                  {p.nodes.map((n, idx) => (
                    <span key={n.id}>
                      {idx > 0 && <span>→</span>}
                      <span style={{ color: idx === p.nodes.length - 1 ? "var(--red)" : undefined }}>{n.label}</span>
                    </span>
                  ))}
                </div>
                {i === active && (
                  <>
                    <p className="signal-detail" style={{ marginTop: 10 }}>
                      {p.narrative}
                    </p>
                    <div className="card card-pad" style={{ marginTop: 10, borderColor: "rgba(63,224,207,0.3)" }}>
                      <div className="label" style={{ color: "var(--cyan)" }}>
                        Fix this first
                      </div>
                      <p className="tiny" style={{ marginTop: 5, lineHeight: 1.65 }}>
                        {p.mitigation}
                      </p>
                    </div>
                  </>
                )}
              </div>
            ))}
            <div className="card card-pad">
              <div className="label">How prediction works</div>
              <p className="tiny muted" style={{ marginTop: 6, lineHeight: 1.7 }}>
                Each finding is mapped to the entry point it exposes and the asset it endangers. Edge weights combine
                severity, exploit complexity and asset sensitivity; the path score is the chained product. When the
                evidence vault is reachable, the route also appears in the Threat-Link Graph.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export function ThreatLink() {
  const state = useAppStore();
  const caseFile = activeCase(state);
  const graph = useMemo(() => buildThreatGraph(caseFile, true), [caseFile]);
  const links = useMemo(() => linkSummary(caseFile), [caseFile]);
  const [active, setActive] = useState(0);
  const path = graph.paths[active] ?? graph.paths[0];
  const risky = links.filter((l) => l.risk >= 40).sort((a, b) => b.risk - a.risk);

  return (
    <div className="stack" style={{ gap: 18 }}>
      <div className="page-head">
        <div>
          <div className="eyebrow">Unique capability</div>
          <h1 className="page-title">Evidence Threat-Link Graph</h1>
          <p className="page-sub">
            The platform's differentiator: application weaknesses and exhibit-level authenticity findings share one
            graph, so an unpatched upload API is shown next to the exhibits it could have altered.
          </p>
        </div>
        <span className="chip chip-cyan">
          <Icon name="link" size={12} /> {links.length} exhibits linked
        </span>
      </div>

      <div className="grid" style={{ gridTemplateColumns: "minmax(0, 1.55fr) minmax(0, 1fr)", alignItems: "start" }}>
        <GraphView
          graph={graph}
          activeNodes={path ? path.nodes.map((n) => n.id) : []}
          onSelect={() => undefined}
        />
        <div className="stack" style={{ gap: 10 }}>
          <div className="label">Linked evidence risk</div>
          {risky.length === 0 ? (
            <Empty title="No high-risk exhibits linked" icon="shield">
              Upload exhibits and run an application scan. Exhibits with elevated manipulation likelihood, a changed
              hash, or exposure through a vulnerable endpoint appear here.
            </Empty>
          ) : (
            risky.slice(0, 5).map((l) => (
              <div className="path-card" key={l.evidence.id}>
                <div className="row" style={{ justifyContent: "space-between" }}>
                  <div className="row" style={{ gap: 8, minWidth: 0 }}>
                    <span className="ev-icon" style={{ width: 26, height: 26, borderRadius: 6 }}>
                      <Icon name={kindIcon(l.evidence.kind)} size={13} />
                    </span>
                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontSize: 12, fontWeight: 550, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                        {l.evidence.name}
                      </div>
                      <div className="ev-meta">
                        {formatBytes(l.evidence.size)} · {l.evidence.analysis.aiLikelihood}% synthetic
                      </div>
                    </div>
                  </div>
                  <span className="prob">{l.risk}% risk</span>
                </div>
                <div className="meter" style={{ marginTop: 10 }}>
                  <div
                    style={{
                      width: `${l.risk}%`,
                      background: l.risk >= 70 ? "var(--red)" : "linear-gradient(90deg, var(--amber), var(--red))",
                    }}
                  />
                </div>
                <div className="stack" style={{ gap: 5, marginTop: 10 }}>
                  {l.exposures.length ? (
                    l.exposures.map((e) => (
                      <div className="row" key={e.id} style={{ gap: 6, fontSize: 10.5, color: "var(--muted)" }}>
                        <SeverityBadge severity={e.severity} />
                        <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{e.title}</span>
                      </div>
                    ))
                  ) : (
                    <div className="tiny" style={{ color: "var(--muted-2)" }}>
                      No application weakness currently reaches this exhibit's asset.
                    </div>
                  )}
                </div>
                {l.evidence.integrity?.status === "modified" && (
                  <div className="tiny" style={{ color: "var(--red)", marginTop: 8 }}>
                    ⚠ Hash mismatch detected — exhibit may have been altered after intake.
                  </div>
                )}
              </div>
            ))
          )}

          <div className="card card-pad">
            <div className="label">The connection</div>
            <p className="tiny muted" style={{ marginTop: 6, lineHeight: 1.7 }}>
              {risky[0]
                ? `${risky[0].evidence.name} sits in the evidence vault. ${
                    risky[0].exposures[0]?.title ?? "No open weakness currently reaches that vault"
                  }${risky[0].exposures[0] ? " would let an attacker reach that asset without touching the exhibit itself." : "."}`
                : "Link exhibits and vulnerabilities to see compound exposure across the case."}
            </p>
            <div className="row" style={{ marginTop: 10 }}>
              <span className="chip">Manipulation signals</span>
              <span className="chip">+</span>
              <span className="chip">Vulnerability register</span>
              <span className="chip">=</span>
              <span className="chip chip-cyan">compound threat</span>
            </div>
          </div>

          {path && (
            <div className="card card-pad">
              <div className="row" style={{ justifyContent: "space-between" }}>
                <div className="label">Top predicted route</div>
                <span className="prob">{path.probability}%</span>
              </div>
              <div className="path-chain" style={{ marginTop: 8 }}>
                {path.nodes.map((n, i) => (
                  <span key={n.id}>
                    {i > 0 && <span>→</span>}
                    {n.label}
                  </span>
                ))}
              </div>
              <div className="row" style={{ marginTop: 10, gap: 6 }}>
                <button className="btn btn-sm btn-ghost" type="button" onClick={() => setActive((a) => (a + 1) % Math.max(1, graph.paths.length))}>
                  <Icon name="refresh" size={12} /> Cycle route
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
