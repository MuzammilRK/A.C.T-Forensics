import { useRef, useState } from "react";
import type { Severity, WebsiteAudit } from "../lib/types";
import { activeCase, addAudit, useAppStore } from "../lib/store";
import { auditWebsite, normalizeUrl, SAMPLE_PAGE_HTML } from "../lib/website";
import { formatDate } from "../lib/hash";
import { Empty, Icon, SeverityBadge } from "../components/ui";

const SEVERITIES: Severity[] = ["critical", "high", "medium", "low", "info"];

export function WebsiteScanner() {
  const state = useAppStore();
  const caseFile = activeCase(state);
  const [url, setUrl] = useState("");
  const [rawHtml, setRawHtml] = useState("");
  const [showPaste, setShowPaste] = useState(false);
  const [busy, setBusy] = useState(false);
  const [step, setStep] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<WebsiteAudit | null>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  const audits = caseFile.audits ?? [];

  const execute = async (target: string, source?: string) => {
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      const audit = await auditWebsite(target, {
        rawHtml: source,
        onStep: (m) => setStep(m),
      });
      setResult(audit);
      addAudit(caseFile.id, audit);
      setStep("");
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  };

  const run = () => {
    if (!normalizeUrl(url)) {
      setError("Enter a web address, for example example.com or https://example.com/.");
      return;
    }
    void execute(url, showPaste && rawHtml.trim().length > 40 ? rawHtml : undefined);
  };

  const runSample = () => {
    setUrl("https://alder-demo.example");
    void execute("https://alder-demo.example", SAMPLE_PAGE_HTML);
  };

  const loadSavedPage = async (file: File) => {
    const text = await file.text();
    setRawHtml(text);
    setShowPaste(true);
    if (!normalizeUrl(url)) setUrl("https://saved-page.local");
    void execute(normalizeUrl(url) || "https://saved-page.local", text);
  };

  return (
    <div className="stack" style={{ gap: 18 }}>
      <div className="page-head">
        <div>
          <div className="eyebrow">Website security</div>
          <h1 className="page-title">Check any website's source</h1>
          <p className="page-sub">
            Paste a link. A.C.T fetches the page and reads its source the way an attacker would: scripts, forms,
            headers, keys, comments and outdated libraries. Nothing is exploited and no login is attempted.
          </p>
        </div>
      </div>

      <section className="web-search">
        <div className="web-input">
          <Icon name="link" size={17} />
          <input
            className="input"
            placeholder="https://example.com"
            value={url}
            spellCheck={false}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") void run();
            }}
          />
          <button className="btn btn-primary" type="button" onClick={() => void run()} disabled={busy}>
            {busy ? "Scanning…" : "Scan site"}
          </button>
        </div>
        <div className="web-hint">
          <span>{step || "Reads the HTML, inline scripts, response headers and linked libraries."}</span>
          <div className="row" style={{ gap: 12 }}>
            <button className="link-btn" type="button" onClick={runSample}>
              Try a sample site
            </button>
            <button className="link-btn" type="button" onClick={() => fileInput.current?.click()}>
              Upload a saved page
            </button>
            <button className="link-btn" type="button" onClick={() => setShowPaste((v) => !v)}>
              {showPaste ? "Hide source paste" : "Paste source"}
            </button>
          </div>
        </div>
        <input
          ref={fileInput}
          type="file"
          accept=".html,.htm,text/html"
          hidden
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) void loadSavedPage(file);
            e.target.value = "";
          }}
        />
        <p className="tiny" style={{ color: "var(--muted-2)", marginTop: 6, lineHeight: 1.55 }}>
          Browsers block reading another site's HTML directly. If the request fails, open the site, press Ctrl+S to save
          the page, and upload the .html file — the review is identical.
        </p>
        {showPaste && (
          <textarea
            className="textarea"
            style={{ minHeight: 120, marginTop: 10 }}
            placeholder="Paste the full page source (Ctrl+U → Ctrl+A → Ctrl+C)…"
            value={rawHtml}
            onChange={(e) => setRawHtml(e.target.value)}
          />
        )}
      </section>

      {error && (
        <div className="notice notice-risk">
          <Icon name="alert" size={15} />
          <div>
            <b>That scan could not run</b>
            <p>{error}</p>
          </div>
        </div>
      )}

      {busy && !result && (
        <div className="card card-pad">
          <div className="progress">
            <div style={{ width: "55%" }} />
          </div>
          <p className="tiny muted" style={{ marginTop: 8 }}>
            {step || "Fetching and reading the page…"}
          </p>
        </div>
      )}

      {result && <AuditView audit={result} />}

      {!result && audits.length > 0 && (
        <div className="stack" style={{ gap: 10 }}>
          <div className="side-title">Previous scans in this case</div>
          {audits.map((a) => (
            <button key={a.id} type="button" className="batch-row" onClick={() => setResult(a)}>
              <span className="batch-icon">
                <Icon name="scan" size={17} />
              </span>
              <span className="batch-name">
                <b>{a.host}</b>
                <em>
                  {a.findings.length} finding(s) · {formatDate(a.createdAt)} · {a.via}
                </em>
              </span>
              <span className={`batch-score ${a.score >= 50 ? "tone-danger" : a.score >= 25 ? "tone-warn" : "tone-ok"}`}>
                {a.grade}
                <em>{a.score}/100</em>
              </span>
            </button>
          ))}
        </div>
      )}

      {!result && audits.length === 0 && !busy && (
        <Empty title="No website scanned yet" icon="scan">
          Start with your own site: paste its address above. The report explains every finding in plain words and gives
          the exact change that fixes it.
        </Empty>
      )}
    </div>
  );
}

function AuditView({ audit }: { audit: WebsiteAudit }) {
  const [filter, setFilter] = useState<Severity | "all">("all");
  const groups = SEVERITIES.map((s) => ({ s, items: audit.findings.filter((f) => f.severity === s) })).filter(
    (g) => g.items.length
  );
  const shown = filter === "all" ? audit.findings : audit.findings.filter((f) => f.severity === filter);
  const tone = audit.score >= 60 ? "danger" : audit.score >= 30 ? "warn" : "ok";

  return (
    <div className="stack" style={{ gap: 14 }}>
      <div className="audit-head">
        <div className={`audit-grade tone-${tone}`}>
          <b>{audit.grade}</b>
          <span>{audit.score}/100 risk</span>
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="row" style={{ gap: 8 }}>
            <span className="badge badge-info">{audit.host}</span>
            <span className="chip">{audit.via}</span>
            <span className="chip">{audit.findings.length} findings</span>
          </div>
          <p className="audit-plain">{audit.plain}</p>
          <a className="tiny mono" href={audit.url} target="_blank" rel="noreferrer noopener">
            {audit.url}
          </a>
        </div>
      </div>

      {audit.topFixes.length > 0 && (
        <section className="fix-strip">
          <div className="side-title">Fix these first</div>
          <ol>
            {audit.topFixes.map((f) => (
              <li key={f}>{f}</li>
            ))}
          </ol>
        </section>
      )}

      <div className="grid grid-2" style={{ alignItems: "start" }}>
        <section className="card">
          <div className="card-head">
            <Icon name="alert" size={14} />
            <div className="card-title">Findings</div>
            <div className="card-sub">{audit.findings.length}</div>
          </div>
          <div className="sev-filter">
            <button type="button" className={filter === "all" ? "active" : ""} onClick={() => setFilter("all")}>
              All
            </button>
            {groups.map((g) => (
              <button key={g.s} type="button" className={filter === g.s ? "active" : ""} onClick={() => setFilter(g.s)}>
                {g.s} <b>{g.items.length}</b>
              </button>
            ))}
          </div>
          <div className="web-findings">
            {shown.map((f) => (
              <article key={f.id} className="web-finding">
                <div className="web-finding-head">
                  <SeverityBadge severity={f.severity} />
                  <b>{f.title}</b>
                  <span className="chip">{f.reference}</span>
                </div>
                {f.evidence && <code className="evidence">{f.evidence}</code>}
                <p>{f.detail}</p>
                <div className="web-fix">
                  <b>Fix</b> {f.fix}
                </div>
              </article>
            ))}
            {shown.length === 0 && <p className="tiny muted">No findings at this severity.</p>}
          </div>
        </section>

        <div className="stack" style={{ gap: 12 }}>
          <section className="side-card">
            <div className="side-title">Security headers</div>
            {!audit.headersAvailable && (
              <p className="prov-plain" style={{ marginBottom: 8 }}>
                Headers were not forwarded by the proxy used for this fetch, so they are unknown. Paste the source and
                run a header check from a terminal for the full picture.
              </p>
            )}
            <div className="header-list">
              {audit.headers.map((h) => (
                <div
                  key={h.name}
                  className={`header-row ${h.value === "not inspected" ? "unknown" : h.ok ? "ok" : "missing"}`}
                >
                  <span className="status-dot" />
                  <div>
                    <b>{h.name}</b>
                    <code>{h.value}</code>
                    <p>{h.note}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section className="side-card">
            <div className="side-title">Page inventory</div>
            <dl className="kv tight">
              {Object.entries(audit.inventory).map(([k, v]) => (
                <div key={k} style={{ display: "contents" }}>
                  <dt>{k}</dt>
                  <dd>{v}</dd>
                </div>
              ))}
            </dl>
          </section>

          <section className="side-card">
            <div className="side-title">Scope &amp; limits</div>
            <ul className="note-list">
              <li>This reads the page source and response headers. It does not attempt to log in, fuzz or exploit anything.</li>
              <li>Only the single page you named is reviewed. Linked pages and APIs need their own scan.</li>
              <li>Server-side code is invisible from outside. A clean result here is not proof the backend is safe.</li>
            </ul>
          </section>
        </div>
      </div>
    </div>
  );
}
