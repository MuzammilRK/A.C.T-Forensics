export type Page = "overview" | "evidence" | "web" | "scanner" | "paths" | "link" | "ledger" | "report";

export const pageMeta: Record<Page, { label: string; icon: string; sub: string }> = {
  overview: { label: "Dashboard", icon: "dashboard", sub: "Case intelligence summary" },
  evidence: { label: "Evidence Lab", icon: "evidence", sub: "Watermarks, provenance & manipulation" },
  web: { label: "Website Check", icon: "shield", sub: "Source-level security review of any URL" },
  scanner: { label: "App Scan", icon: "scan", sub: "Code, dependencies & login posture" },
  paths: { label: "Attack Paths", icon: "graph", sub: "Predicted exploitation routes" },
  link: { label: "Threat-Link Graph", icon: "link", sub: "Evidence ↔ vulnerability correlation" },
  ledger: { label: "Integrity Ledger", icon: "ledger", sub: "SHA-256 chain of custody" },
  report: { label: "Report", icon: "report", sub: "Exportable case findings" },
};
