import { useMemo } from "react";
import { activeCase, useAppStore } from "../lib/store";
import { buildReportJson, buildReportMarkdown, buildManifest } from "../lib/report";
import { buildThreatGraph } from "../lib/graph";
import { downloadText, formatBytes } from "../lib/hash";
import { Icon, ScoreRing } from "../components/ui";

export function Report() {
  const state = useAppStore();
  const caseFile = activeCase(state);
  const json = useMemo(() => buildReportJson(caseFile), [caseFile]);
  const graph = useMemo(() => buildThreatGraph(caseFile), [caseFile]);
  const findings = caseFile.scans.flatMap((s) => s.findings);
  const manifest = buildManifest(caseFile);

  return (
    <div className="stack" style={{ gap: 18 }}>
      <div className="page-head no-print">
        <div>
          <div className="eyebrow">Deliverable</div>
          <h1 className="page-title">Forensic report</h1>
          <p className="page-sub">
            A court-oriented summary of every exhibit, weakness, attack path and integrity record — printable, and
            exportable as machine-readable JSON.
          </p>
        </div>
        <div className="row">
          <button className="btn" type="button" onClick={() => window.print()}>
            <Icon name="print" size={14} /> Print / PDF
          </button>
          <button
            className="btn"
            type="button"
            onClick={() => downloadText(`${caseFile.reference}-report.md`, buildReportMarkdown(caseFile), "text/markdown")}
          >
            <Icon name="download" size={14} /> Markdown
          </button>
          <button
            className="btn btn-primary"
            type="button"
            onClick={() => downloadText(`${caseFile.reference}-report.json`, JSON.stringify(json, null, 2))}
          >
            <Icon name="download" size={14} /> JSON
          </button>
        </div>
      </div>

      <div className="report">
        <div className="report-head">
          <div>
            <div style={{ fontFamily: "var(--mono)", fontSize: 10, letterSpacing: 2, color: "#3b6b6a" }}>
              A.C.T FORENSICS · AI CYBER &amp; EVIDENCE THREAT LAB
            </div>
            <h1 style={{ marginTop: 10 }}>Digital Evidence &amp; Application Security Report</h1>
            <div className="stamp" style={{ marginTop: 8 }}>
              {json.case.name} · {json.case.reference}
            </div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div className="stamp">GENERATED</div>
            <div style={{ fontFamily: "var(--mono)", fontSize: 12, marginTop: 4 }}>
              {new Date(json.generatedAt).toLocaleString()}
            </div>
            <div className="stamp" style={{ marginTop: 10 }}>
              STATUS
            </div>
            <div style={{ fontFamily: "var(--mono)", fontSize: 12, marginTop: 4 }}>
              {findings.filter((f) => f.severity === "critical").length} critical ·{" "}
              {caseFile.evidence.length} exhibits
            </div>
          </div>
        </div>

        <div className="report-meta">
          <div>Case reference: {json.case.reference}</div>
          <div>Case opened: {new Date(json.case.openedAt).toLocaleDateString()}</div>
          <div>Exhibits analysed: {json.summary.exhibits}</div>
          <div>Mean synthetic likelihood: {json.summary.meanSyntheticLikelihood}%</div>
          <div>Application scans: {json.summary.scans}</div>
          <div>Predicted attack paths: {json.summary.attackPaths}</div>
        </div>

        <h2>1 · Executive summary</h2>
        <p>
          {json.summary.exhibits} exhibit(s) were examined for manipulation and synthetic-generation indicators. The
          mean synthetic likelihood across the set is {json.summary.meanSyntheticLikelihood}%. Application analysis
          recorded {json.summary.findings} weakness(es), including {json.summary.critical} critical and{" "}
          {json.summary.high} high severity, and produced {json.summary.attackPaths} ranked route(s) by which an
          attacker could reach case assets.
        </p>
        <p style={{ marginTop: 8 }}>
          {caseFile.evidence.filter((e) => e.analysis.aiLikelihood >= 60).length} exhibit(s) exceed the 60% review
          threshold and are recommended for enhanced examination. {" "}
          {caseFile.evidence.filter((e) => e.integrity?.status === "modified").length
            ? "At least one exhibit fails SHA-256 integrity re-verification and must be treated as potentially altered."
            : "No exhibit currently fails SHA-256 integrity re-verification."}
        </p>

        <h2>2 · Digital evidence findings</h2>
        {manifest.length === 0 ? (
          <p>No exhibits were registered for this case.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Exhibit</th>
                <th>Type</th>
                <th>Finding</th>
                <th>Likelihood</th>
                <th>Integrity</th>
              </tr>
            </thead>
            <tbody>
              {caseFile.evidence.map((e) => (
                <tr key={e.id}>
                  <td>{e.name}</td>
                  <td>{e.kind}</td>
                  <td>{e.analysis.verdict}</td>
                  <td>{e.analysis.aiLikelihood}%</td>
                  <td>{e.integrity?.status ?? "baseline recorded"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {caseFile.evidence.map((e, i) => (
          <div key={e.id}>
            <h3>
              2.{i + 1} {e.name}
            </h3>
            <p>
              {e.analysis.summary} Confidence {e.analysis.confidence}%. File size {formatBytes(e.size)}; SHA-256{" "}
              <span style={{ fontFamily: "var(--mono)", fontSize: 10 }}>{e.hash}</span>.
            </p>
            <ul style={{ marginTop: 6, paddingLeft: 18 }}>
              {e.analysis.signals.slice(0, 5).map((s) => (
                <li key={s.id}>
                  <strong>{s.label}:</strong> {s.detail}
                </li>
              ))}
              {e.regionQuery && (
                <li>
                  <strong>Region interrogation:</strong> {e.regionQuery.verdict} ({e.regionQuery.score}%).
                </li>
              )}
              {e.textQuery && (
                <li>
                  <strong>Quoted portion "{e.textQuery.question}":</strong> {e.textQuery.verdict} ({e.textQuery.score}%).
                </li>
              )}
            </ul>
          </div>
        ))}

        <h2>3 · Application weaknesses</h2>
        {findings.length === 0 ? (
          <p>No application scans were recorded for this case.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Severity</th>
                <th>Finding</th>
                <th>CWE</th>
                <th>Location</th>
                <th>Recommended fix</th>
              </tr>
            </thead>
            <tbody>
              {findings.slice(0, 24).map((f) => (
                <tr key={f.id}>
                  <td>{f.severity}</td>
                  <td>{f.title}</td>
                  <td>{f.cwe}</td>
                  <td>{f.location}</td>
                  <td>{f.fix}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        <h2>4 · Predicted attack paths</h2>
        {graph.paths.length === 0 ? (
          <p>No exploitation routes could be predicted from the recorded findings.</p>
        ) : (
          <ol style={{ paddingLeft: 18, marginTop: 6 }}>
            {graph.paths.map((p) => (
              <li key={p.nodes.map((n) => n.id).join("-")} style={{ marginBottom: 8 }}>
                <strong>{p.probability}% likelihood</strong> — {p.nodes.map((n) => n.label).join(" → ")}.
                <div style={{ fontSize: 11, color: "#4a555c" }}>Recommended fix: {p.mitigation}</div>
              </li>
            ))}
          </ol>
        )}

        <h2>5 · Integrity manifest</h2>
        <table>
          <thead>
            <tr>
              <th>Exhibit</th>
              <th>SHA-256</th>
              <th>Registered</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {manifest.map((m) => (
              <tr key={m.sha256}>
                <td>{m.name}</td>
                <td style={{ wordBreak: "break-all" }}>{m.sha256}</td>
                <td>{new Date(m.registered).toLocaleString()}</td>
                <td>{m.status}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <h2>6 · Methodology &amp; limitations</h2>
        <ul style={{ paddingLeft: 18 }}>
          {json.methodology.map((m) => (
            <li key={m} style={{ marginBottom: 4 }}>
              {m}
            </li>
          ))}
        </ul>

        <div className="disclaimer">{json.disclaimer}</div>
      </div>

      <div className="card card-pad no-print">
        <div className="row" style={{ gap: 18 }}>
          <ScoreRing value={json.summary.meanSyntheticLikelihood} size={66} label="mean" stroke={5} />
          <div style={{ flex: 1 }}>
            <div className="label">Report readiness</div>
            <p className="tiny muted" style={{ marginTop: 4, lineHeight: 1.6 }}>
              {caseFile.evidence.length && findings.length
                ? "Evidence findings and application weaknesses are both present — the report covers the full A.C.T pipeline."
                : "Add more exhibits or run an application scan to strengthen the report. Sections with no data are clearly marked as such."}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
