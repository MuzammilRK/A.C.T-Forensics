import { useAppStore, activeCase } from "../lib/store";
import { buildThreatGraph } from "../lib/graph";
import { Icon, kindIcon } from "../components/ui";
import { formatBytes, formatDate } from "../lib/hash";
import type { Page } from "./nav";

function tone(score: number): "danger" | "warn" | "ok" {
  return score >= 65 ? "danger" : score >= 40 ? "warn" : "ok";
}

export function Overview({
  onNavigate,
  onDemo,
  demoBusy,
  onOpenEvidence,
}: {
  onNavigate: (page: Page) => void;
  onDemo: () => void;
  demoBusy: boolean;
  onOpenEvidence: (id: string) => void;
}) {
  const state = useAppStore();
  const caseFile = activeCase(state);
  const evidence = caseFile.evidence;
  const findings = caseFile.scans.flatMap((s) => s.findings);
  const serious = findings.filter((f) => f.severity === "critical" || f.severity === "high");
  const audits = caseFile.audits ?? [];
  const graph = buildThreatGraph(caseFile);
  const topPath = graph.paths[0];
  const reviewed = evidence.filter((e) => e.integrity?.status === "verified" || e.integrity?.status === "modified");
  const aiFlagged = evidence.filter((e) => e.kind !== "code" && e.analysis.aiLikelihood >= 60);
  // Code risk is a different scale from media authenticity, so it is excluded here.
  const mediaItems = evidence.filter((e) => e.kind !== "code");
  const mean = mediaItems.length
    ? Math.round(mediaItems.reduce((a, e) => a + e.analysis.aiLikelihood, 0) / mediaItems.length)
    : 0;
  const latest = evidence.slice(0, 5);
  const webRisk = audits[0]?.score ?? 0;

  const routing = [
    {
      label: "Visual",
      value: evidence.length ? Math.round((1 - mean / 100) * 100) : 0,
      note: evidence.length ? "pixels consistent with capture" : "no exhibits",
    },
    {
      label: "Metadata",
      value: evidence.length
        ? Math.round((evidence.filter((e) => e.analysis.provenance && e.analysis.provenance.verdict !== "unknown").length / evidence.length) * 100)
        : 0,
      note: "files carrying a provenance record",
    },
    {
      label: "Provenance",
      value: evidence.length ? Math.round((aiFlagged.length / evidence.length) * 100) : 0,
      note: "files with an AI marker",
      risk: aiFlagged.length > 0,
    },
  ];

  return (
    <div className="stack" style={{ gap: 16 }}>
      <section className="command">
        <div className="command-left">
          <div className="eyebrow">Case workspace</div>
          <h1>{caseFile.name}</h1>
          <div className="command-meta">
            <span className="mono">{caseFile.reference}</span>
            <span>{evidence.length} exhibits</span>
            <span>{caseFile.scans.length} app scan(s)</span>
            <span>{audits.length} website scan(s)</span>
          </div>
        </div>
        <div className="command-actions">
          <button className="btn btn-primary" type="button" onClick={() => onNavigate("evidence")}>
            <Icon name="upload" size={14} /> Analyse evidence
          </button>
          <button className="btn" type="button" onClick={() => onNavigate("web")}>
            <Icon name="shield" size={14} /> Check a website
          </button>
          <button className="btn btn-ghost" type="button" onClick={onDemo} disabled={demoBusy}>
            <Icon name="spark" size={14} /> {demoBusy ? "Building demo…" : "Load demo case"}
          </button>
        </div>
      </section>

      <div className="kpi-row">
        <Kpi label="Exhibits analysed" value={evidence.length} sub={`${reviewed.length} re-checked`} />
        <Kpi
          label="Mean AI likelihood"
          value={`${mean}%`}
          sub={mediaItems.length ? `across ${mediaItems.length} media exhibits` : "no media exhibits"}
          tone={tone(mean)}
        />
        <Kpi
          label="AI markers found"
          value={aiFlagged.length}
          sub={aiFlagged.length ? "direct provenance hits" : "none in metadata"}
          tone={aiFlagged.length ? "danger" : "ok"}
        />
        <Kpi
          label="Website risk"
          value={audits.length ? `${webRisk}/100` : "—"}
          sub={audits[0] ? `${audits[0].findings.length} findings · grade ${audits[0].grade}` : "no site scanned"}
          tone={webRisk >= 60 ? "danger" : webRisk >= 30 ? "warn" : "ok"}
        />
        <Kpi
          label="Attack paths"
          value={graph.paths.length}
          sub={topPath ? `${topPath.probability}% top path` : serious.length ? "graph ready" : "no findings yet"}
          tone={serious.length ? "warn" : "ok"}
        />
      </div>

      <p className="kpi-note">
        How to read the score: 0% means nothing in the file points to AI, 100% means the file's own metadata says it was
        generated. Code risk is scored on its own scale and is not included here.
      </p>

      <div className="dash-grid">
        <section className="card dash-main">
          <div className="card-head">
            <Icon name="evidence" size={14} />
            <div className="card-title">Evidence under review</div>
            <button className="btn btn-sm btn-ghost" type="button" onClick={() => onNavigate("evidence")}>
              Open lab <Icon name="arrow" size={12} />
            </button>
          </div>
          {latest.length === 0 ? (
            <div className="dash-empty">
              <p>No exhibits yet. Add an image, video, audio file or document — or load the demo case to see a complete investigation.</p>
              <div className="row" style={{ gap: 8 }}>
                <button className="btn btn-sm btn-primary" type="button" onClick={() => onNavigate("evidence")}>
                  Add evidence
                </button>
                <button className="btn btn-sm" type="button" onClick={onDemo} disabled={demoBusy}>
                  Load demo
                </button>
              </div>
            </div>
          ) : (
            <div className="dash-list">
              {latest.map((item) => {
                const t = tone(item.kind === "code" ? item.analysis.aiLikelihood : item.analysis.aiLikelihood);
                return (
                  <button key={item.id} type="button" className="dash-row" onClick={() => onOpenEvidence(item.id)}>
                    <span className="dash-thumb">
                      {item.analysis.thumbnail ? (
                        <img src={item.analysis.thumbnail} alt="" />
                      ) : (
                        <Icon name={kindIcon(item.kind)} size={18} />
                      )}
                    </span>
                    <span className="dash-row-main">
                      <b>{item.name}</b>
                      <em>
                        {item.kind.toUpperCase()} · {formatBytes(item.size)} · {formatDate(item.addedAt)}
                      </em>
                      <span className="dash-verdict">{item.analysis.verdict}</span>
                    </span>
                    <span className={`dash-score tone-${t}`}>
                      {item.analysis.aiLikelihood}%
                      <em>{item.kind === "code" ? "risk" : "AI"}</em>
                    </span>
                  </button>
                );
              })}
            </div>
          )}
        </section>

        <section className="card side-panel">
          <div className="card-head">
            <Icon name="graph" size={14} />
            <div className="card-title">Signal routing</div>
          </div>
          <div className="routing">
            {routing.map((r) => (
              <div key={r.label} className="routing-row">
                <span>{r.label}</span>
                <div className="routing-bar">
                  <div style={{ width: `${r.value}%` }} className={r.risk ? "risk" : ""} />
                </div>
                <b>{r.value}%</b>
              </div>
            ))}
            <div className="routing-legend">
              <span>
                <i className="dot ok" /> evidence of authenticity
              </span>
              <span>
                <i className="dot danger" /> evidence of AI
              </span>
            </div>
          </div>

          <div className="card-head" style={{ borderTop: "1px solid var(--line-soft)" }}>
            <Icon name="ledger" size={14} />
            <div className="card-title">Chain of custody</div>
          </div>
          <ol className="mini-custody">
            <li>
              <span className="custody-dot" />
              <div>
                <b>Case opened</b>
                <em>{formatDate(caseFile.createdAt)}</em>
              </div>
            </li>
            <li>
              <span className="custody-dot" />
              <div>
                <b>{evidence.length} exhibits fingerprinted</b>
                <em>SHA-256 computed in the browser</em>
              </div>
            </li>
            <li>
              <span className="custody-dot" />
              <div>
                <b>{reviewed.length} integrity re-checks</b>
                <em>{evidence.filter((e) => e.integrity?.status === "modified").length} modified</em>
              </div>
            </li>
            <li>
              <span className="custody-dot" />
              <div>
                <b>Report {caseFile.scans.length ? "ready to export" : "waiting for a scan"}</b>
                <em>{caseFile.reference}</em>
              </div>
            </li>
          </ol>
        </section>
      </div>

      <div className="dash-grid even">
        <section className="card card-pad">
          <div className="card-head" style={{ margin: -16, marginBottom: 10 }}>
            <Icon name="alert" size={14} />
            <div className="card-title">Priority weaknesses</div>
            <button className="btn btn-sm btn-ghost" type="button" onClick={() => onNavigate("scanner")}>
              Scanner <Icon name="arrow" size={12} />
            </button>
          </div>
          {serious.length === 0 ? (
            <p className="tiny muted">
              No high-severity application findings. Run a source scan or the website check to populate this panel.
            </p>
          ) : (
            <div className="signal-list">
              {serious.slice(0, 4).map((f) => (
                <div key={f.id} className="signal-row risk">
                  <span className="dot" />
                  <div>
                    <b>{f.title}</b>
                    <p>
                      {f.location} · {f.cwe} — {f.fix}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        <section className="card card-pad">
          <div className="card-head" style={{ margin: -16, marginBottom: 10 }}>
            <Icon name="link" size={14} />
            <div className="card-title">Predicted attack path</div>
            <button className="btn btn-sm btn-ghost" type="button" onClick={() => onNavigate("paths")}>
              Paths <Icon name="arrow" size={12} />
            </button>
          </div>
          {topPath ? (
            <>
              <div className="path-chain">
                {topPath.nodes.map((n, i) => (
                  <span key={n.id}>
                    {i > 0 && <span>→</span>}
                    <span style={{ color: i === topPath.nodes.length - 1 ? "var(--red)" : "var(--text)" }}>{n.label}</span>
                  </span>
                ))}
              </div>
              <p className="tiny muted" style={{ marginTop: 8, lineHeight: 1.6 }}>
                <b style={{ color: "var(--text)" }}>Blast radius: {topPath.probability}%.</b> {topPath.narrative}
              </p>
            </>
          ) : (
            <p className="tiny muted">
              Add an application scan to generate ranked paths from an entry point to the evidence store.
            </p>
          )}
        </section>
      </div>

      <section className="how">
        {[
          { n: "1", t: "Read the source", d: "Metadata, watermarks and camera records first." },
          { n: "2", t: "Check the pixels", d: "Compression, noise and duplicated texture." },
          { n: "3", t: "Explain it", d: "Every number comes with a plain-language reason." },
          { n: "4", t: "Seal the evidence", d: "SHA-256 fingerprint and an exportable report." },
        ].map((s) => (
          <div key={s.n}>
            <b>{s.n}</b>
            <span>{s.t}</span>
            <em>{s.d}</em>
          </div>
        ))}
      </section>
    </div>
  );
}

function Kpi({
  label,
  value,
  sub,
  tone,
}: {
  label: string;
  value: string | number;
  sub: string;
  tone?: "danger" | "warn" | "ok";
}) {
  return (
    <div className={`kpi ${tone ? `tone-${tone}` : ""}`}>
      <span>{label}</span>
      <b>{value}</b>
      <em>{sub}</em>
    </div>
  );
}
