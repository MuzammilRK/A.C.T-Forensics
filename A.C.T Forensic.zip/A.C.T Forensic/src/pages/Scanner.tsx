import { useMemo, useRef, useState } from "react";
import type { PostureAnswers, ScanKind, VulnFinding } from "../lib/types";
import { activeCase, addScan, setPosture, useAppStore } from "../lib/store";
import { auditPosture, sampleVulnerableSource, scanDependencies, scanSource } from "../lib/vuln";
import { formatDate, uid } from "../lib/hash";
import { Empty, Icon, ScoreRing, SeverityBadge } from "../components/ui";

const SAMPLE_MANIFEST = `{
  "name": "evidence-portal",
  "version": "1.0.0",
  "dependencies": {
    "express": "4.17.1",
    "jsonwebtoken": "8.5.1",
    "lodash": "4.17.15",
    "multer": "1.4.2",
    "axios": "0.21.1",
    "pdfjs-dist": "3.4.120",
    "moment": "2.24.0",
    "xlsx": "0.18.5"
  }
}`;

const POSTURE_ITEMS: { key: keyof PostureAnswers; label: string; desc: string }[] = [
  { key: "https", label: "HTTPS enforced with HSTS", desc: "All traffic redirects to TLS; HSTS preload enabled." },
  { key: "mfa", label: "Multi-factor authentication", desc: "TOTP or WebAuthn enforced for every investigator account." },
  { key: "rateLimit", label: "Login rate limiting", desc: "Per-IP and per-account throttling with lockout alerts." },
  { key: "strongPasswords", label: "Strong password policy", desc: "12+ characters, breach-list screening, no forced rotation." },
  { key: "waf", label: "WAF / API gateway", desc: "Managed OWASP rules in front of all endpoints." },
  { key: "sessionExpiry", label: "Session expiry & rotation", desc: "15-minute idle timeout and rotation on privilege change." },
  { key: "leastPrivilege", label: "Least-privilege case access", desc: "Role-based, per-case authorisation with examiner separation." },
  { key: "logging", label: "Tamper-evident audit logging", desc: "Append-only, hash-chained access trail." },
  { key: "encryptionAtRest", label: "Encryption at rest", desc: "AES-256 with KMS-managed envelope keys." },
  { key: "dependencyScanning", label: "Continuous dependency scanning", desc: "OSV / Dependabot gates in CI." },
];

export function Scanner() {
  const state = useAppStore();
  const caseFile = activeCase(state);
  const [tab, setTab] = useState<ScanKind>("source");
  const [source, setSource] = useState("");
  const [manifest, setManifest] = useState("");
  const [activeScanId, setActiveScanId] = useState<string | null>(null);
  const [selectedFinding, setSelectedFinding] = useState<VulnFinding | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const scans = useMemo(
    () => caseFile.scans.filter((s) => s.kind === tab),
    [caseFile.scans, tab]
  );
  const activeScan = caseFile.scans.find((s) => s.id === activeScanId) ?? scans[0] ?? null;

  const run = () => {
    let result;
    if (tab === "source") {
      if (!source.trim()) return;
      result = scanSource(source, "pasted-source");
    } else if (tab === "dependencies") {
      if (!manifest.trim()) return;
      result = scanDependencies(manifest);
    } else {
      result = auditPosture(caseFile.posture, "login & network posture");
    }
    const scan = {
      id: uid("scan"),
      kind: tab,
      target:
        tab === "source" ? "pasted source" : tab === "dependencies" ? "package.json" : "login & network posture",
      createdAt: new Date().toISOString(),
      score: result.score,
      grade: result.grade,
      findings: result.findings,
      stats: result.stats,
    };
    addScan(caseFile.id, scan);
    setActiveScanId(scan.id);
    setSelectedFinding(null);
  };

  return (
    <div className="stack" style={{ gap: 18 }}>
      <div className="page-head">
        <div>
          <div className="eyebrow">Application scan</div>
          <h1 className="page-title">Vulnerability assessment &amp; login posture</h1>
          <p className="page-sub">
            Static analysis of supplied source, dependency manifests and the portal's authentication posture. Every
            finding carries a CWE reference and a concrete fix, and feeds straight into the attack-path graph.
          </p>
        </div>
        <button className="btn" onClick={run} type="button">
          <Icon name="scan" /> Run {tab === "posture" ? "audit" : "scan"}
        </button>
      </div>

      <div className="tabs">
        <button className={`tab ${tab === "source" ? "active" : ""}`} onClick={() => setTab("source")} type="button">
          Source code
        </button>
        <button className={`tab ${tab === "dependencies" ? "active" : ""}`} onClick={() => setTab("dependencies")} type="button">
          Dependencies
        </button>
        <button className={`tab ${tab === "posture" ? "active" : ""}`} onClick={() => setTab("posture")} type="button">
          Login &amp; network posture
        </button>
      </div>

      <div className="grid" style={{ gridTemplateColumns: "minmax(0, 1.1fr) minmax(0, 1fr)", alignItems: "start" }}>
        <section className="card">
          <div className="card-head">
            <Icon name={tab === "posture" ? "shield" : "code"} size={15} />
            <div className="card-title">
              {tab === "source" ? "Paste or load application source" : tab === "dependencies" ? "Dependency manifest" : "Control checklist"}
            </div>
            <span className="card-sub">{tab}</span>
          </div>
          <div className="card-pad stack" style={{ gap: 12 }}>
            {tab === "source" && (
              <>
                <div className="row">
                  <button className="btn btn-sm" type="button" onClick={() => setSource(sampleVulnerableSource())}>
                    <Icon name="spark" size={12} /> Load vulnerable sample
                  </button>
                  <button className="btn btn-sm" type="button" onClick={() => fileRef.current?.click()}>
                    <Icon name="upload" size={12} /> Load file
                  </button>
                  <input
                    ref={fileRef}
                    type="file"
                    hidden
                    accept=".js,.ts,.tsx,.jsx,.py,.php,.rb,.java,.go,.sql,.json,.txt"
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (file) setSource(await file.text());
                      e.target.value = "";
                    }}
                  />
                  {source && (
                    <button className="btn btn-sm btn-ghost" type="button" onClick={() => setSource("")}>
                      Clear
                    </button>
                  )}
                </div>
                <textarea
                  className="textarea"
                  style={{ minHeight: 330 }}
                  spellCheck={false}
                  placeholder="// Express, Flask, Spring, Laravel, raw SQL — paste the handler, route or module you want assessed…"
                  value={source}
                  onChange={(e) => setSource(e.target.value)}
                />
                <div className="row tiny muted" style={{ justifyContent: "space-between" }}>
                  <span>{source.split(/\r?\n/).length} lines · {source.length} characters</span>
                  <span>Static rules · no traffic is sent to target systems</span>
                </div>
              </>
            )}

            {tab === "dependencies" && (
              <>
                <div className="row">
                  <button className="btn btn-sm" type="button" onClick={() => setManifest(SAMPLE_MANIFEST)}>
                    <Icon name="spark" size={12} /> Load sample package.json
                  </button>
                  {manifest && (
                    <button className="btn btn-sm btn-ghost" type="button" onClick={() => setManifest("")}>
                      Clear
                    </button>
                  )}
                </div>
                <textarea
                  className="textarea"
                  style={{ minHeight: 300 }}
                  spellCheck={false}
                  placeholder='{ "dependencies": { "express": "4.17.1" } }'
                  value={manifest}
                  onChange={(e) => setManifest(e.target.value)}
                />
                <p className="tiny muted" style={{ lineHeight: 1.6 }}>
                  Compares declared versions against a curated advisory table (prototype pollution, ReDoS, verification
                  bypass, path traversal). Production deployments stream OSV and GitHub Advisory feeds.
                </p>
              </>
            )}

            {tab === "posture" && (
              <>
                <p className="tiny muted" style={{ lineHeight: 1.6 }}>
                  Answer for the portal under examination. Missing controls become high-impact findings — weak login and
                  network posture is the easiest route into an evidence system.
                </p>
                <div>
                  {POSTURE_ITEMS.map((item) => (
                    <div className="toggle-row" key={item.key}>
                      <div>
                        <div className="toggle-title">{item.label}</div>
                        <div className="toggle-desc">{item.desc}</div>
                      </div>
                      <button
                        type="button"
                        className={`switch ${caseFile.posture[item.key] ? "on" : ""}`}
                        aria-label={item.label}
                        aria-pressed={caseFile.posture[item.key]}
                        onClick={() =>
                          setPosture(caseFile.id, {
                            ...caseFile.posture,
                            [item.key]: !caseFile.posture[item.key],
                          })
                        }
                      />
                    </div>
                  ))}
                </div>
                <button className="btn btn-primary" onClick={run} type="button">
                  <Icon name="shield" /> Audit {POSTURE_ITEMS.filter((i) => caseFile.posture[i.key]).length}/
                  {POSTURE_ITEMS.length} controls
                </button>
              </>
            )}
          </div>
        </section>

        <section className="card">
          <div className="card-head">
            <Icon name="graph" size={15} />
            <div className="card-title">Latest result</div>
            <span className="card-sub">{activeScan ? formatDate(activeScan.createdAt) : "no scan yet"}</span>
          </div>
          <div className="card-pad">
            {!activeScan ? (
              <Empty title="No result yet" icon="scan">
                Run a scan or audit to populate findings. Results are stored in the case and used by the attack-path
                graph.
              </Empty>
            ) : (
              <div className="stack">
                <div className="row" style={{ gap: 18 }}>
                  <ScoreRing value={activeScan.score} size={92} label="risk score" stroke={7} />
                  <div>
                    <div className="label">Grade</div>
                    <div style={{ fontSize: 32, fontWeight: 600, lineHeight: 1 }}>{activeScan.grade}</div>
                    <div className="tiny muted" style={{ marginTop: 4 }}>
                      {activeScan.findings.length} finding(s) · {activeScan.target}
                    </div>
                  </div>
                </div>
                <div className="stack" style={{ gap: 4 }}>
                  {Object.entries(activeScan.stats).map(([k, v]) => (
                    <div key={k} className="row" style={{ justifyContent: "space-between", fontSize: 11.5 }}>
                      <span className="muted">{k}</span>
                      <span className="mono">{String(v)}</span>
                    </div>
                  ))}
                </div>
                <div className="row" style={{ gap: 6 }}>
                  {(["critical", "high", "medium", "low"] as const).map((sev) => {
                    const count = activeScan.findings.filter((f) => f.severity === sev).length;
                    if (!count) return null;
                    return (
                      <span key={sev} className={`badge badge-${sev}`}>
                        {count} {sev}
                      </span>
                    );
                  })}
                </div>
                {scans.length > 1 && (
                  <div className="field">
                    <span>Scan history</span>
                    <select
                      className="input"
                      value={activeScan.id}
                      onChange={(e) => {
                        setActiveScanId(e.target.value);
                        setSelectedFinding(null);
                      }}
                    >
                      {scans.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.target} · {s.score}/100 · {formatDate(s.createdAt)}
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>
            )}
          </div>
        </section>
      </div>

      {activeScan && activeScan.findings.length > 0 && (
        <section className="card">
          <div className="card-head">
            <Icon name="alert" size={15} />
            <div className="card-title">Finding register</div>
            <span className="card-sub">{activeScan.findings.length} items</span>
          </div>
          <div style={{ padding: "4px 10px 12px" }}>
            <table className="table">
              <thead>
                <tr>
                  <th style={{ width: 90 }}>Severity</th>
                  <th>Finding</th>
                  <th style={{ width: 90 }}>CWE</th>
                  <th style={{ width: 110 }}>Location</th>
                  <th style={{ width: 70 }} />
                </tr>
              </thead>
              <tbody>
                {activeScan.findings.map((f) => (
                  <tr key={f.id}>
                    <td>
                      <SeverityBadge severity={f.severity} />
                    </td>
                    <td>
                      <strong>{f.title}</strong>
                      <div className="tiny" style={{ color: "var(--muted-2)", marginTop: 2 }}>
                        {f.category}
                      </div>
                    </td>
                    <td className="mono tiny">{f.cwe}</td>
                    <td className="mono tiny">{f.location}</td>
                    <td>
                      <button className="btn btn-sm btn-ghost" onClick={() => setSelectedFinding(f)} type="button">
                        Detail
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {activeScan && activeScan.findings.length === 0 && (
        <Empty title="No findings on this target" icon="shield">
          The supplied material matched no rules in the register. Absence of findings is not proof of security — pair
          this with the posture audit and dependency scan.
        </Empty>
      )}

      {selectedFinding && (
        <div className="modal-backdrop" onClick={() => setSelectedFinding(null)}>
          <div className="modal" style={{ width: 720 }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-head">
              <SeverityBadge severity={selectedFinding.severity} />
              <div style={{ flex: 1 }}>
                <h2 style={{ fontSize: 16 }}>{selectedFinding.title}</h2>
                <div className="tiny muted" style={{ marginTop: 4 }}>
                  {selectedFinding.category} · {selectedFinding.cwe} · {selectedFinding.location}
                </div>
              </div>
              <button className="close-btn" onClick={() => setSelectedFinding(null)} type="button">
                <Icon name="close" size={14} />
              </button>
            </div>
            <div className="modal-body stack">
              <div>
                <div className="label">Evidence</div>
                <div className="excerpt" style={{ marginTop: 6 }}>{selectedFinding.snippet}</div>
              </div>
              <div>
                <div className="label">Why it matters</div>
                <p style={{ fontSize: 12.5, lineHeight: 1.65, marginTop: 6, color: "var(--muted)" }}>
                  {selectedFinding.detail}
                </p>
              </div>
              <div className="card card-pad" style={{ borderColor: "rgba(63,224,207,0.3)" }}>
                <div className="label" style={{ color: "var(--cyan)" }}>
                  Recommended fix
                </div>
                <p style={{ fontSize: 12.5, lineHeight: 1.65, marginTop: 6 }}>{selectedFinding.fix}</p>
              </div>
              <div className="row" style={{ gap: 14 }}>
                <span className="chip">Confidence {selectedFinding.confidence}%</span>
                <span className="chip">Weight {selectedFinding.weight}</span>
                <span className="chip">CWE {selectedFinding.cwe}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
